
import org.apache.spark.sql.SparkSession
import io.delta.tables._
import io.delta._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.expressions._
import java.io.File
import org.apache.log4j._

object windowFuncTest {
 
  def main(args: Array[String]): Unit = {
			Logger.getLogger("org").setLevel(Level.ERROR)
			// Create Spark Conf
			val spark = SparkSession
			.builder()
			.appName("DeltaLakeDataValidator")
			.master("local[*]")
				.getOrCreate()
				
		println("TEst")
		import spark.implicits._
		val df = Seq( ("12345", "2021-06-15", 100),
                  ("12345", "2021-07-15", 0),
                  ("12345", "2021-08-15", 0),
                  ("12345", "2021-09-15", 0),
                  ("12345", "2021-10-15", 0),
                  ("12345", "2021-11-15", 100),
                  ("12345", "2021-12-15", 150),
                  ("23456", "2021-06-11", 110),
                  ("23456", "2021-08-11", 110),
                  ("23456", "2021-09-11", 210),
                  ("23456", "2021-10-11", 0),
                  ("23456", "2021-11-11", 110),
                  ("34567", "2021-06-25", 400),
                  ("34567", "2021-07-25", 250),
                  ("34567", "2021-08-25", 350),
                  ("34567", "2021-09-25", 750),
                  ("34567", "2021-10-25", 0),
                  ("34567", "2021-11-25", 750),
                  ("34567", "2021-12-25", 555),
                  ("34567", "2022-01-25", 666),
                  ("34567", "2022-02-25", 777),
                  ("34567", "2022-03-25", 0),
                  ("34567", "2022-04-25", 888),
                  ("34567", "2022-05-25", 333),
                  ("34567", "2022-06-25", 400),
                  ("34567", "2022-07-25", 999)
                ).toDF("account", "emi_date", "emi_amount")
                .withColumn("emi_date", to_date('emi_date,"yyyy-MM-dd"))
                .withColumn("diffCount22", when('emi_amount===0 , lit(1)).otherwise(lit(0)))
                .withColumn("emi_amount22",'emi_amount)
                .withColumn("emi_amount22",last(when(col("emi_amount22") =!= 0, col("emi_amount22")), true).over(Window.partitionBy("account").orderBy('account, 'emi_date)))
                .withColumn("flag22",last(when(lead('emi_amount22,1,0).over(Window.partitionBy("account").orderBy('account, 'emi_date))=!= 'emi_amount22, lit(1)).otherwise(lit(0)), true).over(Window.partitionBy("account").orderBy('account, 'emi_date)))
                //.withColumn("start_date22",first('emi_date, true).over(Window.partitionBy('account).orderBy('account, 'emi_date)))
                .withColumn("start_date22",last(when(lag('emi_amount22,1,0).over(Window.partitionBy("account").orderBy('account, 'emi_date))=!= 'emi_amount22, 'emi_date)
                   // .otherwise(lit(0))
                    , true).over(Window.partitionBy("account").orderBy('account, 'emi_date)))
                .withColumn("end_date22",last('emi_date, true).over(Window.partitionBy('account,'emi_amount22).orderBy('account, 'emi_date)))
                .withColumn("emi_count_temp",lit(1))
                .orderBy('account, 'emi_date)
                df.printSchema()
                df.show()

                
                val w1 = Window.partitionBy("account","emi_amount").orderBy('account, 'emi_date)
                val w2 = Window.partitionBy("account","emi_amount22").orderBy('account, 'emi_date)
                
                                
                
                val df22=df.select('account, 'emi_amount22,'flag22,'emi_date,'diffCount22,'emi_count_temp)
                          .withColumn("start_date", min("emi_date").over(w2))
                        //  .withColumn("start_date22", lag("emi_date",1).over(w2))
                          .withColumn("end_date", max("emi_date").over(w2))
                          .withColumn("temp", lead('emi_amount22,1,0).over(w2))
                          .withColumn("flag", when('emi_amount22 =!= 'temp  ,lit(true)).otherwise(lit(false)))
                          .withColumn("dcount", sum('diffCount22).over(w2))
                          .withColumn("emicount", sum('emi_count_temp).over(w2))
                          .withColumn("row-number", row_number().over(Window.partitionBy('account,'emi_amount22).orderBy('emi_date)))
                          //,sum('diffCount22))
                         // .groupBy('account, 'emi_amount22,'start_date,'end_date).agg(sum('diffCount22))
                          .orderBy('account,'emi_date)
                
                df22.show()
                
                 val df33=df22.filter('flag===true).toDF
                .withColumn("cycleNumber", rank().over(Window.partitionBy('account).orderBy('start_date)))
                .select('account, 'start_date,'end_date,'emi_amount22,'dcount,'emicount,'cycleNumber)
                .orderBy('account,'start_date)
                df33.show()
                
                val df44=df33.filter('cycleNumber <= 8).groupBy('account).pivot('cycleNumber)
                          .agg(
                              first('start_date).alias("start_date"),
                              first('end_date).alias("end_date"),
                              first('emi_amount22).alias("emi_amount"),
                              first('dcount).alias("def_count"),
                              first('emicount).alias("emi_count")
                              )
                df44.show()
                
                System.exit(1)
                
                val df2=df.withColumn("start_date", min("emi_date").over(w1))
                          .withColumn("end_date", max("emi_date").over(w1))
                          .withColumn("temp", lead('emi_amount,1,0).over(w1))
                          .withColumn("temp2", lag('emi_amount,1,0).over(w1))
                          .withColumn("diffCount",when('emi_amount===0 , expr("diffCount +1").cast("integer")).otherwise('diffCount))
                          .withColumn("rownum",row_number().over(Window.partitionBy("account").orderBy('account, 'emi_date)))//(Window.orderBy(lit(1))))
                          .withColumn("emi_amount2", 'emi_amount)
                          .withColumn("emi_amount2",last(when(col("emi_amount2") =!= 0, col("emi_amount2")), true).over(Window.partitionBy("account").orderBy('account, 'emi_date)))
                          .withColumn("emi_cycle_number", rank().over(Window.partitionBy('account,'emi_amount2).orderBy('account,'emi_date)))
                          //.withColumn("flag", when('emi_amount =!= (lag('emi_amount,1,0).over(w1)) && 'emi_amount =!= lit(0) ,lit(true)).otherwise(lit(false)))
                          .withColumn("flag", when('emi_amount =!= 'temp  ,lit(true)).otherwise(lit(false)))
                          .withColumn("flag3", when('emi_amount =!= 'temp2  ,lit(true)).otherwise(lit(false)))
                          //.withColumn("dcount", when('flag===true,'diffCount2))
                          .withColumn("flag2", when('emi_amount === (lag('emi_amount,1).over(w1))  ,lit(false)).otherwise(lit(true)))
                          .orderBy('account,'emi_date)
                          
                val df3=df2.filter('flag===true).toDF
                .withColumn("cycleNumber", rank().over(Window.partitionBy('account).orderBy('start_date)))
                .select('account, 'start_date,'end_date,'emi_amount,'cycleNumber)
                
                df3.show()
                
                
                val dfx=df2
                ////.withColumn("emi_amount2", when('emi_amount===0 ,lag('emi_amount,1).over(Window.partitionBy('account).orderBy('end_date))).otherwise('emi_amount))
                //// .withColumn("emi_amount3", when('emi_amount===0 ,lag('emi_amount2,1).over(Window.partitionBy('account).orderBy('end_date))).otherwise('emi_amount2))
                 //   .when((lag('emi_amount,1).over(Window.partitionBy('account).orderBy('end_date)))===0,lead('emi_amount,1).over(Window.partitionBy('account).orderBy('end_date))).otherwise('emi_amount))
               // .withColumn("cycleNumber", dense_rank().over(Window.partitionBy('account,'flag).orderBy('account,'end_date)))
                //.withColumn("diffCount2", sum('diffCount).over(Window.partitionBy('account,'cycleNumber).orderBy('start_date)))
                //.agg(sum('diffCount).over(Window.partitionBy('account,'cycleNumber).orderBy('start_date)).alias("a"))
               ///// .select('account, 'start_date,'end_date,'emi_amount,'cycleNumber,'flag,'diffCount)//.filter('flag===true).toDF
                .groupBy('account,'emi_amount2).agg(sum('diffCount)).alias("dc").toDF
                
                //df3.show()
                
                dfx.show()
                //https://stackoverflow.com/questions/45035940/how-to-pivot-on-multiple-columns-in-spark-sql
                val df4=df3.groupBy('account).pivot('cycleNumber)
                          .agg(
                              first('start_date).alias("start_date"),
                              first('end_date).alias("end_date"),
                              first('emi_amount).alias("emi_amount")
                              )
                df4.show()
                
                df2.show()
/*+-------+----------+----------+----------+-----------+
|account|start_date|  end_date|emi_amount|cycleNumber|
+-------+----------+----------+----------+-----------+
|  23456|2021-06-25|2021-07-25|       110|          1|
|  23456|2021-08-25|2021-10-25|       210|          2|
|  12345|2021-09-15|2021-09-15|       100|          1|
|  12345|2021-10-15|2021-10-15|       150|          2|
|  34567|2021-06-25|2021-08-25|       400|          1|
|  34567|2021-09-25|2021-10-25|       555|          2|
+-------+----------+----------+----------+-----------+
* /
*/
                
               // df2.select('account, 'emi_amount,'start_date, 'end_date) .dropDuplicates().show()
  }
}