package com.fds.qcl

import io.delta.tables._
import io.delta._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
import utils.SimahRuleChecker._
import utils.QCLInputParams2._
import QCLHistroyLoader_V3._
import QCLRequestLoader_V3._
import QCLResponseLoader_V3._

object QCLOps {
  def main(args: Array[String]) {

    Logger.getLogger("org").setLevel(Level.ERROR)
    //val conf = new SparkConf().setAppName("LogFileParser").setMaster("local[*]").set("spark.testing.memory", "2147480000") //local
    val spark = SparkSession.builder().appName("SparkSQL").master("local[*]")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      //.config("spark.driver.extraJavaOptions","-Dlogger.File=C:/Bigdata/Installs/spark-3.0.1-bin-hadoop3.2/conf/sample.log -Dlog4j.debug -Dlog4j.configuration=file:C:/Bigdata/Installs/spark-3.0.1-bin-hadoop3.2/conf/log4j.properties")
      //.config("spark.executor.extraJavaOptions","-Dlogger.File=C:/Bigdata/Installs/spark-3.0.1-bin-hadoop3.2/conf/sample.log -Dlog4j.debug -Dlog4j.configuration=file:C:/Bigdata/Installs/spark-3.0.1-bin-hadoop3.2/conf/log4j.properties")
      .getOrCreate()

    /*
		// creates a custom logger and log messages
    var logger = Logger.getLogger(this.getClass())
    logger.debug("this is a debug log message")
    logger.info("this is a information log message")
    logger.warn("this is a warning log message")
    logger.trace("this is a TRACE log message")
		//E:\Murali\bigdata_folder\DataProfiling\Simah\LAKEHOUSE\BASE
		*/

    val programStartTime = spark.sparkContext.broadcast(new java.sql.Timestamp(System.currentTimeMillis()))
    println(".....QCL Execution Started @" + programStartTime.value)

    if (args == null )
    {
      println("Usage : Insufficiant Number of arguments , kindly provide required parameters and try again")
      println("Usage : Param 1 : optional home path , Param 2: run option  (HISTORY , REQUEST,RESPONSE) , Param 3: FILE NAME , Param 4 : RUN DATE")
      //|| args(2).length() !=10
      println("Usage : Sample command params without homepath : REQUEST 111REG0000222PLN.xml 30-12-2019")
      println("Usage : Sample command params with home path   : HOME=C:/QCL REQUEST 111REG0000222PLN.xml 30-12-2019")
      println("Error : Aborting the Program ")
      println(".....QCL Execution Aborted @" + new java.sql.Timestamp(System.currentTimeMillis()))
      System.exit(1)
    }
    else if (args != null && args.length == 0 ) 
    {
      println("Usage : Insufficiant Number of arguments , kindly provide required parameters and try again")
      println("Usage : Param 1 : optional home path , Param 2: run option  (HISTORY , REQUEST,RESPONSE) , Param 3: FILE NAME , Param 4 : RUN DATE")
      //|| args(2).length() !=10
      println("Usage : Sample command params without homepath : REQUEST 111REG0000222PLN.xml 30-12-2019")
      println("Usage : Sample command params with home path   : HOME=C:/QCL REQUEST 111REG0000222PLN.xml 30-12-2019")
      println("Error : Aborting the Program ")
      println(".....QCL Execution Aborted @" + new java.sql.Timestamp(System.currentTimeMillis()))
      System.exit(1)
    }
    
    val qcl_home = try { System.getenv.get("QCL_HOME") }
    catch {
      case e: Exception =>
        {
          e.printStackTrace()
          println("Exception caught while getting System Environment variable value for QCL_HOME , setting null value , exucute the program by passing QCL_HOME value as program parameter..")
          null
        }
    }
    val argLength = if (qcl_home == null) 4 else if (args != null && args(0).startsWith("HOME")) 4 else 3

    println("qcl_home:" + qcl_home)
    println("argLength:" + argLength)

    if (args == null || args.length == 0 || args.length == 1 || args.length == 2 || args.length != argLength || args.length >= 5) {
      println("Usage : Insufficiant Number of arguments , kindly provide required parameters and try again")
      println("Usage : Param 1 : optional home path , Param 2: run option  (HISTORY , REQUEST,RESPONSE) , Param 3: FILE NAME , Param 4 : RUN DATE")
      //|| args(2).length() !=10
      println("Usage : Sample command params without homepath : QCL REQUEST 111REG0000222PLN.xml 30-12-2019")
      println("Usage : Sample command params with home path   : QCL  HOME=C:/QCL REQUEST 111REG0000222PLN.xml 30-12-2019")
      println("Error : Aborting the Program ")
      println(".....QCL Execution Aborted @" + new java.sql.Timestamp(System.currentTimeMillis()))
      System.exit(1)
    } else {
      //val QCL_HOME=if(argLength==3 && qcl_home!=null ) qcl_home else  args(0)
      val QCL_HOME = if (args.length == 4) args(0).substring(args(0).indexOf("=") + 1) else if (argLength == 3 && qcl_home != null) qcl_home else ""

      println("QCL_HOME:" + QCL_HOME)

      println(s"ConfigFilePath: $QCL_HOME/config/qcl_config.properties")

      val params = setParams(QCL_HOME)
      if (params.configFileLoad)
       // printInputParams2(params)
        println("Dummy")
      else {
        println(s"Usage : Unable to load the config file kindly check the provided path is correct : $QCL_HOME/config/qcl_config.properties")
        println("Error : Aborting the Program ")
        println(".....QCL Execution Aborted @" + new java.sql.Timestamp(System.currentTimeMillis()))
        System.exit(1)
      }

      val RUN_OPTION = if (argLength == 3) args(0) else args(1)

      val FILE_NAME = if (argLength == 3) args(1) else args(2)

      val RUN_DATE = if (argLength == 3 && qcl_home != null) getRunDate(args(2)) else getRunDate(args(3))

      if (RUN_DATE == new java.sql.Date(0)) {
        println(s"Error : Unable to parse rundate param, Restart the program by supplying rundate in dd-MM-yyyy format:" + args(2))
        println("Error : Aborting the Program ")
        println(".....QCL Execution Aborted @" + new java.sql.Timestamp(System.currentTimeMillis()))
        System.exit(1)
      } //else println(s"runDate: $runDate")

      if (RUN_OPTION != null && !RUN_OPTION.isEmpty() && RUN_OPTION.equalsIgnoreCase("HISTORY")) {
        
        val pattern = "%d %-5p [%c] %m%n"
        
        val logFile=params.OUTPUT_FILE_LOGS_PATH+"QCLHistoryProcessor.log" //+FILE_NAME.substring(0, FILE_NAME.lastIndexOf("."))+".log"
        val fa = new FileAppender
        fa.setName("FileLogger")
        fa.setFile(logFile)
        //fa.setFile("C:/Bigdata/QCL_TESTRUN/logs/testlog.log")
        //fa.setLayout(new PatternLayout("%d %-5p [%c{1}] %m%n"))
        fa.setLayout(new PatternLayout(pattern))
        fa.setThreshold(Level.DEBUG)
        fa.setAppend(true)
        fa.activateOptions
        //add appender to any Logger (here is root)
        Logger.getRootLogger.addAppender(fa)
      // usage
        val log = Logger.getLogger("HistoryProcessor")
             //log.info("I am a log message") 
        
        //def historyLoader(spark : SparkSession,FILE_NAME:String ,params:utils.QCLInputParams2)
        historyLoader(spark, FILE_NAME, params, log)
        
        log.info(".....QCL HISTORY Processor Execution Completed ")//@" + new java.sql.Timestamp(System.currentTimeMillis()))
        log.info("QCL HISTORY Processor Start Time :" + programStartTime.value)
        log.info("QCL HISTORY Processor End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
        log.info("QCL HISTORY Processor Total Execution Time: " + getTimeDifference(programStartTime.value, new java.sql.Timestamp(System.currentTimeMillis())))
        spark.stop()
        
      } else if (RUN_OPTION != null && !RUN_OPTION.isEmpty() && RUN_OPTION.equalsIgnoreCase("REQUEST")) 
      {
      //Start of REQUEST processing if
        val pattern = "%d %-5p [%c] %m%n"
        val logFile=params.OUTPUT_FILE_LOGS_PATH+"QCLRequestProcessor.log" //+FILE_NAME.substring(0, FILE_NAME.lastIndexOf("."))+".log"
        val fa = new FileAppender
        fa.setName("FileLogger")
        fa.setFile(logFile)
        //fa.setFile("C:/Bigdata/QCL_TESTRUN/logs/testlog.log")
        //fa.setLayout(new PatternLayout("%d %-5p [%c{1}] %m%n"))
        fa.setLayout(new PatternLayout(pattern))
        fa.setThreshold(Level.DEBUG)
        fa.setAppend(true)
        fa.activateOptions
        Logger.getRootLogger.addAppender(fa)
      // usage
        val log = Logger.getLogger("RequestProcessor")
        
        //def requestProcessor(spark : SparkSession,FILE_NAME:String ,RUN_DATE: java.sql.Date , params:utils.QCLInputParams2)
        requestProcessor(spark, FILE_NAME,RUN_DATE, params ,log)
        
        log.info("Info: .....QCL REQUEST Processor Execution Completed ")//@" + new java.sql.Timestamp(System.currentTimeMillis()))
        log.info("QCL REQUEST Processor Start Time :" + programStartTime.value)
        log.info("QCL REQUEST Processor End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
        log.info("QCL REQUEST Processor Total Execution Time: " + getTimeDifference(programStartTime.value, new java.sql.Timestamp(System.currentTimeMillis())))
        spark.stop()

      //End of REQUEST processing if
      } else if (RUN_OPTION != null && !RUN_OPTION.isEmpty() && RUN_OPTION.equalsIgnoreCase("RESPONSE")) 
      {
        //Start of RESPONSE processing if
        val pattern = "%d %-5p [%c] %m%n"
        val logFile=params.OUTPUT_FILE_LOGS_PATH+"QCLResponseProcessor.log" //+FILE_NAME.substring(0, FILE_NAME.lastIndexOf("."))+".log"
        val fa = new FileAppender
        fa.setName("FileLogger")
        fa.setFile(logFile)
        //fa.setFile("C:/Bigdata/QCL_TESTRUN/logs/testlog.log")
        //fa.setLayout(new PatternLayout("%d %-5p [%c{1}] %m%n"))
        fa.setLayout(new PatternLayout(pattern))
        fa.setThreshold(Level.DEBUG)
        fa.setAppend(true)
        fa.activateOptions
        Logger.getRootLogger.addAppender(fa)
      // usage
        val log = Logger.getLogger("ResponseProcessor")
        
        //def requestProcessor(spark : SparkSession,FILE_NAME:String ,RUN_DATE: java.sql.Date , params:utils.QCLInputParams2)
        responseProcessor(spark, FILE_NAME,RUN_DATE, params , log)
        
        log.info("....QCL RESPONSE Processor Execution Completed ")//@" + new java.sql.Timestamp(System.currentTimeMillis()))
        log.info("QCL RESPONSE Processor Start Time :" + programStartTime.value)
        log.info("QCL RESPONSE Processor End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
        log.info("QCL RESPONSE Processor Total Execution Time: " + getTimeDifference(programStartTime.value, new java.sql.Timestamp(System.currentTimeMillis())))
        spark.stop()
        
    } else {
        println(s"Warning : Invalid Run options entered : $RUN_OPTION ")
        println(s"Info : Permitted Run options are (HISTORY , REQUEST , RESPONSE) ")
        println("Error : Aborting the Program ")
        println(".....QCLOps Execution Aborted @" + new java.sql.Timestamp(System.currentTimeMillis()))
        System.exit(1)
      }

    } // End of args else block
  } // end of main method
} // end of object