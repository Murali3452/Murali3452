package com.fds.qcl.utils


import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import org.apache.spark.sql._
import org.apache.spark.sql.types._

case class QCLInputParams(propMap: Map[String,String])
{
	/*val responseFileSchema = StructType(Seq(StructField("ACTION", StringType, nullable = true),
			StructField("HEADER",
					StructType(Seq(
							StructField("ERR_ITEMS", StringType, nullable = true),
							StructField("MEMBER_ID", StringType, nullable = true),
							StructField("RUN_NO", StringType, nullable = true),
							StructField("TOT_ITEMS", StringType, nullable = true),
							StructField("USER_ID", StringType, nullable = true))), nullable = true),
			StructField("MESSAGE",
					StructType(Seq(
							StructField("ITEM", ArrayType(StructType(
									List(
											StructField("ERROR", StructType(Seq(
													StructField("DATA", StringType, nullable = true),
													StructField("FIELD", StringType, nullable = true),
													StructField("RSP_MSG", StringType, nullable = true))), nullable = true),
											StructField("NO_ERRORS", StringType),
											StructField("PPRD", StringType),
											StructField("APRD", StringType),
											StructField("PREF", StringType),
											StructField("AREF", StringType),
											StructField("_seq", StringType))))))), nullable = true),
			StructField("SERVICE", StringType, nullable = true),
			StructField("STATUS", StringType, nullable = true)))
			*/
			val configFileLoad = if(propMap.isEmpty) false else true

			val DELTA_TABLE_PATH_BASE             :String =propMap.getOrElse("DELTA_TABLE_PATH_BASE", "NA")
			val DELTA_TABLE_PATH_TEMP             :String =propMap.getOrElse("DELTA_TABLE_PATH_TEMP", "NA")
			val DELTA_TABLE_NAME_BASE             :String =propMap.getOrElse("DELTA_TABLE_NAME_BASE", "NA")
			val DELTA_TABLE_NAME_BASERAW          :String =propMap.getOrElse("DELTA_TABLE_NAME_BASERAW", "NA")
			val DELTA_TABLE_NAME_CONTROL          :String =propMap.getOrElse("DELTA_TABLE_NAME_CONTROL", "NA")

			val INPUT_SOURCE                      :String =if( propMap.getOrElse("INPUT_SOURCE","").isEmpty()) "FILE" else propMap.get("INPUT_SOURCE").get
			val INPUT_FILE_HISTDATA_LOCATION      :String =if( propMap.getOrElse("INPUT_FILE_HISTDATA_LOCATION","").isEmpty()) "WINDOWS" else propMap.get("INPUT_FILE_HISTDATA_LOCATION").get
			val INPUT_FILE_HISTDATA_PATH          :String =propMap.getOrElse("INPUT_FILE_HISTDATA_PATH", "NA")
			val INPUT_FILE_HISTDATA_NAME          :String =propMap.getOrElse("INPUT_FILE_HISTDATA_NAME", "NA")
			val INPUT_FILE_HISTDATA_DELIMETER     :String =if( propMap.getOrElse("INPUT_FILE_HISTDATA_DELIMETER","").isEmpty()) "," else propMap.get("INPUT_FILE_HISTDATA_DELIMETER").get
			val INPUT_FILE_HISTDATA_FORMAT        :String =if( propMap.getOrElse("INPUT_FILE_HISTDATA_FORMAT","").isEmpty()) "CSV" else propMap.get("INPUT_FILE_HISTDATA_FORMAT").get
			val INPUT_FILE_HISTDATA_HEADER        :Boolean = propMap.getOrElse("INPUT_FILE_HISTDATA_HEADER", "true").toBoolean
			val INPUT_FILE_HISTDATA_CHARACTERSET  :String =if( propMap.getOrElse("INPUT_FILE_HISTDATA_CHARACTERSET","").isEmpty()) "UTF-8" else propMap.get("INPUT_FILE_HISTDATA_CHARACTERSET").get
			val INPUT_FILE_HISTDATA_PARSINGMODE   :String =if( propMap.getOrElse("INPUT_FILE_HISTDATA_PARSINGMODE","").isEmpty()) "PERMISSIVE" else propMap.get("INPUT_FILE_HISTDATA_PARSINGMODE").get
			val INPUT_FILE_XMLREQUEST_LOCATION    :String =if( propMap.getOrElse("INPUT_FILE_XMLREQUEST_LOCATION","").isEmpty()) "WINDOWS" else propMap.get("INPUT_FILE_XMLREQUEST_LOCATION").get
			val INPUT_FILE_XMLREQUEST_PATH        :String =propMap.getOrElse("INPUT_FILE_XMLREQUEST_PATH", "NA")
			val INPUT_FILE_XMLREQUEST_NAME        :String =propMap.getOrElse("INPUT_FILE_XMLREQUEST_NAME", "NA")
			val INPUT_FILE_XMLREQUEST_CHARACTERSET:String =if( propMap.getOrElse("INPUT_FILE_XMLREQUEST_CHARACTERSET","").isEmpty()) "UTF-8" else propMap.get("INPUT_FILE_XMLREQUEST_CHARACTERSET").get
			val INPUT_FILE_XMLREQUEST_ROWTAG      :String =if( propMap.getOrElse("INPUT_FILE_XMLREQUEST_ROWTAG","").isEmpty()) "ACCOUNT" else propMap.get("INPUT_FILE_XMLREQUEST_ROWTAG").get
			val OUTPUT_SOURCE                     :String =if( propMap.getOrElse("OUTPUT_SOURCE","").isEmpty()) "FILE" else propMap.get("OUTPUT_SOURCE").get
			val OUTPUT_FILE_DQ_LOCATION           :String =if( propMap.getOrElse("OUTPUT_FILE_DQ_LOCATION","").isEmpty()) "WINDOWS" else propMap.get("OUTPUT_FILE_DQ_LOCATION").get
			val OUTPUT_FILE_DQ_PATH               :String =propMap.getOrElse("OUTPUT_FILE_DQ_PATH", "NA")
			//val OUTPUT_FILE_DQ_NAME               :String =propMap.getOrElse("OUTPUT_FILE_DQ_NAME", "NA")
			val OUTPUT_FILE_DQ_NAME               :String =propMap.getOrElse("OUTPUT_FILE_DQ_NAME", "NA")
			val OUTPUT_FILE_DQ_FORMAT             :String =if( propMap.getOrElse("OUTPUT_FILE_DQ_FORMAT","").isEmpty()) "CSV" else propMap.get("OUTPUT_FILE_DQ_FORMAT").get
			val OUTPUT_FILE_DQ_DELIMETER          :String =if( propMap.getOrElse("OUTPUT_FILE_DQ_DELIMETER","").isEmpty()) "," else propMap.get("OUTPUT_FILE_DQ_DELIMETER").get
			val OUTPUT_FILE_ERR_LOCATION          :String =if( propMap.getOrElse("OUTPUT_FILE_ERR_LOCATION","").isEmpty()) "WINDOWS" else propMap.get("OUTPUT_FILE_ERR_LOCATION").get
			val OUTPUT_FILE_ERR_PATH              :String =propMap.getOrElse("OUTPUT_FILE_ERR_PATH", "NA")
			val OUTPUT_FILE_ERR_NAME              :String =propMap.getOrElse("OUTPUT_FILE_ERR_NAME", "NA")
			val OUTPUT_FILE_ERR_FORMAT            :String =if( propMap.getOrElse("OUTPUT_FILE_ERR_FORMAT","").isEmpty()) "CSV" else propMap.get("OUTPUT_FILE_ERR_FORMAT").get
			val OUTPUT_FILE_ERR_DELIMETER         :String =if( propMap.getOrElse("OUTPUT_FILE_ERR_DELIMETER","").isEmpty()) "," else propMap.get("OUTPUT_FILE_ERR_DELIMETER").get
			val OUTPUT_FILE_XMLREQUET_LOCATION    :String =if( propMap.getOrElse("OUTPUT_FILE_XMLREQUET_LOCATION","").isEmpty()) "WINDOWS" else propMap.get("OUTPUT_FILE_XMLREQUET_LOCATION").get
			val OUTPUT_FILE_XMLREQUET_PATH        :String =propMap.getOrElse("OUTPUT_FILE_XMLREQUET_PATH", "NA")
			val OUTPUT_FILE_XMLREQUET_NAME        :String =propMap.getOrElse("OUTPUT_FILE_XMLREQUET_NAME", "NA")
			val OUTPUT_FILE_XMLREQUET_ROOTTAG     :String =if( propMap.getOrElse("OUTPUT_FILE_XMLREQUET_ROOTTAG","").isEmpty()) "MESSAGE" else propMap.get("OUTPUT_FILE_XMLREQUET_ROOTTAG").get
			val OUTPUT_FILE_XMLREQUET_ROWTAG      :String = if( propMap.getOrElse("OUTPUT_FILE_XMLREQUET_ROWTAG","").isEmpty()) "ACCOUNT" else propMap.get("OUTPUT_FILE_XMLREQUET_ROWTAG").get
			val INPUT_FILE_XMLRESPONSE_LOCATION    :String =if( propMap.getOrElse("INPUT_FILE_XMLRESPONSE_LOCATION","").isEmpty()) "WINDOWS" else propMap.get("INPUT_FILE_XMLRESPONSE_LOCATION").get
			val INPUT_FILE_XMLRESPONSE_PATH        :String =propMap.getOrElse("INPUT_FILE_XMLRESPONSE_PATH", "NA")
			val INPUT_FILE_XMLRESPONSE_NAME        :String =propMap.getOrElse("INPUT_FILE_XMLRESPONSE_NAME", "NA")
			val INPUT_FILE_XMLRESPONSE_CHARACTERSET:String =if( propMap.getOrElse("INPUT_FILE_XMLRESPONSE_CHARACTERSET","").isEmpty()) "UTF-8" else propMap.get("INPUT_FILE_XMLRESPONSE_CHARACTERSET").get
			val INPUT_FILE_XMLRESPONSE_ROWTAG      :String =if( propMap.getOrElse("INPUT_FILE_XMLRESPONSE_ROWTAG","").isEmpty()) "ACCOUNT" else propMap.get("INPUT_FILE_XMLRESPONSE_ROWTAG").get
}
object QCLInputParams {
	def setParams(propFilePath: String):QCLInputParams=
		{
				val propMap=
						try
				{
							Source.fromFile(propFilePath).getLines().filterNot(line => line.startsWith("#")).filter(line => line.contains("="))
							.map { line => // println(line)
							val tokens = line.split("=")
							(tokens(0).trim() -> (if (tokens.length >= 2) tokens(1).trim() else ""))
							}.toMap
				}
				catch{
				case e:Exception  =>
				println("************ Exception Caught in reading the Configuration File:"+propFilePath)
				e.printStackTrace()
				Map[String,String]()
				}
				//val schemaFile=spark.sparkContext.textFile(input_schemafile).map(x=>x.split('|')).collect()
				new QCLInputParams(propMap)
		}
	//val params2=DataProfilerParams
}