package com.fds.qcl

import io.delta.tables._
import com.crealytics.spark.excel._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter ,File ,FileOutputStream,PrintWriter}
import scala.util.Try
import scala.collection.mutable
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import java.time.format.DateTimeFormatter
import java.time._
import scala.io._
import org.apache.commons.io.FileUtils
//import utils.CBDataValidatorHelpers_V1_1._

object contolTableRollback 
{
  
  def main(args: Array[String]) {

   Logger.getLogger("org").setLevel(Level.ERROR)
    val conf = new SparkConf().setAppName("LogFileParser")
    .setMaster("local[*]")
    .set("spark.testing.memory", "2147480000") //local
    
    val spark = SparkSession
      .builder()
      .appName("SparkSQL")
      .master("local[*]")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .config("spark.sql.legacy.timeParserPolicy","LEGACY")// LEGACY //CORRECTED
      .config(conf)
      .getOrCreate()

      val controlTablePath="D:/dphome/deltalake/base/exe_control"
      
      val baseTablePath="D:/dphome/deltalake/base/base_hist"
      
      spark.sql(s"select *  FROM delta.`$controlTablePath`" ).show(false)
      
      spark.sql(s"delete FROM delta.`$controlTablePath` where key1='REG0016415PLN'" )
      
      spark.sql(s"select *  FROM delta.`$controlTablePath`" ).show(false)
      
       System.exit(0)
  }
}