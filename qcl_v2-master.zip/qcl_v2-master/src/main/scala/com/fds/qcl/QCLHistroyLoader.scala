package com.fds.qcl

import org.apache.spark.sql.SparkSession
import io.delta.tables._
import io.delta._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.commons.io.FileUtils
import java.io.File
import org.apache.log4j._

//import utils.SimahCaseClasses._
////#import utils.SimahCaseClasses_V1_2._
import utils.SimahCaseClasses._
//import utils.CBDataValidatorHelpers_V1_1._
////#import utils.CBDataValidatorHelpers_V2_0._
import utils.QCLHelperFunctions._
//import utils.SimahRuleChecker_V1_0._
//import utils.SimahRuleChecker_V1_2._
////#import utils.SimahRuleChecker_V1_3._
import utils.SimahRuleChecker._
////#import utils.CBDataValidatorParams_V1_1._
import utils.QCLInputParams._

/*//import utils.SimahCaseClasses._
import utils.SimahCaseClasses_V1_2._
import utils.CBDataValidatorHelpers_V1_1._
//import utils.SimahRuleChecker_V1_0._
//import utils.SimahRuleChecker_V1_2._
import utils.SimahRuleChecker_V1_3._
import utils.CBDataValidatorParams_V1_1._
 */
object QCLHistroyLoader
{
	def main(args: Array[String]): Unit = {
			Logger.getLogger("org").setLevel(Level.ERROR)
			// Create Spark Conf
			val spark = SparkSession
			.builder()
			.appName("DeltaLakeDataValidator")
			.master("local[*]")
			.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
			.config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
			//#.config("spark.sql.warehouse.dir", "C:\\Bigdata\\warehouse\\deltatable_sqlpaths2")
			//  .config("spark.sql.warehouse.dir", "E:\\Murali\\bigdata_folder\\DataProfiling\\deltalake\\warehouse\\deltatable_sqlpaths2")
			.getOrCreate()
			val programStartTime = spark.sparkContext.broadcast(new java.sql.Timestamp(System.currentTimeMillis()))
			println(".....CBHistoryLoader Execution Started @"+ programStartTime.value)
			val schema_hist_updated = StructType(Seq(
					StructField("MemberID" , IntegerType , nullable = true),
					StructField("SalaryAssignment" , StringType , nullable = true),
					StructField("SecurityType" , StringType , nullable = true),
					StructField("ACHDTAID" , StringType , nullable = true),
					StructField("AccountNumber" , StringType , nullable = true),
					StructField("ProductType" , StringType , nullable = true),
					StructField("PaymentFrequency" , StringType , nullable = true),
					StructField("IssueDate" , DateType , nullable = true),
					StructField("ExpiryDate" , DateType , nullable = true),
					StructField("AsOfDate" , DateType , nullable = true),
					StructField("CloseDate" , DateType , nullable = true),
					StructField("ProductStatus" , StringType , nullable = true),
					StructField("PaymentStatus" , StringType , nullable = true),
					StructField("Tenure" , IntegerType , nullable = true),
					StructField("InstallmentAmount" , DoubleType , nullable = true),
					StructField("OriginalAmount" , DoubleType , nullable = true),
					StructField("OutStandingBalance" , DoubleType , nullable = true),
					StructField("LastCycleID" , IntegerType , nullable = true),
					StructField("LastAmountPaid" , DoubleType , nullable = true),
					StructField("LastPaymentDate" , DateType , nullable = true),
					StructField("NextPaymentDate" , DateType , nullable = true),
					StructField("PastDueBalance" , DoubleType , nullable = true),
					StructField("CIUploadDate" , DateType , nullable = true),
					StructField("CIUpdateDate" , DateType , nullable = true),
					StructField("ACHCRTDAT" , StringType , nullable = true),
					StructField("ACHCHGDAT" , StringType , nullable = true),
					StructField("ACYCRTDAT" , StringType , nullable = true),
					StructField("ACYCHGDAT" , StringType , nullable = true),
					StructField("DefaultStatus" , StringType , nullable = true),
					StructField("DefaultLoadDate" , DateType , nullable = true),
					StructField("DefaultOriginalAmount" , DoubleType , nullable = true),
					StructField("DefaultOutStandingAmount" , DoubleType , nullable = true),
					StructField("DefaultStatusDate" , DateType , nullable = true),
					StructField("DefaultChangeDate" , DateType , nullable = true),
					StructField("CreationDate" , DateType , nullable = true)
					// StructField("CurrentStatus" , StringType , nullable = true) //derived column
					))
			val BaseTablePath= "C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/"
			val BaseHistTableName="base_hist"
			val BaseHistRawTableName="base_hist_raw"
			//Start of run control table creation block
			val controlTableName="exe_control_table"
			val controlTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$controlTableName` (
			|KEY1 STRING,
			|KEY2 STRING,
			|FILENAME STRING,
			|RUNDATE DATE,
			|RUNTIMESTAMP TIMESTAMP,
			|RUNNUMBER INT,
			|FILETYPE STRING,
			|FILEPRODUCT STRING,
			|COUNT_INFILE_REC INT,
			|COUNT_OUTFILE_REC INT,
			|COUNT_REJ_SDVL INT,
			|COUNT_REJ_SIMAH INT,
			|COUNT_REJ_TOTAL INT,
			|COUNT_REJ_EXTRA INT,
			|COUNT_REJ_MISSING INT,
			|COUNT_ACCTS_NEW INT,
			|COUNT_DQ_REC INT,
			|RESP_STS_SDVL STRING,
			|RESP_STS_SIMAH STRING
			)  USING DELTA""".stripMargin
			//
			val insertSql=s"""INSERT INTO delta.`$BaseTablePath$controlTableName` VALUES
			('DEF0000011PLN','DEFPLN','',null,null,11,'DEF','PLN', 0,0,0,0,0,0,0,0,0,'OK','OK') ,
			|('REG0000012PLN','REGPLN','',null,null,12,'REG','PLN', 0,0,0,0,0,0,0,0,0,'OK','OK'),
			|('REG0000013CRC','REGCRC','',null,null,13,'REG','CRC', 0,0,0,0,0,0,0,0,0,'OK','OK'),
			|('REG0000014VLS','REGVLS','',null,null,14,'REG','VLS', 0,0,0,0,0,0,0,0,0,'OK','OK')""".stripMargin
			//Insert records in to control table
			// spark.sql(insertSql)                     
			try {
				val tablePath = new File(BaseTablePath)
						if (tablePath.exists())
						{
						  try
						  {
							println("Path: "+ s"$BaseTablePath" + " Exists creating  Execution control table" )
							spark.sql(controlTableCreateSql)
							println(s"Execution control table : $controlTableName  created")
							spark.sql(insertSql)
							println(s" Inserted initial records in Execution control table  : $controlTableName")
						  }
						  catch{
						    case e: Exception => e.printStackTrace()
					  }
						}
						else
						{
							println("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
							println("Usage: Re-execute the program by changing  control table path value in parameter file ..")
							//System.exit(1)
						}
			}
			catch {
			case e:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
			println("Table: "+ s"$BaseTablePath$controlTableName" + " is already Exists , Skipping control table creation step ...")
			// println("Usage: Re-execute the program by changing  control table name value in parameter file ..")
			//System.exit(1)
			case e: Exception =>
			println("Error : Exception caught in control table creation block")
			e.printStackTrace()
			}
			//End of run control table creation block
			val baseTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$BaseHistTableName` (
					|AccountNumber STRING,
					|ProductType STRING,
					|SalaryAssignment STRING,
					|SecurityType STRING,
					|PaymentFrequency STRING,
					|IssueDate Date,
					|ExpiryDate Date,
					|AsOfDate Date,
					|CloseDate Date,
					|ProductStatus STRING,
					|PaymentStatus STRING,
					|Tenure INT,
					|InstallmentAmount DOUBLE,
					|OriginalAmount DOUBLE,
					|OutStandingBalance DOUBLE,
					|LastCycleID INT,
					|LastAmountPaid DOUBLE,
					|LastPaymentDate Date,
					|NextPaymentDate Date,
					|PastDueBalance DOUBLE,
					|DefaultStatus STRING,
					|DefaultLoadDate Date,
					|DefaultOriginalAmount DOUBLE,
					|DefaultOutStandingAmount DOUBLE,
					|DefaultStatusDate Date,
					|DefaultChangeDate Date,
					|CIUploadDate Date,
					|CIUpdateDate Date,
					|CurrentStatus STRING,
					|ReportedDate Date,
					|DPR INT,
					|DPA INT,
					|RJC INT
					)  USING DELTA""".stripMargin//.replaceAll("\n", "")
					val baseRawTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$BaseHistRawTableName` (
					|MemberID INT,
					|SalaryAssignment STRING,
					|SecurityType STRING,
					|ACHDTAID STRING,
					|AccountNumber STRING,
					|ProductType STRING,
					|PaymentFrequency STRING,
					|IssueDate Date,
					|ExpiryDate Date,
					|AsOfDate Date,
					|CloseDate Date,
					|ProductStatus STRING,
					|PaymentStatus STRING,
					|Tenure INT,
					|InstallmentAmount DOUBLE,
					|OriginalAmount DOUBLE,
					|OutStandingBalance DOUBLE,
					|LastCycleID INT,
					|LastAmountPaid DOUBLE,
					|LastPaymentDate Date,
					|NextPaymentDate Date,
					|PastDueBalance DOUBLE,
					|CIUploadDate Date,
					|CIUpdateDate Date,
					|ACHCRTDAT STRING,
					|ACHCHGDAT STRING,
					|ACYCRTDAT STRING,
					|ACYCHGDAT STRING,
					|DefaultStatus STRING,
					|DefaultLoadDate Date,
					|DefaultOriginalAmount DOUBLE,
					|DefaultOutStandingAmount DOUBLE,
					|DefaultStatusDate Date,
					|DefaultChangeDate Date,
					|CreationDate Date)  USING DELTA""".stripMargin//.replaceAll("\n", "")
					try {
						val tablePath = new File(BaseTablePath)
								if (tablePath.exists())
								{
									println("Path: "+ s"$BaseTablePath" + " Exists creating  base tables" )
									spark.sql(baseRawTableCreateSql)
									println(s"Base raw table : $BaseHistTableName _raw created")
									spark.sql(baseTableCreateSql)
									println(s"Base table : $BaseHistTableName  created")
								}
								else
								{
									println("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
									println("Usage: Re-execute the program by changing  base table path value in parameter file ..")
									System.exit(1)
								}
					}
			catch {
			case e:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
			println("Table: "+ s"$BaseTablePath$BaseHistRawTableName" + " is already Exists , exiting the program ...")
			println("Usage: Re-execute the program by changing  base table name value in parameter file ..")
			System.exit(1)
			case e: Exception =>
			println("Error : Exception caught in base table creation block")
			e.printStackTrace()
			}
			//   FileUtils.deleteDirectory(tablePath)
			//Read data from CSV and load it to Delta table
			//val HistoryFilePath="E:\\Murali\\bigdata_folder\\DataProfiling\\deltalake\\warehouse\\simah_input_recon\\119_ReconiliationFile_20220529.csv"
			val HistoryFilePath="C:/Bigdata/QCL_EXECUTION/input/" //"E:/Murali/bigdata_folder/DataProfiling/deltalake/warehouse/simah_input_recon/"
			
					val HistoryFileName="PLN_HISTDATA_13170.csv"//"119_ReconiliationFile_20220529.csv"
					//val df = spark.read.option("header",true).option("inferSchema", "false").schema(schema_hist_updated).csv(HistoryFilePath)
					try {
						val FolderPath = new File(HistoryFilePath)
								if (FolderPath.exists() && FolderPath.isDirectory())
								{
									println("Path: "+ s"$HistoryFilePath" + " Exists checking for files" )
									// val a=FileUtils.listFiles(HistoryFilePath, HistoryFileName)//, dirFilter)(new File(HistoryFilePath+HistoryFileName))
									val FileName = new File(HistoryFilePath+HistoryFileName)
									if(FileName.exists() && FileName.isFile())
									{
										println("File :" + FileName.getAbsolutePath + " is available started loding the file..")
										val HistoryDF = spark.sqlContext.read.format("csv").option("header", "true").option("inferSchema", "false")
										.schema(schema_hist_updated)//  .option("delimiter", " ")
										.load(HistoryFilePath+HistoryFileName)
										HistoryDF.show()
										println(s"Data load started to Base raw table : $BaseTablePath$BaseHistRawTableName ")
										HistoryDF.printSchema()
										// Write the data to delta target table.
										HistoryDF.write.format("delta").mode("overwrite").save(BaseTablePath+BaseHistRawTableName) //.save("E:/Murali/bigdata_folder/DataProfiling/deltalake/warehouse/hist_delta_table")
										println(s"Data load completed to Base raw table : $BaseTablePath$BaseHistRawTableName ")
									}
									else
									{
										println(s"File: $FileName is not available  exiting the program ...")
										println(s"Usage: dropping the table $BaseTablePath$BaseHistRawTableName ..")
										FileUtils.deleteDirectory(new File(s"$BaseTablePath$BaseHistRawTableName"))
										//spark.sql(s"DROP TABLE IF EXISTS `$BaseTablePath$BaseHistRawTableName`")
										println(s"Usage: Droppped the table $BaseTablePath$BaseHistRawTableName ..")
										println("Usage: Re-execute the program by changing  history file path and/or name value in parameter file ..")
										System.exit(1)
									}
								}
								else
								{
									println("Path: "+ s"HistoryFilePath" + " is Not Exists exiting the program ...")
									println(s"Usage: dropping the table $BaseTablePath$BaseHistRawTableName ..")
									FileUtils.deleteDirectory(new File(s"$BaseTablePath$BaseHistRawTableName"))
									//spark.sql(s"DROP TABLE IF EXISTS `$BaseTablePath$BaseHistRawTableName`")
									println(s"Usage: Droppped the table $BaseTablePath$BaseHistRawTableName ..")
									println("Usage: Re-execute the program by changing  history file path value in parameter file ..")
									System.exit(1)
								}
					}
			catch {
				//case e:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
				//println("Table: "+ s"$BaseTablePath$BaseHistRawTableName" + " is already Exists , exiting the program ...")
				//println("Usage: Re-execute the program by changing  base table name value in parameter file ..")
			case e: Exception =>
			println("Error : Exception caught in history file load block")
			e.printStackTrace()
			}
			val tempDF =spark.sql(s"SELECT * FROM delta.`$BaseTablePath$BaseHistRawTableName`").na.fill("")
					tempDF.show()
					println(s"Total records loaded in base history raw table $BaseHistRawTableName :" + tempDF.count())
					try
			{
						import spark.implicits._
						val currentTime=new java.sql.Timestamp(System.currentTimeMillis())
						val hist_base_DF=tempDF
						.withColumn("IssueDate", when('IssueDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('IssueDate))
						.withColumn("ExpiryDate", when('ExpiryDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('ExpiryDate))
						.withColumn("CloseDate", when('CloseDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('CloseDate))
						.withColumn("LastPaymentDate", when('LastPaymentDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('LastPaymentDate))
						.withColumn("NextPaymentDate", when('NextPaymentDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('NextPaymentDate))
						.withColumn("DefaultLoadDate", when('DefaultLoadDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultLoadDate))
						.withColumn("DefaultStatusDate", when('DefaultStatusDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultStatusDate))
						.withColumn("DefaultChangeDate", when('DefaultChangeDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultChangeDate)).withColumn("CurrentStatus", when('DefaultStatus =!= "NULL" && ('DefaultStatus==="FS" || 'DefaultStatus==="NS") , lit("SETTLED"))
								.when('ProductStatus =!= "NULL" && 'ProductStatus==="C"  , lit("CLOSED"))
								.when('ProductStatus=!= "NULL" && 'ProductStatus==="A" && 'DefaultStatus==="NULL" , lit("ACTIVE"))
								.when('ProductStatus =!= "NULL" && 'ProductStatus==="S"  && 'DefaultStatus === "NULL" , lit("SUSPENDED"))
								.when('ProductStatus =!= "NULL"  && 'ProductStatus==="W"  && ('DefaultStatus === "NULL" || 'DefaultStatus==="OS" || 'DefaultStatus==="PP") , lit("WRITTENOFF"))
								.when('DefaultStatus =!= "NULL" && 'DefaultStatus==="RS"  , lit("CLOSED"))
								.otherwise('ProductStatus))
						.withColumn("ReportedDate", coalesce('DefaultStatusDate, 'CIUpdateDate))
						.withColumn("currentDate", current_date())
						.withColumn("DPR",datediff('currentDate, coalesce('DefaultStatusDate, 'CIUpdateDate)))
						.withColumn("DPA",datediff('currentDate, coalesce('DefaultStatusDate, 'CIUpdateDate)))
						// .withColumn("DPR",  expr(s" (( $currentTime - CIUploadDate.getTime() ) / (60 * 60 * 1000 *24))"))//                    lit(null).cast(IntegerType))
						// .withColumn("DPR",  expr(s" (($currentTime - CIUploadDate.getTime() ) / (60 * 60 * 1000 *24))"))
						//  .withColumn("x", getTimeDifference('CIUploadDate,new java.sql.Timestamp(System.currentTimeMillis())))
						//.withColumn("DPA",  lit(null).cast(IntegerType))
						.withColumn("RJC", lit(0).cast(IntegerType))
						.select('AccountNumber,'ProductType,'SalaryAssignment,'PaymentFrequency,'SecurityType,'IssueDate,'ExpiryDate,
								'AsOfDate,'CloseDate,'ProductStatus,'PaymentStatus,'Tenure,'InstallmentAmount,
								'OriginalAmount,'OutStandingBalance,'LastCycleID,'LastAmountPaid,'LastPaymentDate,
								'NextPaymentDate,'PastDueBalance,'DefaultStatus,'DefaultLoadDate,'DefaultOriginalAmount,
								'DefaultOutStandingAmount,'DefaultStatusDate,'DefaultChangeDate,'CIUploadDate,
								'CIUpdateDate,'CurrentStatus,'ReportedDate,'DPR,'DPA,'RJC)
						hist_base_DF.show() 
						//Test
						hist_base_DF.groupBy('CurrentStatus,'ProductStatus,'DefaultStatus).agg(count('AccountNumber).as("TotalAccts")).show()
						hist_base_DF.write.format("delta").mode("overwrite").save(BaseTablePath+BaseHistTableName)
						// val HistBaseDS=hist_base_DF.as[HistBaseCaseClass]
						val HistBaseDS=spark.sql(s"SELECT * FROM delta.`$BaseTablePath$BaseHistTableName`").as[HistBaseCaseClass]
								println(s"Total records loaded in base history table $BaseHistTableName : "+ HistBaseDS.count())
								HistBaseDS.printSchema()
								println("TestFlow: function call def:getHistoryDQReport")
								//Funcation call
								val HistDQDS= for
								{
									row <- HistBaseDS
									//getInvalidRecords
									val rows=getHistoryDQReport(row.AccountNumber           ,
											row.ProductType             ,
											row.SalaryAssignment        ,
											row.SecurityType            ,
											row.PaymentFrequency       ,
											row.IssueDate               ,
											row.ExpiryDate              ,
											row.AsOfDate                ,
											row.CloseDate               ,
											row.ProductStatus           ,
											row.PaymentStatus           ,
											row.Tenure                  ,
											row.InstallmentAmount       ,
											row.OriginalAmount          ,
											row.OutStandingBalance      ,
											row.LastCycleID             ,
											row.LastAmountPaid          ,
											row.LastPaymentDate         ,
											row.NextPaymentDate         ,
											row.PastDueBalance          ,
											row.DefaultStatus           ,
											row.DefaultLoadDate         ,
											row.DefaultOriginalAmount   ,
											row.DefaultOutStandingAmount,
											row.DefaultStatusDate       ,
											row.DefaultChangeDate       ,
											row.CIUploadDate            ,
											row.CIUpdateDate            ,
											row.CurrentStatus           ,
											row.ReportedDate            ,
											row.DPR                     ,
											row.DPA                     ,
											row.RJC                     )
								} yield rows
								val HistDQDF=  HistDQDS.filter(col("ValidFlag")=!=("VALID")).toDF()
								println("TestFlow: return from function , got HistDQDS and filterd output to HistDQDF")
								HistDQDF.printSchema()
								HistDQDF.show()
								//println("HistoryDQ count:"+HistDQDF.count())
								val a= HistDQDF.groupBy('ErrorIDs).agg(count('AccountNumber).as("TotalAccts"))
								a.show()
								try
								{
									a.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(BaseTablePath+"HistDQReport_Summary")
								}
								catch{
								case e: Exception =>
								println("Error : Exception caught while saving SummaryHistDQReport ")
								e.printStackTrace()
								}
								//val HistDQReport=HistDQDS.join(HistDQDF)
								//Seq("name")
								//val HistDQReport=hist_base_DF.join(HistDQDF, hist_base_DF("AccountNumber") === HistDQDF("AccountNumber") && hist_base_DF("ProductType") === HistDQDF("ProductType"), "full")
								val HistDQReport=HistDQDF.join(hist_base_DF, Seq("AccountNumber","ProductType") , "inner")
										HistDQReport.show()
										try
								{
											HistDQReport.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(BaseTablePath+"HistDQReport_Detail")
								}
								catch{
								case e: Exception =>
								println("Error : Exception caught while saving DetailHistDQReport ")
								e.printStackTrace()
								}
			}
			catch {
			case e: Exception =>
			println("Error : Exception caught in base history table load block")
			e.printStackTrace()
			}
			println(".....CBHistoryLoader Execution Completed @"+ new java.sql.Timestamp(System.currentTimeMillis()))
			println("Start Time :" + programStartTime.value)
			println("End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
			println("Execution Time: " + getTimeDifference(programStartTime.value,new java.sql.Timestamp(System.currentTimeMillis())))
			spark.stop()
	}
}