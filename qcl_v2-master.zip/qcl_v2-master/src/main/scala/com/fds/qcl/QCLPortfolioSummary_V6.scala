package com.fds.qcl

import io.delta.tables._
import com.crealytics.spark.excel._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import scala.util.Try
import scala.collection.mutable
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import java.time.format.DateTimeFormatter
import java.time._
import scala.io._
import org.apache.commons.io.FileUtils
//import utils.CBDataValidatorHelpers_V1_1._
import utils.QCLHelperFunctions_V2._

object QCLPortfolioSummary_V6 {

  def extractPortfolioSummaryReport(spark: SparkSession, params: utils.QCLConfigParams, log: Logger, RUN_DATE: java.sql.Date): Unit = {
    //def main(args: Array[String]) {

    val controlTablePath = params.DELTA_TABLE_PATH_BASE + params.DELTA_TABLE_NAME_CONTROL
    val baseTablePath = params.DELTA_TABLE_PATH_BASE + params.DELTA_TABLE_NAME_BASE

    println("RUN_DATE:" + RUN_DATE)
    val PFProductGroup = List("ADFL", "CDL", "DPLN", "DSTFM", "EDUF", "MGLD", "PLN", "RPLN", "RSFM", "SFB", "SME", "STFM", "TPLN") //ProductGroupPersonalLoan PLN PRDGRPPLN
    val CCProductGroup = List("CDC", "CHC", "CRC", "LCRC", "POD", "TOD") //Product Group PCR Credit Cards CRC                PRDGRPPCR
    val ALProductGroup = List("RSMEI", "RSMEL", "RVIN", "RVLS", "SMEI", "SMEL", "VEHE", "VESP", "VIN", "VLS", "VRA") //Product Group Vehicle               VLB        PRDGRPVEH
    val MTGProductGroup = List("AMTG", "AQAR", "EMTG", "IMTG", "INPR", "MMTG", "MSKN", "MTG", "OMTG", "RERA", "RMSKN", "RMTG", "SMTG", "TMTG") //ProductGroupMortgage           MTG      PRDGRPMTG

    import spark.implicits._

    val aggDF2 = spark.sql(s"SELECT * FROM delta.`$baseTablePath`").toDF()
      .withColumn("Rundate", lit(RUN_DATE).cast(DateType))
      .withColumn("RundateTime", lit(current_timestamp()).cast(TimestampType))
      //.withColumn("OS_BALANCE", when( 'DefaultStatus.isNotNull ,'DefaultOutStandingAmount ).otherwise('OutStandingBalance))
      .withColumn("OS_BALANCE", when('ProductStatus === "W", 'DefaultOutStandingAmount).otherwise('OutStandingBalance))
      //.withColumn("PAST_DUE", when( 'DefaultStatus.isNull ,'PastDueBalance ).otherwise(lit(0)))
      .withColumn("PAST_DUE", when('CurrentStatus === "ACTIVE" || 'CurrentStatus === "SUSPENDED", 'PastDueBalance).otherwise(lit(0)))
      .withColumn("DEFAULT_ORIGINAL_AMOUNT", when('CurrentStatus === "SETTLED" || 'CurrentStatus === "WRITTENOFF", 'DefaultOriginalAmount).otherwise(lit(0)))
      .withColumn("ProductGroup", when(('ProductType).isin(PFProductGroup: _*), lit("PF"))
        .when('ProductType.isin(MTGProductGroup: _*), lit("RF"))
        .when('ProductType.isin(ALProductGroup: _*), lit("AL"))
        .when('ProductType.isin(CCProductGroup: _*), lit("CC"))
        .otherwise('ProductType))
      .groupBy("Rundate", "ProductGroup", "ProductType", "CurrentStatus")
      .agg(
        count("AccountNumber").as("Total_accts_count"),
        sum("OS_BALANCE").cast(DecimalType(25, 0)).alias("Total_OS_amount"),
        sum("OriginalAmount").cast(DecimalType(25, 0)).alias("Total_loan_amount"),
        //sum("DefaultOriginalAmount").cast(DecimalType(25,0)).alias("Total_Defaulted_amount"),
        sum("DEFAULT_ORIGINAL_AMOUNT").cast(DecimalType(25, 0)).alias("Total_Defaulted_amount"),
        //sum("PastDueBalance").cast(DecimalType(25,0)).alias("Total_PastDue_amount")
        sum("PAST_DUE").cast(DecimalType(25, 0)).alias("Total_PastDue_amount"))
    val aggDF3 = aggDF2.select("Rundate", "ProductGroup", "ProductType", "CurrentStatus", "Total_accts_count", "Total_OS_amount", "Total_loan_amount", "Total_Defaulted_amount", "Total_PastDue_amount")
      //.withColumn("RundateTime", lit(current_timestamp()).cast(TimestampType))
      //.withColumn("RundateTime",  concat( hour(lit(current_timestamp())) ,lit(":"), minute(lit(current_timestamp())) ))
      .withColumn("RundateTime", lit(current_timestamp()))
      .withColumn("KEY", concat('Rundate, 'ProductGroup, 'ProductType, 'CurrentStatus))
      .select('KEY, 'Rundate, 'RundateTime, 'ProductGroup, 'ProductType, 'CurrentStatus, 'Total_accts_count, 'Total_OS_amount, 'Total_loan_amount, 'Total_Defaulted_amount, 'Total_PastDue_amount)
    // aggDF3.show(false)
    // System.exit(0)
    try {
      println("Usage : Start : Saving the Portfolio_stats_Table ")
      val portfolioTablePath = "D:/dphome2/deltalake/base/portfolio_summary"
      // aggDF3.write.format("delta").mode("overwrite").save(portfolioTablePath)

      DeltaTable.forPath(portfolioTablePath)
        .as("target")
        .merge(
          aggDF3.as("source"),
          "target.KEY = source.KEY")
        .whenMatched
        .updateAll()
        // .updateExpr(
        //   Map("data" -> "updates.data"))
        .whenNotMatched
        // .insertExpr(
        //   Map(
        //     "date" -> "updates.date",
        //    "eventId" -> "updates.eventId",
        //    "data" -> "updates.data"))
        .insertAll()
        .execute()

      println("Usage : End : Saving the Portfolio_stats_table ")

      val df = spark.sql(s"SELECT * FROM delta.`$portfolioTablePath`").toDF()

      println("Df schema")
      df.printSchema()
      df.show(false)
      try {
        println("Usage : Start : Saving the Portfolio_Summary_Report ")

        val outputPath = params.OUTPUT_FILE_REPORTS_PATH + "Portfolio_Summary_Report_" + RUN_DATE + ".xlsx"
        
        //"D:/dphome2/output/reports/" + "Portfolio_Summary_Report_" + RUN_DATE + ".xlsx"

        df.drop('KEY).write.format("com.crealytics.spark.excel")
          //.option("sheetName", "Sheet_1")
          //.option("dataAddress","Sheet_1")
          //.option("useHeader", "true")
          .option("header", "true")
          //.option("treatEmptyValuesAsNulls", "false")
          .option("dateFormat", "MM/DD/yyyy")
          //  .option("addColorColumns", "False")
          .mode("overwrite")
          .save(outputPath)
        println("Usage : End : Saving the Portfolio_Summary_Report ")
      } catch {
        case e: Exception =>
          println("Error : Exception caught while saving portfolio Summary report ")
          e.printStackTrace()
          println(e)
      }
      //  val deltaTable = DeltaTable.forPath(spark, portfolioTablePath)

      //deltaTable.toDF
    } catch {
      case e: Exception =>
        println("Error : Exception caught while updating portfolio Summary Table ")
        e.printStackTrace()
        println(e)
    }

  }
}