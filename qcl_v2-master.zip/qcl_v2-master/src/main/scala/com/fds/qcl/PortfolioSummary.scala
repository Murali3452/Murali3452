package com.fds.qcl


//import utils.CBDataValidatorHelpers_V1_1._
    import io.delta.tables._
import com.crealytics.spark.excel._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter ,File ,FileOutputStream,PrintWriter}
import scala.util.Try
import scala.collection.mutable
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import java.time.format.DateTimeFormatter
import java.time._
import scala.io._
import org.apache.commons.io.FileUtils

object PortfolioSummary
{
  
 def getFileName(filePath: String): String = {
     
     filePath.substring(filePath.lastIndexOf("/")+1)
     
   }
  




  def main(args: Array[String]) {

//Logger.getLogger("org").setLevel(Level.ERROR)
    val conf = new SparkConf().setAppName("LogFileParser")
    .setMaster("local[*]")
    .set("spark.testing.memory", "2147480000") //local
    
    val spark = SparkSession
      .builder()
      .appName("SparkSQL")
      .master("local[*]")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .config("spark.sql.legacy.timeParserPolicy","LEGACY")// LEGACY //CORRECTED
      .config(conf)
      .getOrCreate()

      val controlTablePath="D:/dphome/deltalake/base/exe_control"
      
      val baseTablePath="D:/dphome/deltalake/base/base_hist"
      

      val deltaTable = DeltaTable.forPath(spark, baseTablePath)

      val fullHistoryDF = deltaTable.history()    // get the full history of the table
      
     
       fullHistoryDF.show(50,false)
  //System.exit(0)
       
      //val dfVersion=spark.sql(s"select * FROM delta.`$baseTablePath` VERSION AS OF 2" )
      
      import spark.implicits._
      val histVersion=0
      
          import spark.implicits._
         val aggDF=spark.sql(s"select * FROM delta.`$baseTablePath`" )//.limit(10).toDF()
                         .withColumn("Rundate", current_date())
                         .withColumn("version", lit(1))
                        //.withColumn("OS_BALANCE", when( 'DefaultStatus.isNotNull ,'DefaultOutStandingAmount ).otherwise('OutStandingBalance))
                        //.groupBy("ProductType","CurrentStatus","PaymentStatus")
                        .groupBy("Rundate","version","CurrentStatus")
                        .agg(
                            count("AccountNumber").as("Total_accts_count"),
                            sum("OutStandingBalance").cast(DecimalType(25,0)).alias("Total_OS_amount"),
                            sum("OriginalAmount").cast(DecimalType(25,0)).alias("Total_loan_amount"),
                            sum("DefaultOriginalAmount").cast(DecimalType(25,0)).alias("Total_Defaulted_amount"),
                            sum("PastDueBalance").cast(DecimalType(25,0)).alias("Total_PastDue_amount")
                            )   
     // val sampleDF=stgDF.selectExpr(allSqls(1).toSeq :_*).limit(1).toDF() //spark.createDataFrame(colSeq.head ,colSeq.tail:_*)
     //  val sampleDF=spark.sql(s"select * FROM delta.`$baseTablePath` VERSION AS OF 2" ).limit(10).toDF() //spark.createDataFrame(colSeq.head ,colSeq.tail:_*)
         
    val outputPath=s"D:/dphome/output/portfolio_summmary_rundate_allVersion34to41_CurrentStatus.xlsx"
        
      //  summaryDF.show(false)
        
      /*aggDF.write.format("com.crealytics.spark.excel")
                //.option("sheetName", "Sheet_1")
                //.option("dataAddress","Sheet_1")
                //.option("useHeader", "true")
                .option("header", "true")
                //.option("treatEmptyValuesAsNulls", "false")
                .option("dateFormat", "MM/DD/yyyy")
               //  .option("addColorColumns", "False")
                .mode("overwrite")
                .save(outputPath)
    */
     val emptyDF = spark.createDataFrame(spark.sparkContext.emptyRDD[Row],  aggDF.schema)
      
      val versionsList=List.range(40, 42)
      
      val unionDF= versionsList.map{ 
      histVersion => 
        //stgDF.selectExpr(sql.toSeq : _*)//.show(2,false)
        val dfVersion = spark.read.format("delta").option("versionAsOf", histVersion).load(baseTablePath)
                        .withColumn("Rundate", current_date()-histVersion)
                        .withColumn("version", lit(histVersion))
                       // .withColumn("OS_BALANCE", when( 'DefaultStatus.isNotNull ,'DefaultOutStandingAmount ).otherwise('OutStandingBalance))
                        //.groupBy("ProductType","CurrentStatus","PaymentStatus")
                        .groupBy("Rundate","version","CurrentStatus")
                        .agg(
                            count("AccountNumber").as("Total_accts_count"),
                            sum("OutStandingBalance").cast(DecimalType(25,0)).alias("Total_OS_amount"),
                            sum("OriginalAmount").cast(DecimalType(25,0)).alias("Total_loan_amount"),
                            sum("DefaultOriginalAmount").cast(DecimalType(25,0)).alias("Total_Defaulted_amount"),
                            sum("PastDueBalance").cast(DecimalType(25,0)).alias("Total_PastDue_amount")
                            )
                            dfVersion.show(2)
        dfVersion
     }.foldLeft(emptyDF)(_ union _)
    spark.stop()
   
             
      unionDF.write.format("com.crealytics.spark.excel")
                //.option("sheetName", "Sheet_1")
                //.option("dataAddress","Sheet_1")
                //.option("useHeader", "true")
                .option("header", "true")
                //.option("treatEmptyValuesAsNulls", "false")
                .option("dateFormat", "MM/DD/yyyy")
               //  .option("addColorColumns", "False")
                .mode("overwrite")
                .save(outputPath)
    spark.stop()
      
  }
}
