package com.fds.qcl

import org.apache.spark.sql.SparkSession
import io.delta.tables._
import io.delta._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.commons.io.FileUtils
import java.io.File
import org.apache.log4j._

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
import utils.SimahRuleChecker._

//import utils.QCLInputParams2._


object QCLHistroyLoader_V3
{
	def historyLoader(spark : SparkSession,FILE_NAME:String , params:utils.QCLInputParams2, log:Logger): Unit = {
			Logger.getLogger("org").setLevel(Level.ERROR)
				val schema_hist_updated = StructType(Seq(
					StructField("MemberID" , IntegerType , nullable = true),
					StructField("SalaryAssignment" , StringType , nullable = true),
					StructField("SecurityType" , StringType , nullable = true),
					StructField("ACHDTAID" , StringType , nullable = true),
					StructField("AccountNumber" , StringType , nullable = true),
					StructField("ProductType" , StringType , nullable = true),
					StructField("PaymentFrequency" , StringType , nullable = true),
					StructField("IssueDate" , DateType , nullable = true),
					StructField("ExpiryDate" , DateType , nullable = true),
					StructField("AsOfDate" , DateType , nullable = true),
					StructField("CloseDate" , DateType , nullable = true),
					StructField("ProductStatus" , StringType , nullable = true),
					StructField("PaymentStatus" , StringType , nullable = true),
					StructField("Tenure" , IntegerType , nullable = true),
					StructField("InstallmentAmount" , DoubleType , nullable = true),
					StructField("OriginalAmount" , DoubleType , nullable = true),
					StructField("OutStandingBalance" , DoubleType , nullable = true),
					StructField("LastCycleID" , IntegerType , nullable = true),
					StructField("LastAmountPaid" , DoubleType , nullable = true),
					StructField("LastPaymentDate" , DateType , nullable = true),
					StructField("NextPaymentDate" , DateType , nullable = true),
					StructField("PastDueBalance" , DoubleType , nullable = true),
					StructField("CIUploadDate" , DateType , nullable = true),
					StructField("CIUpdateDate" , DateType , nullable = true),
					StructField("ACHCRTDAT" , StringType , nullable = true),
					StructField("ACHCHGDAT" , StringType , nullable = true),
					StructField("ACYCRTDAT" , StringType , nullable = true),
					StructField("ACYCHGDAT" , StringType , nullable = true),
					StructField("DefaultStatus" , StringType , nullable = true),
					StructField("DefaultLoadDate" , DateType , nullable = true),
					StructField("DefaultOriginalAmount" , DoubleType , nullable = true),
					StructField("DefaultOutStandingAmount" , DoubleType , nullable = true),
					StructField("DefaultStatusDate" , DateType , nullable = true),
					StructField("DefaultChangeDate" , DateType , nullable = true),
					StructField("CreationDate" , DateType , nullable = true)
					// StructField("CurrentStatus" , StringType , nullable = true) //derived column
					))
			val BaseTablePath= params.DELTA_TABLE_PATH_BASE //"C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/"
			val BaseHistTableName=params.DELTA_TABLE_NAME_BASE // "base_hist"
			val BaseHistRawTableName=params.DELTA_TABLE_NAME_BASERAW //"base_hist_raw"
			//Start of run control table creation block
			val controlTableName=params.DELTA_TABLE_NAME_CONTROL //"exe_control_table"
			val controlTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$controlTableName` (
			|KEY1 STRING,
			|KEY2 STRING,
			|FILENAME STRING,
			|RUNDATE DATE,
			|RUNTIMESTAMP TIMESTAMP,
			|RUNNUMBER INT,
			|FILETYPE STRING,
			|FILEPRODUCT STRING,
			|COUNT_INFILE_REC INT,
			|COUNT_OUTFILE_REC INT,
			|COUNT_REJ_SDVL INT,
			|COUNT_REJ_SIMAH INT,
			|COUNT_REJ_TOTAL INT,
			|COUNT_REJ_EXTRA INT,
			|COUNT_REJ_MISSING INT,
			|COUNT_ACCTS_NEW INT,
			|COUNT_DQ_REC INT,
			|RESP_STS_SDVL STRING,
			|RESP_STS_SIMAH STRING
			)  USING DELTA""".stripMargin
			//
			val insertSql=s"""INSERT INTO delta.`$BaseTablePath$controlTableName` VALUES
			('DEF0000021PLN','DEFPLN','',null,null,21,'DEF','PLN', 0,0,0,0,0,0,0,0,0,'OK','OK') ,
			|('DEF0000022CRC','DEFCRC','',null,null,22,'DEF','CRC', 0,0,0,0,0,0,0,0,0,'OK','OK') ,
			|('DEF0000023VLS','DEFVLS','',null,null,23,'DEF','VLS', 0,0,0,0,0,0,0,0,0,'OK','OK') ,
			|('REG0000011PLN','REGPLN','',null,null,11,'REG','PLN', 0,0,0,0,0,0,0,0,0,'OK','OK'),
			|('REG0000012CRC','REGCRC','',null,null,12,'REG','CRC', 0,0,0,0,0,0,0,0,0,'OK','OK'),
			|('REG0000013VLS','REGVLS','',null,null,13,'REG','VLS', 0,0,0,0,0,0,0,0,0,'OK','OK')""".stripMargin
			//Insert records in to control table
			// spark.sql(insertSql)                     
			try {
				val tablePath = new File(BaseTablePath)
						if (tablePath.exists())
						{
						  try
						  {
							println("Creating  execution control table in path: "+ s"$BaseTablePath"  )
							log.info("Creating  execution control table in path: "+ s"$BaseTablePath")
							spark.sql(controlTableCreateSql)
							println(s"Execution control table : $controlTableName  created")
							log.info(s"Execution control table : $controlTableName  created")
							spark.sql(insertSql)
							println(s"Inserted initial records in execution control table  : $controlTableName")
							log.info(s"Inserted initial records in execution control table  : $controlTableName")
						  }
						  catch{
						    case e:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
		            	println("Table: "+ s"$BaseTablePath$controlTableName" + " is already Exists , Skipping control table creation step ...")
		            	log.warn("Table: "+ s"$BaseTablePath$controlTableName" + " is already Exists , Skipping control table creation step ...")
						       case e: Exception => 
						         println("Exception caught while creating Execution control table")
						         log.error("Exception caught while creating Execution control table")
						         e.printStackTrace()
					  }
						}
						else
						{
							println("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
							println("Usage: Re-execute the program by changing  control table path value in configuration file ..")
							log.error("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
							log.info("Re-execute the program by changing  control table path value in configuration file ..")
							//System.exit(1)
						}
			}
			catch {
			
			// println("Usage: Re-execute the program by changing  control table name value in parameter file ..")
			//System.exit(1)
			case e: Exception =>
			println("Error : Exception caught in control table creation block")
			log.error("Exception caught in control table creation block")
			log.error(e)
			}
			//End of run control table creation block
			val baseTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$BaseHistTableName` (
					|AccountNumber STRING,
					|ProductType STRING,
					|SalaryAssignment STRING,
					|SecurityType STRING,
					|PaymentFrequency STRING,
					|IssueDate Date,
					|ExpiryDate Date,
					|AsOfDate Date,
					|CloseDate Date,
					|ProductStatus STRING,
					|PaymentStatus STRING,
					|Tenure INT,
					|InstallmentAmount DOUBLE,
					|OriginalAmount DOUBLE,
					|OutStandingBalance DOUBLE,
					|LastCycleID INT,
					|LastAmountPaid DOUBLE,
					|LastPaymentDate Date,
					|NextPaymentDate Date,
					|PastDueBalance DOUBLE,
					|DefaultStatus STRING,
					|DefaultLoadDate Date,
					|DefaultOriginalAmount DOUBLE,
					|DefaultOutStandingAmount DOUBLE,
					|DefaultStatusDate Date,
					|DefaultChangeDate Date,
					|CIUploadDate Date,
					|CIUpdateDate Date,
					|CurrentStatus STRING,
					|ReportedDate Date,
					|DPR INT,
					|DPA INT,
					|RJC INT
					)  USING DELTA""".stripMargin//.replaceAll("\n", "")
					val baseRawTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$BaseHistRawTableName` (
					|MemberID INT,
					|SalaryAssignment STRING,
					|SecurityType STRING,
					|ACHDTAID STRING,
					|AccountNumber STRING,
					|ProductType STRING,
					|PaymentFrequency STRING,
					|IssueDate Date,
					|ExpiryDate Date,
					|AsOfDate Date,
					|CloseDate Date,
					|ProductStatus STRING,
					|PaymentStatus STRING,
					|Tenure INT,
					|InstallmentAmount DOUBLE,
					|OriginalAmount DOUBLE,
					|OutStandingBalance DOUBLE,
					|LastCycleID INT,
					|LastAmountPaid DOUBLE,
					|LastPaymentDate Date,
					|NextPaymentDate Date,
					|PastDueBalance DOUBLE,
					|CIUploadDate Date,
					|CIUpdateDate Date,
					|ACHCRTDAT STRING,
					|ACHCHGDAT STRING,
					|ACYCRTDAT STRING,
					|ACYCHGDAT STRING,
					|DefaultStatus STRING,
					|DefaultLoadDate Date,
					|DefaultOriginalAmount DOUBLE,
					|DefaultOutStandingAmount DOUBLE,
					|DefaultStatusDate Date,
					|DefaultChangeDate Date,
					|CreationDate Date)  USING DELTA""".stripMargin//.replaceAll("\n", "")
					try {
						val tablePath = new File(BaseTablePath)
								if (tablePath.exists())
								{
									println("creating  base raw table in path: "+ s"$BaseTablePath" )
									log.info("Creating  base raw table in path: "+ s"$BaseTablePath" )
									spark.sql(baseRawTableCreateSql)
									println(s"Base raw table : $BaseHistTableName+_raw created")
									log.info(s"Base raw table : $BaseHistTableName+_raw created")
									
								}
								else
								{
									println("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
									println("Usage: Re-execute the program by changing  base table path value in parameter file ..")
									log.error("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
									log.info("Usage: Re-execute the program by changing  base table path value in parameter file ..")
									System.exit(1)
								}
					}
			catch {
			case e:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
			println("Usage:Table: "+ s"$BaseTablePath$BaseHistRawTableName" + " is already Exists ,  exiting the program......")
			println("Usage: Re-execute the program by changing  base table name value in parameter file ..")
			log.error("Usage:Table: "+ s"$BaseTablePath$BaseHistRawTableName" + " is already Exists ,  exiting the program......")
			log.info("Usage: Re-execute the program by changing  base table name value in parameter file ..")
			log.error(e)
			System.exit(1)
			case e: Exception =>
			println("Error : Exception caught in base table creation block")
			log.error("Error : Exception caught in base table creation block")
			e.printStackTrace()
			}
			
								try {
						val tablePath = new File(BaseTablePath)
								if (tablePath.exists())
								{
									log.info("creating  base table in path: "+ s"$BaseTablePath" )
									spark.sql(baseTableCreateSql)
									log.info(s"Base table : $BaseHistTableName  is created")
								}
								else
								{
									log.error("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
									log.info("Usage: Re-execute the program by changing  base table path value in parameter file ..")
									System.exit(1)
								}
					}
			catch {
			case e:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
			log.error("Usage:Table: "+ s"$BaseTablePath$BaseHistTableName" + " is already Exists , , exiting the program......")
			log.error(e)
			log.info("Usage: Re-execute the program by changing  base table name value in parameter file ..")
			System.exit(1)
			case e: Exception =>
			log.error("Error : Exception caught in base table creation block")
			log.error(e)
			e.printStackTrace()
			}
			//   FileUtils.deleteDirectory(tablePath)
			//Read data from CSV and load it to Delta table
			val HistoryFilePath=params.INPUT_FILE_HISTDATA_PATH //"C:/Bigdata/QCL_EXECUTION/input/" 
			
					val HistoryFileName=FILE_NAME//"PLN_HISTDATA_13170.csv"//"119_ReconiliationFile_20220529.csv"
					//val df = spark.read.option("header",true).option("inferSchema", "false").schema(schema_hist_updated).csv(HistoryFilePath)
					try {
						val FolderPath = new File(HistoryFilePath)
								if (FolderPath.exists() && FolderPath.isDirectory())
								{
									println("Path: "+ s"$HistoryFilePath" + " Exists checking for files" )
									// val a=FileUtils.listFiles(HistoryFilePath, HistoryFileName)//, dirFilter)(new File(HistoryFilePath+HistoryFileName))
									val FileName = new File(HistoryFilePath+HistoryFileName)
									if(FileName.exists() && FileName.isFile())
									{
										log.info("File :" + FileName.getAbsolutePath + " is available started loading the file..")
										val HistoryDF = spark.sqlContext.read.format("csv").option("header", "true").option("inferSchema", "false")
										.schema(schema_hist_updated)//  .option("delimiter", " ")
										.load(HistoryFilePath+HistoryFileName)
										HistoryDF.show()
										log.info(s"Data load started to Base raw table : $BaseTablePath$BaseHistRawTableName ")
										//HistoryDF.printSchema()
										// Write the data to delta target table.
										HistoryDF.write.format("delta").mode("overwrite").save(BaseTablePath+BaseHistRawTableName) //.save("E:/Murali/bigdata_folder/DataProfiling/deltalake/warehouse/hist_delta_table")
										log.info(s"Data load completed to Base raw table : $BaseTablePath$BaseHistRawTableName ")
									}
									else
									{
										log.error(s"File: $FileName is not available  exiting the program ...")
										log.info(s"Usage: dropping the table $BaseTablePath$BaseHistRawTableName ..")
										FileUtils.deleteDirectory(new File(s"$BaseTablePath$BaseHistRawTableName"))
										//spark.sql(s"DROP TABLE IF EXISTS `$BaseTablePath$BaseHistRawTableName`")
										log.info(s"Usage: Droppped the table $BaseTablePath$BaseHistRawTableName ..")
										log.info(s"Usage: dropping the table $BaseTablePath$BaseHistTableName ..")
										FileUtils.deleteDirectory(new File(s"$BaseTablePath$BaseHistTableName"))
										//spark.sql(s"DROP TABLE IF EXISTS `$BaseTablePath$BaseHistTableName`")
										log.info(s"Usage: Droppped the table $BaseTablePath$BaseHistTableName ..")
										log.error("Usage: Re-execute the program by changing  history file path and/or name value in parameter file ..")
										System.exit(1)
									}
								}
								else
								{
									log.error("Path: "+ s"HistoryFilePath" + " is Not Exists exiting the program ...")
									log.info(s"Usage: dropping the table $BaseTablePath$BaseHistRawTableName ..")
									FileUtils.deleteDirectory(new File(s"$BaseTablePath$BaseHistRawTableName"))
									//spark.sql(s"DROP TABLE IF EXISTS `$BaseTablePath$BaseHistRawTableName`")
									log.info(s"Usage: Droppped the table $BaseTablePath$BaseHistRawTableName ..")
									log.info(s"Usage: dropping the table $BaseTablePath$BaseHistTableName ..")
									FileUtils.deleteDirectory(new File(s"$BaseTablePath$BaseHistTableName"))
									//spark.sql(s"DROP TABLE IF EXISTS `$BaseTablePath$BaseHistTableName`")
									log.info(s"Usage: Droppped the table $BaseTablePath$BaseHistTableName ..")
									log.error("Usage: Re-execute the program by changing  history file path value in parameter file ..")
									System.exit(1)
								}
					}
			catch {
				//case e:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
				//println("Table: "+ s"$BaseTablePath$BaseHistRawTableName" + " is already Exists , exiting the program ...")
				//println("Usage: Re-execute the program by changing  base table name value in parameter file ..")
			case e: Exception =>
			log.error("Error : Exception caught in history file load block")
			log.error(e)
			}
			val tempDF =spark.sql(s"SELECT * FROM delta.`$BaseTablePath$BaseHistRawTableName`").na.fill("")
					tempDF.show()
					log.info(s"Total records loaded in base history raw table $BaseHistRawTableName :" + tempDF.count())
					try
			{
						import spark.implicits._
						val currentTime=new java.sql.Timestamp(System.currentTimeMillis())
						val hist_base_DF=tempDF
						.withColumn("IssueDate", when('IssueDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('IssueDate))
						.withColumn("ExpiryDate", when('ExpiryDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('ExpiryDate))
						.withColumn("CloseDate", when('CloseDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('CloseDate))
						.withColumn("LastPaymentDate", when('LastPaymentDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('LastPaymentDate))
						.withColumn("NextPaymentDate", when('NextPaymentDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('NextPaymentDate))
						.withColumn("DefaultLoadDate", when('DefaultLoadDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultLoadDate))
						.withColumn("DefaultStatusDate", when('DefaultStatusDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultStatusDate))
						.withColumn("DefaultChangeDate", when('DefaultChangeDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultChangeDate)).withColumn("CurrentStatus", when('DefaultStatus =!= "NULL" && ('DefaultStatus==="FS" || 'DefaultStatus==="NS") , lit("SETTLED"))
								.when('ProductStatus =!= "NULL" && 'ProductStatus==="C"  , lit("CLOSED"))
								.when('ProductStatus=!= "NULL" && 'ProductStatus==="A" && 'DefaultStatus==="NULL" , lit("ACTIVE"))
								.when('ProductStatus =!= "NULL" && 'ProductStatus==="S"  && 'DefaultStatus === "NULL" , lit("SUSPENDED"))
								.when('ProductStatus =!= "NULL"  && 'ProductStatus==="W"  && ('DefaultStatus === "NULL" || 'DefaultStatus==="OS" || 'DefaultStatus==="PP") , lit("WRITTENOFF"))
								.when('DefaultStatus =!= "NULL" && 'DefaultStatus==="RS"  , lit("CLOSED"))
								.otherwise('ProductStatus))
						.withColumn("ReportedDate", coalesce('DefaultStatusDate, 'CIUpdateDate))
						.withColumn("currentDate", current_date())
						.withColumn("DPR",datediff('currentDate, coalesce('DefaultStatusDate, 'CIUpdateDate)))
						.withColumn("DPA",datediff('currentDate, coalesce('DefaultStatusDate, 'CIUpdateDate)))
						// .withColumn("DPR",  expr(s" (( $currentTime - CIUploadDate.getTime() ) / (60 * 60 * 1000 *24))"))//                    lit(null).cast(IntegerType))
						// .withColumn("DPR",  expr(s" (($currentTime - CIUploadDate.getTime() ) / (60 * 60 * 1000 *24))"))
						//  .withColumn("x", getTimeDifference('CIUploadDate,new java.sql.Timestamp(System.currentTimeMillis())))
						//.withColumn("DPA",  lit(null).cast(IntegerType))
						.withColumn("RJC", lit(0).cast(IntegerType))
						.select('AccountNumber,'ProductType,'SalaryAssignment,'PaymentFrequency,'SecurityType,'IssueDate,'ExpiryDate,
								'AsOfDate,'CloseDate,'ProductStatus,'PaymentStatus,'Tenure,'InstallmentAmount,
								'OriginalAmount,'OutStandingBalance,'LastCycleID,'LastAmountPaid,'LastPaymentDate,
								'NextPaymentDate,'PastDueBalance,'DefaultStatus,'DefaultLoadDate,'DefaultOriginalAmount,
								'DefaultOutStandingAmount,'DefaultStatusDate,'DefaultChangeDate,'CIUploadDate,
								'CIUpdateDate,'CurrentStatus,'ReportedDate,'DPR,'DPA,'RJC)
						hist_base_DF.show()
						//		log.info(hist_base_DF.show() )
						//Test
						hist_base_DF.groupBy('CurrentStatus,'ProductStatus,'DefaultStatus).agg(count('AccountNumber).as("TotalAccts")).show()
						hist_base_DF.write.format("delta").mode("overwrite").save(BaseTablePath+BaseHistTableName)
						// val HistBaseDS=hist_base_DF.as[HistBaseCaseClass]
						val HistBaseDS=spark.sql(s"SELECT * FROM delta.`$BaseTablePath$BaseHistTableName`").as[HistBaseCaseClass]
								log.info(s"Total records loaded in base history table $BaseHistTableName : "+ HistBaseDS.count())
							//	HistBaseDS.printSchema()
								//println("TestFlow: function call def:getHistoryDQReport")
								//Funcation call
								val HistDQDS= for
								{
									row <- HistBaseDS
									//getInvalidRecords
									val rows=getHistoryDQReport(row.AccountNumber           ,
											row.ProductType             ,
											row.SalaryAssignment        ,
											row.SecurityType            ,
											row.PaymentFrequency       ,
											row.IssueDate               ,
											row.ExpiryDate              ,
											row.AsOfDate                ,
											row.CloseDate               ,
											row.ProductStatus           ,
											row.PaymentStatus           ,
											row.Tenure                  ,
											row.InstallmentAmount       ,
											row.OriginalAmount          ,
											row.OutStandingBalance      ,
											row.LastCycleID             ,
											row.LastAmountPaid          ,
											row.LastPaymentDate         ,
											row.NextPaymentDate         ,
											row.PastDueBalance          ,
											row.DefaultStatus           ,
											row.DefaultLoadDate         ,
											row.DefaultOriginalAmount   ,
											row.DefaultOutStandingAmount,
											row.DefaultStatusDate       ,
											row.DefaultChangeDate       ,
											row.CIUploadDate            ,
											row.CIUpdateDate            ,
											row.CurrentStatus           ,
											row.ReportedDate            ,
											row.DPR                     ,
											row.DPA                     ,
											row.RJC                     )
								} yield rows
								val HistDQDF=  HistDQDS.filter(col("ValidFlag")=!=("VALID")).toDF()
								//println("TestFlow: return from function , got HistDQDS and filterd output to HistDQDF")
								//HistDQDF.printSchema()
								//log.info(HistDQDF.show())
							try
								{
								  val histDQSummaryDF= HistDQDF.groupBy('ErrorIDs).agg(count('AccountNumber).as("TotalAccts"))
									val tmpFolderName=BaseTablePath+"HistDQReport_Summary"
									val outputPath=params.OUTPUT_FILE_REPORTS_PATH
									val newfileName="HistDQReport_Summary_"+FILE_NAME//+".csv"
									log.info("Usage : Start : Saving the History Data Quality Summary report")
									histDQSummaryDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(tmpFolderName)
									moveFiles(tmpFolderName,outputPath, newfileName)
									log.info("Usage : End : Saved the file with name : " + outputPath + newfileName)
									}
							 catch{
									case e: Exception =>
									log.error("Error : Exception caught while saving SummaryHistDQReport ")
									log.error(e)
									}

							 	try
								{
								  val HistDQReport=HistDQDF.join(hist_base_DF, Seq("AccountNumber","ProductType") , "inner")
									val tmpFolderName=BaseTablePath+"HistDQReport_Detail"
									val outputPath=params.OUTPUT_FILE_REPORTS_PATH
									val newfileName="HistDQReport_Detail_"+FILE_NAME//+".csv"
									log.info("Usage : Start : Saving the History Data Quality Detail report")
									HistDQReport.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(tmpFolderName)
									moveFiles(tmpFolderName,outputPath, newfileName)
									log.info("Usage : End : Saved the file with name : " + outputPath + newfileName)
									}
							 catch{
									case e: Exception =>
									log.error("Error : Exception caught while saving DetailHistDQReport ")
									log.error(e)
									}
			}
			catch {
			case e: Exception =>
			log.error("Error : Exception caught in base history table load block")
			log.error(e)
			}
			
	}
}