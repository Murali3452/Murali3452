package com.fds.qcl


import io.delta.tables._
import io.delta._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import java.time.format.DateTimeFormatter
import java.time._


import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
//import utils.InputParams2._
import utils.ConfigParams._
import com.crealytics.spark.excel._

object QCLManualDataProcessor_V6 {
  
 val manual_update_schema_regularfile = StructType(Seq(
      StructField("AccountNumber", StringType, nullable = true),
      StructField("IssueDate", DateType, nullable = true),
      StructField("ProductType", StringType, nullable = true),
      StructField("OriginalAmount", DoubleType, nullable = true),
      StructField("SalaryAssignmentFlag", StringType, nullable = true),
      StructField("ExpiryDate", DateType, nullable = true),
      StructField("ProductStatus", StringType, nullable = true),
      StructField("InstallmentAmount", DoubleType, nullable = true),
      StructField("PaymentFrequency", StringType, nullable = true),
      StructField("Tenure", IntegerType, nullable = true),
      StructField("SecurityType", StringType, nullable = true),
      StructField("SubProductType", StringType, nullable = true),
      StructField("LastCycleID", IntegerType, nullable = true),
      StructField("LastPaymentDate", DateType, nullable = true),
      StructField("LastAmountPaid", DoubleType, nullable = true),
      StructField("PaymentStatus", StringType, nullable = true),
      StructField("OutStandingBalance", DoubleType, nullable = true),
      StructField("PastDueBalance", DoubleType, nullable = true),
      StructField("AsOfDate", DateType, nullable = true),
      StructField("NextPaymentDate", DateType, nullable = true),
      StructField("IDType", StringType, nullable = true),
      StructField("IDNumber", StringType, nullable = true),
      StructField("ApplicantType", StringType, nullable = true),
      StructField("MU_RequestorId", StringType, nullable = true),
      StructField("MU_RequestorEmail", StringType, nullable = true),
      StructField("MU_Reason", StringType, nullable = true),
      StructField("MU_RequestedDate", DateType, nullable = true)))
      
 val manual_update_schema_defaultfile = StructType(Seq(
      StructField("AccountNumber", StringType, nullable = true),
      StructField("ProductType", StringType, nullable = true),
      StructField("DefaultStatus", StringType, nullable = true),
      StructField("OutStandingBalance", DoubleType, nullable = true),
      //StructField("AsOfDate", DateType, nullable = true),
      StructField("DefaultStatusDate", DateType, nullable = true),
      StructField("MU_RequestorId", StringType, nullable = true),
      StructField("MU_RequestorEmail", StringType, nullable = true),
      StructField("MU_Reason", StringType, nullable = true),
      StructField("MU_RequestedDate", DateType, nullable = true)))
  
  


 def  getManualDataDF_V6(spark : SparkSession ,params:utils.QCLConfigParams ,log:Logger, RUN_DATE:java.sql.Date,FILE_NAME:String,FILE_TYPE:String ):DataFrame  = {
     
   val manual_update_schema =
                     if(FILE_TYPE.equalsIgnoreCase("REG")) 
                        manual_update_schema_regularfile 
                     else if(FILE_TYPE.equalsIgnoreCase("DEF"))
                       manual_update_schema_defaultfile
                     else
                        StructType(Seq())
   
   
      try
      {
         val excelDF2 = spark.read.format("com.crealytics.spark.excel")
                  .option("inferSchema", "false")
                  .option("treatEmptyValuesAsNulls", "false")
                  .option("header", "true")
                  .option("dateFormat", "MM/DD/yyyy")
                  .schema(manual_update_schema)
                  .load(FILE_NAME)
                  .withColumn("manualUpdateFlag",lit("Y"))
                  
     /* val excelDF2 = spark.read.excel(
                                header=true,
                treatEmptyValuesAsNulls=false
                //.option("inferSchema", "true")
                 //.option("addColorColumns", "False")
                ).schema(manual_update_schema)
                
                .load(FILE_NAME)
                .withColumn("manualUpdateFlag",lit("Y"))
        */      
       excelDF2.printSchema()
       excelDF2.show(false)
       
       excelDF2 
  
      }
      catch
      {
        case e:Exception => e.printStackTrace()
        null
      }
      
   }    
 
       
   def  writeManualDataXML_V6(spark : SparkSession ,params:utils.QCLConfigParams ,log:Logger, df:DataFrame,FILE_NAME:String,FILE_TYPE:String ):String  = 
   {
      val outFilePath=params.OUTPUT_FILE_XMLREQUET_PATH
      val tablePath=params.DELTA_TABLE_PATH_WORKING
      val fileName=getFileName(FILE_NAME)
      //println("fileName:"+fileName)
      val fileNameWOext=fileName.slice(0, fileName.lastIndexOf("."))
      val xmlFileName=fileNameWOext+".xml"
      val manualUpdateTable=tablePath+fileNameWOext
      val manualUpdateXMLfilePath=outFilePath+xmlFileName
      
         deleteFolder3(manualUpdateTable)
    
    val tempTableSQL = s"""CREATE OR REPLACE TABLE delta.`$manualUpdateTable` ( 
        AccountNumber STRING ,
        |IssueDate Date,
        |ProductType STRING,
        |OriginalAmount DOUBLE,
        |SalaryAssignmentFlag STRING ,
        |ExpiryDate Date,
        |ProductStatus STRING,
        |InstallmentAmount DOUBLE,
        |PaymentFrequency STRING,
        |Tenure INT,
        |SecurityType STRING,
        |SubProductType STRING,
        |LastCycleID INT,
        |LastPaymentDate Date,
        |LastAmountPaid DOUBLE,
        |PaymentStatus STRING,
        |OutStandingBalance DOUBLE,
        |PastDueBalance DOUBLE,
        |AsOfDate Date,
        |NextPaymentDate Date,
        |IDType STRING,
        |IDNumber STRING,
        |manualupdateFlag STRING,
        |UpdateUserId STRING,
        |UpdateUserEmail STRING,
        |UpdateReason STRING)  USING DELTA""".stripMargin
        
   
    /*spark.sql(tempTableSQL)*/

    //reqWithRejDetails.write.format("delta").saveAsTable("E:/Murali/bigdata_folder/DataProfiling/Simah/LAKEHOUSE/TEMP/REG0015720PLN")

    //##manualUpdateFileDF.write.format("delta").mode("overwrite").save(manualUpdateTable)
    df.write.format("delta").mode("overwrite").save(manualUpdateTable)

    println(s"inserted data to temp table :$manualUpdateTable")
    

      
     val sqlStr_regularfile="""select '<ACCOUNT>' as account_start_tag,
       '<AREF>' || ACC.AccountNumber || '</AREF>' AS AccountNumber ,
      |CASE WHEN ACC.IssueDate is not null then '<AOPN>' || '<AOPND>' || lpad( date_part('D',ACC.IssueDate) ,2, '0') || '</AOPND>' || '<AOPNM>' || lpad( date_part('MON',ACC.IssueDate) ,2, '0') || '</AOPNM>' || '<AOPNY>' || date_part('YEAR',ACC.IssueDate)  || '</AOPNY>' || '</AOPN>' else null END AS IssueDate,
      |'<APRD>' || ACC.ProductType || '</APRD>' AS ProductType,
      |'<ALMT>' || ACC.OriginalAmount || '</ALMT>'  AS OriginalAmount,
      |'<ASAL>' || ACC.SalaryAssignmentFlag || '</ASAL>'AS SalaryAssignmentFlag,
      |CASE WHEN ACC.ExpiryDate is not null then '<AEXP>' || '<AEXPD>' || lpad( date_part('D',ACC.ExpiryDate) ,2, '0') || '</AEXPD>' || '<AEXPM>' || lpad( date_part('MON',ACC.ExpiryDate) ,2, '0') || '</AEXPM>' || '<AEXPY>' || date_part('YEAR',ACC.ExpiryDate)  || '</AEXPY>' || '</AEXP>' else null END AS ExpiryDate,
      |'<APST>' || ACC.ProductStatus || '</APST>' AS ProductStatus,
      |'<AINST>' || ACC.InstallmentAmount || '</AINST>' AS InstallmentAmount,
      |'<AFRQ>' || ACC.PaymentFrequency || '</AFRQ>' AS PaymentFrequency,
      |'<ATNR>' || ACC.Tenure || '</ATNR>' AS Tenure,
      |'<ASEC>' || ACC.SecurityType || '</ASEC>' AS SecurityType,
      |'<ADWNP>' || '0' || '</ADWNP>' AS DownPayment,
      |'<ABPAY>' || '0' || '</ABPAY>' AS BalloonPayment,
      |'<ADAMT>' || '0' || '</ADAMT>' AS DispensedAmount,
      |'<AMAX>' || '0' || '</AMAX>' AS MaxInstallmentAmount,
      |CASE WHEN ACC.SubProductType IS NOT NULL THEN '<ASP>' || ACC.SubProductType  || '</ASP>' ELSE NULL END AS SubProductType,
      |'<ACON>' || '1' || '</ACON>' AS NumberOfApplicants,
      |'<ACYC>' as cycle_start_tag,
      |'<ACYCID>' || ACC.LastCycleID || '</ACYCID>'  AS LastCycleID,
      |CASE WHEN ACC.LastPaymentDate is not null then '<ALSPD>' || '<ALSPDD>' || lpad( date_part('D',ACC.LastPaymentDate) ,2, '0') || '</ALSPDD>' || '<ALSPDM>' || lpad( date_part('MON',ACC.LastPaymentDate) ,2, '0') || '</ALSPDM>' || '<ALSPDY>' || date_part('YEAR',ACC.LastPaymentDate)  || '</ALSPDY>' || '</ALSPD>' else null END AS LastPaymentDate,
      |'<ALSTAM>' || nvl(ACC.LastAmountPaid,'') || '</ALSTAM>' AS LastAmountPaid,
      |'<AACS>' || ACC.PaymentStatus || '</AACS>' AS PaymentStatus,
      |'<ACUB>' || ACC.OutStandingBalance || '</ACUB>' AS OutStandingBalance,
      |'<AODB>' || ACC.PastDueBalance || '</AODB>' AS PastDueBalance,
      |CASE WHEN ACC.AsOfDate is not null then '<AASOF>' || '<AASOFD>' || lpad( date_part('D',ACC.AsOfDate) ,2, '0') || '</AASOFD>' || '<AASOFM>' || lpad( date_part('MON',ACC.AsOfDate) ,2, '0') || '</AASOFM>' || '<AASOFY>' || date_part('YEAR',ACC.AsOfDate)  || '</AASOFY>' || '</AASOF>' else null END AS AsOfDate,
      |CASE WHEN ACC.NextPaymentDate is not null then '<ANXPD>' || '<ANXPDD>' || lpad( date_part('D',ACC.NextPaymentDate) ,2, '0') || '</ANXPDD>' || '<ANXPDM>' || lpad( date_part('MON',ACC.NextPaymentDate) ,2, '0') || '</ANXPDM>' || '<ANXPDY>' || date_part('YEAR',ACC.NextPaymentDate)  || '</ANXPDY>' || '</ANXPD>' else null END  AS NextPaymentDate , 
      |'</ACYC>'  as cycle_end_tag,
      |'<CONSUMER>' AS consumer_start_tag ,
      |'<CID>' AS ID_start_tag,
      |'<CID1>' || ACC.IDType || '</CID1>' AS IDType,
      |'<CID2>' || ACC.IDNumber || '</CID2>' AS IDNumber,
      |'</CID>' AS ID_end_tag,
      |'<CAPL>' || ACC.ApplicantType || '</CAPL>' AS ApplicantType,
      |'</CONSUMER>' AS consumer_end_tag,
      | '</ACCOUNT>'  as account_end_tag  """.stripMargin
    
      val sqlStr_defaultfile="""select '<BAD_DEBT>' as BAD_DEBT_START_TAG,
      |'<BAL>' || ACC.OutStandingBalance || '</BAL>' AS OutStandingBalance,
      |'<PREF>' || ACC.AccountNumber || '</PREF>' AS AccountNumber ,
      |'<PPRD>' || ACC.ProductType || '</PPRD>' AS ProductType,
      |'<STS>' || ACC.DefaultStatus || '</STS>' AS DEFAULTStatus,
      |CASE WHEN ACC.DefaultStatusDate is not null then '<STSDATE>' || '<STSDAY>' || lpad( date_part('D',ACC.DefaultStatusDate) ,2, '0') || '</STSDAY>' || '<STSMON>' || lpad( date_part('MON',ACC.DefaultStatusDate) ,2, '0') || '</STSMON>' || '<STSYEAR>' || date_part('YEAR',ACC.DefaultStatusDate)  || '</STSYEAR>' || '</STSDATE>' else null END AS DefaultStatusDate,
      | '</BAD_DEBT>'  as BAD_DEBT_END_TAG  """.stripMargin
 
      
      val sqlStr_V4 = if(FILE_TYPE.equalsIgnoreCase("REG")) 
                        sqlStr_regularfile 
                     else if(FILE_TYPE.equalsIgnoreCase("DEF"))
                       sqlStr_defaultfile
                     else
                       ""
      
    //val xmlDataDF=spark.sql(s"$sqlStr  FROM delta.`$manualUpdateTable` as ACC")
      val xmlDataDF=spark.sql(s"$sqlStr_V4  FROM delta.`$manualUpdateTable` as ACC")
    
    xmlDataDF.printSchema()
    xmlDataDF.show()
    
    val allColumns=xmlDataDF.columns.map(m=>col(m))
    try
    {
      import spark.implicits._
      val xmlStringArray=xmlDataDF.select(allColumns:_*).collect() //.toList.foreach(f => f.getList(0)) //.map { row => row}
      val bufferWrite = new PrintWriter(new FileOutputStream(new File(manualUpdateXMLfilePath), true))
       println("Xml file generation started:"+new java.sql.Timestamp(System.currentTimeMillis()))
       println(s"FilePath: $manualUpdateXMLfilePath ")
     // var row=Array([String])
      for(i <- 0 until xmlStringArray.length)
      {
        val row =xmlStringArray(i)
        for(j <- 0 until row.length )
        {
          val tag=row(j)
          if(tag != null)
          bufferWrite.write(tag + "\n")
        }
        //
      }
      bufferWrite.close()
      println(s"XML file generation completed:"+new java.sql.Timestamp(System.currentTimeMillis()))
      manualUpdateXMLfilePath
    }
    catch 
    {
      case e:Exception => e.printStackTrace()
      ""
    }
  }
    
 
}