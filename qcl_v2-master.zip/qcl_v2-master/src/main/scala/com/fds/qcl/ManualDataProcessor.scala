package com.fds.qcl

import io.delta.tables._
import io.delta._

import com.crealytics.spark.excel._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import java.time.format.DateTimeFormatter
import java.time._
 
 
import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
//import utils.InputParams2._
import utils.ConfigParams._


 
object ManualDataProcessor {
 
   def  getManualDataDF(spark : SparkSession ,params:utils.QCLConfigParams ,log:Logger, RUN_DATE:java.sql.Date,FILE_NAME:String ):Dataset[RegularRequestXMLMapClass_V4]  = {
    
      val manual_update_schema = StructType(Seq(
      StructField("AccountNumber", StringType, nullable = true),
      StructField("IssueDate", DateType, nullable = true),
      StructField("ProductType", StringType, nullable = true),
      StructField("OriginalAmount", DoubleType, nullable = true),
      StructField("SalaryAssignmentFlag", StringType, nullable = true),
      StructField("ExpiryDate", DateType, nullable = true),
      StructField("ProductStatus", StringType, nullable = true),
      StructField("InstallmentAmount", DoubleType, nullable = true),
      StructField("PaymentFrequency", StringType, nullable = true),
      StructField("Tenure", IntegerType, nullable = true),
      StructField("SecurityType", StringType, nullable = true),
      StructField("SubProductType", StringType, nullable = true),
      StructField("LastCycleID", IntegerType, nullable = true),
      StructField("LastPaymentDate", DateType, nullable = true),
      StructField("LastAmountPaid", DoubleType, nullable = true),
      StructField("PaymentStatus", StringType, nullable = true),
      StructField("OutStandingBalance", DoubleType, nullable = true),
      StructField("PastDueBalance", DoubleType, nullable = true),
      StructField("AsOfDate", DateType, nullable = true),
      StructField("NextPaymentDate", DateType, nullable = true),
      StructField("IDType", StringType, nullable = true),
      StructField("IDNumber", StringType, nullable = true),
      StructField("ApplicantType", StringType, nullable = true),
      StructField("MU_RequestorId", StringType, nullable = true),
      StructField("MU_RequestorEmail", StringType, nullable = true),
      StructField("MU_Reason", StringType, nullable = true),
      StructField("MU_RequestedDate", StringType, nullable = true)
      ))
     // StructField("UpdateUserId", StringType, nullable = true),
     // StructField("UpdateUserEmail", StringType, nullable = true),
      //StructField("UpdateReason", StringType, nullable = true)))
    //manualUpdateFilePath
    
      try
      {
      val excelDF2 = spark.read.excel(
                                header=true,
                treatEmptyValuesAsNulls=false
                //.option("inferSchema", "true")
                 //.option("addColorColumns", "False")
                ).schema(manual_update_schema)
                .load(FILE_NAME)
              
       excelDF2.printSchema()
       excelDF2.show(false)
      
       
       
       
       
       import spark.implicits._
       val caseClassDF=excelDF2
                           .withColumn("manualUpdateFlag",lit("Y"))
                           .as[RegularRequestXMLMapClass_V4]
        caseClassDF
      }
      catch
      {
        case e:Exception => e.printStackTrace()
        null
      }
     
   }
  
   def  writeManualDataXML(spark : SparkSession ,params:utils.QCLConfigParams ,log:Logger, df:DataFrame,FILE_NAME:String ):String  =
   {
      val outFilePath=params.OUTPUT_FILE_XMLREQUET_PATH
      val tablePath=params.DELTA_TABLE_PATH_WORKING
      val fileName=getFileName(FILE_NAME)
      println("******************fileName:"+fileName)
      val fileNameWOext=fileName.slice(0, fileName.lastIndexOf("."))
      val xmlFileName=fileNameWOext+".xml"
      val manualUpdateTable=tablePath+fileNameWOext
      val manualUpdateXMLfilePath=outFilePath+xmlFileName
     
         deleteFolder3(manualUpdateTable)
   
    val tempTableSQL = s"""CREATE OR REPLACE TABLE delta.`$manualUpdateTable` (
        AccountNumber STRING ,
        |IssueDate Date,
        |ProductType STRING,
        |OriginalAmount DOUBLE,
        |SalaryAssignmentFlag STRING ,
        |ExpiryDate Date,
        |ProductStatus STRING,
        |InstallmentAmount DOUBLE,
        |PaymentFrequency STRING,
        |Tenure INT,
        |SecurityType STRING,
        |SubProductType STRING,
        |LastCycleID INT,
        |LastPaymentDate Date,
        |LastAmountPaid DOUBLE,
        |PaymentStatus STRING,
        |OutStandingBalance DOUBLE,
        |PastDueBalance DOUBLE,
        |AsOfDate Date,
        |NextPaymentDate Date,
        |IDType STRING,
        |IDNumber STRING,
        |manualupdateFlag STRING,
        |UpdateUserId STRING,
        |UpdateUserEmail STRING,
        |UpdateReason STRING)  USING DELTA""".stripMargin
       
       val tempTableSQL2 = s"""CREATE OR REPLACE TABLE delta.`$manualUpdateTable` (
        AccountNumber STRING ,
        |IssueDate Date,
        |ProductType STRING,
        |OriginalAmount DOUBLE,
        |SalaryAssignmentFlag STRING ,
        |ExpiryDate Date,
        |ProductStatus STRING,
        |InstallmentAmount DOUBLE,
        |PaymentFrequency STRING,
        |Tenure INT,
        |SecurityType STRING,
        |SubProductType STRING,
        |LastCycleID INT,
        |LastPaymentDate Date,
        |LastAmountPaid DOUBLE,
        |PaymentStatus STRING,
        |OutStandingBalance DOUBLE,
        |PastDueBalance DOUBLE,
        |AsOfDate Date,
        |NextPaymentDate Date,
        |IDType STRING,
        |IDNumber STRING,
        |manualupdateFlag STRING)  USING DELTA""".stripMargin
    // manualDF.repartition(1) .write.format("csv").mode("overwrite").option("header", "true").save("E:/Murali/bigdata_folder/DataProfiling/Simah/TestRun2_1_delta/output/MANUALUPDATE/test")
 
    /*spark.sql(tempTableSQL)*/
 
    //reqWithRejDetails.write.format("delta").saveAsTable("E:/Murali/bigdata_folder/DataProfiling/Simah/LAKEHOUSE/TEMP/REG0015720PLN")
 
    //##manualUpdateFileDF.write.format("delta").mode("overwrite").save(manualUpdateTable)
    df.write.format("delta").mode("overwrite").save(manualUpdateTable)
 
    println(s"inserted data to temp table :$manualUpdateTable")
   
         val sqlStr="""select '<ACCOUNT>' as account_start_tag,
       '<AREF>' || ACC.AccountNumber || '</AREF>' AS AccountNumber ,
      |CASE WHEN ACC.IssueDate is not null then '<AOPN>' || '<AOPND>' || lpad( date_part('D',ACC.IssueDate) ,2, '0') || '</AOPND>' || '<AOPNM>' || lpad( date_part('MON',ACC.IssueDate) ,2, '0') || '</AOPNM>' || '<AOPNY>' || date_part('YEAR',ACC.IssueDate)  || '</AOPNY>' || '</AOPN>' else null END AS IssueDate,
      |'<APRD>' || ACC.ProductType || '</APRD>' AS ProductType,
      |'<ALMT>' || ACC.OriginalAmount || '</ALMT>'  AS OriginalAmount,
      |'<ASAL>' || ACC.SalaryAssignmentFlag || '</ASAL>'AS SalaryAssignmentFlag,
      |CASE WHEN ACC.ExpiryDate is not null then '<AEXP>' || '<AEXPD>' || lpad( date_part('D',ACC.ExpiryDate) ,2, '0') || '</AEXPD>' || '<AEXPM>' || lpad( date_part('MON',ACC.ExpiryDate) ,2, '0') || '</AEXPM>' || '<AEXPY>' || date_part('YEAR',ACC.ExpiryDate)  || '</AEXPY>' || '</AEXP>' else null END AS ExpiryDate,
      |'<APST>' || ACC.ProductStatus || '</APST>' AS ProductStatus,
      |'<AINST>' || ACC.InstallmentAmount || '</AINST>' AS InstallmentAmount,
      |'<AFRQ>' || ACC.PaymentFrequency || '</AFRQ>' AS PaymentFrequency,
      |'<ATNR>' || ACC.Tenure || '</ATNR>' AS Tenure,
      |'<ASEC>' || ACC.SecurityType || '</ASEC>' AS SecurityType,
      |'<ADWNP>' || '0' || '</ADWNP>' AS DownPayment,
      |'<ABPAY>' || '0' || '</ABPAY>' AS BalloonPayment,
      |'<ADAMT>' || '0' || '</ADAMT>' AS DispensedAmount,
      |'<AMAX>' || '0' || '</AMAX>' AS MaxInstallmentAmount,
      |CASE WHEN ACC.SubProductType IS NOT NULL THEN '<ASP>' || ACC.SubProductType  || '</ASP>' ELSE NULL END AS SubProductType,
      |'<ACON>' || '1' || '</ACON>' AS NumberOfApplicants,
      |'<ACYC>' as cycle_start_tag,
      |'<ACYCID>' || ACC.LastCycleID || '</ACYCID>'  AS LastCycleID,
      |CASE WHEN ACC.LastPaymentDate is not null then '<ALSPD>' || '<ALSPDD>' || lpad( date_part('D',ACC.LastPaymentDate) ,2, '0') || '</ALSPDD>' || '<ALSPDM>' || lpad( date_part('MON',ACC.LastPaymentDate) ,2, '0') || '</ALSPDM>' || '<ALSPDY>' || date_part('YEAR',ACC.LastPaymentDate)  || '</ALSPDY>' || '</ALSPD>' else null END AS LastPaymentDate,
      |'<ALSTAM>' || ACC.LastAmountPaid || '</ALSTAM>' AS LastAmountPaid,
      |'<AACS>' || ACC.PaymentStatus || '</AACS>' AS PaymentStatus,
      |'<ACUB>' || ACC.OutStandingBalance || '</ACUB>' AS OutStandingBalance,
      |'<AODB>' || ACC.PastDueBalance || '</AODB>' AS PastDueBalance,
      |CASE WHEN ACC.AsOfDate is not null then '<AASOF>' || '<AASOFD>' || lpad( date_part('D',ACC.AsOfDate) ,2, '0') || '</AASOFD>' || '<AASOFM>' || lpad( date_part('MON',ACC.AsOfDate) ,2, '0') || '</AASOFM>' || '<AASOFY>' || date_part('YEAR',ACC.AsOfDate)  || '</AASOFY>' || '</AASOF>' else null END AS AsOfDate,
      |CASE WHEN ACC.NextPaymentDate is not null then '<ANXPD>' || '<ANXPDD>' || lpad( date_part('D',ACC.NextPaymentDate) ,2, '0') || '</ANXPDD>' || '<ANXPDM>' || lpad( date_part('MON',ACC.NextPaymentDate) ,2, '0') || '</ANXPDM>' || '<ANXPDY>' || date_part('YEAR',ACC.NextPaymentDate)  || '</ANXPDY>' || '</ANXPD>' else null END  AS NextPaymentDate ,
      |'</ACYC>'  as cycle_end_tag,
      |'<CONSUMER>' AS consumer_start_tag ,
      |'<CID>' AS ID_start_tag,
      |'<CID1>' || ACC.IDType || '</CID1>' AS IDType,
      |'<CID2>' || ACC.IDNumber || '</CID2>' AS IDNumber,
      |'</CID>' AS ID_end_tag,
      |'<CAPL>' || ACC.ApplicantType || '</CAPL>' AS ApplicantType,
      |'</CONSUMER>' AS consumer_end_tag,
      | '</ACCOUNT>'  as account_end_tag  """.stripMargin
   
    val xmlDataDF=spark.sql(s"$sqlStr  FROM delta.`$manualUpdateTable` as ACC")
   
    xmlDataDF.printSchema()
    xmlDataDF.show()
   
    val allColumns=xmlDataDF.columns.map(m=>col(m))
    try
    {
      import spark.implicits._
      val xmlStringArray=xmlDataDF.select(allColumns:_*).collect() //.toList.foreach(f => f.getList(0)) //.map { row => row}
      val bufferWrite = new PrintWriter(new FileOutputStream(new File(manualUpdateXMLfilePath), true))
       println("Xml file generation started:"+new java.sql.Timestamp(System.currentTimeMillis()))
       println(s"FilePath: $manualUpdateXMLfilePath ")
     // var row=Array([String])
      for(i <- 0 until xmlStringArray.length)
      {
        val row =xmlStringArray(i)
        for(j <- 0 until row.length )
        {
          val tag=row(j)
          if(tag != null)
          bufferWrite.write(tag + "\n")
        }
        //
      }
      bufferWrite.close()
      println(s"XML file generation completed:"+new java.sql.Timestamp(System.currentTimeMillis()))
      manualUpdateXMLfilePath
    }
    catch
    {
      case e:Exception => e.printStackTrace()
      ""
    }
  }
  
   
}