package com.fds.qcl.utils
import SimahCaseClasses._
import java.text.DecimalFormat
import java.sql.Timestamp
import java.sql.Date
import org.apache.spark.sql.functions._
import org.apache.spark._
import org.apache.spark.SparkContext._
import scala.util.Try
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import java.util.regex.Pattern
import scala.util.matching.Regex
import scala.io._
import org.apache.commons.io.FileUtils
//import scala.io.{Source, BufferedSource}
import scala.collection.mutable.LinkedHashSet
import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.ListBuffer
import scala.collection.mutable.ArrayBuffer
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter, BufferedReader, FileReader }
import scala.collection.JavaConversions._
import scala.reflect.io.Directory
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.catalyst.ScalaReflection

object QCLHelperFunctions_V2 {

  val conf = new SparkConf().setAppName("SimahRuleChecker").setMaster("local[*]").set("spark.testing.memory", "2147480000").set("spark.kryoserializer.buffer.max", "512") //local
  val spark = SparkSession.builder.appName("SimahRuleChecker_App").config(conf).getOrCreate() //local

  def isSchemaNested(df: DataFrame): Boolean = {
    df.schema.fields.flatMap(field => {

      field.dataType match {
        case arrayType: ArrayType => {
          Array(true)
        }
        case mapType: MapType => {
          Array(true)
        }
        case structType: StructType => {
          Array(true)
        }
        case _ => {
          Array(false)
        }
      }
    }).exists(b => b)
  }

  private def flattenSchema(schema: StructType, prefix: String = null): Array[Column] = {
    schema.fields.flatMap(field => {
      val columnName = if (prefix == null) field.name else prefix + "." + field.name

      field.dataType match {
        case arrayType: ArrayType => {

          Array[Column](explode_outer(col(columnName)).as(columnName.replace(".", "_")))
        }
        case mapType: MapType => {
          None
        }
        case structType: StructType => {

          flattenSchema(structType, columnName)
        }
        case _ => {
          val columnNameWithUnderscores = columnName.replace(".", "_")

          val metadata = new MetadataBuilder().putString("encoding", "ZSTD").build()

          Array(col(columnName).as(columnNameWithUnderscores, metadata))
        }
      }
    }).filter(field => field != None)
  }

  def makeItFlat(df: DataFrame): DataFrame = {
    if (isSchemaNested(df)) {
      val flattenedSchema = flattenSchema(df.schema)
      makeItFlat(df.select(flattenedSchema: _*))
    } else {
      df
    }
  }

  def addMissingColumns(df: DataFrame, requestFileSchema: StructType): DataFrame =
    {
      val targetSchema = requestFileSchema.fields.map(x => (x.name.toString(), x.dataType)).toMap
      val targetColumns = requestFileSchema.fieldNames.toList

     // df.printSchema()

      //  val dfSchema=df.schema.fields.map(x=> (x.name.toString() , x.dataType )).toMap

      targetColumns.foldLeft(df) {
        (df, column) =>
          {

            //println("column:"+column)

            if (df.columns.contains(column) == false) {
              //println("inFunc:-----:" + column + " : " + targetSchema(column))
              targetSchema(column).typeName match {
                case "string" => df.withColumn(column, lit(null).cast(targetSchema(column)))
                case "struct" => df.withColumn(column, lit(null).cast(targetSchema(column)))

                case "array"  => df.withColumn(column, lit(array()).cast(targetSchema(column)))
                case _        => df.withColumn(column, lit(null))
              }
            } else (df)
          }
      }
    }

  def addMissingColumns2(df: DataFrame, requestFileSchema: StructType): DataFrame =
    {
      val targetSchema = requestFileSchema.fields.map(x => (x.name.toString(), x.dataType)).toMap
      val targetColumns = requestFileSchema.fieldNames.toList

      df.printSchema()

      val tempDF = df.select(col("ACYC.*"))

      val ACYCfields = df.select(col("ACYC.*")).schema.fieldNames

      val bb = df.select(col("ACYC.*")).schema.fieldNames.contains("ENXP")

      println("ACYCfields Length:" + ACYCfields.length)
      for (i <- 0 until ACYCfields.length) {

      }

      //val newSchema = StructType(df.select(col("ACYC.*")). .fields.g ++ Array(StructField("Rank", LongType, false), StructField("Rank_Category", StringType, false))) // Append "rowid" column of type Long

      // val totalCountRDD = deviceCountsDF.orderBy(org.apache.spark.sql.functions.col("CountOfTxns").desc).limit(100).rdd.zipWithIndex() //sortRDDwithID
      // val totalCountDF = spark.createDataFrame(totalCountRDD.map { case (row, index) => Row.fromSeq(row.toSeq ++ Array(index + 1, "TopTransactionCounts")) }, newSchema)

      val dfSchema = df.schema.fields.map(x => (x.name.toString(), x.dataType)).toMap

      targetColumns.foldLeft(df) {
        (df, column) =>
          {

            println("column:" + column)

            val a = df.columns.contains(column)

            if (column.equalsIgnoreCase("ACYC")) {
              //println("inFunc:-----:"+ column +" : "+targetSchema(column) )

              df.select(col("ACYC.*")).show()

              targetSchema(column).typeName match {
                //case "string" => df.withColumn(column,lit(null).cast(targetSchema(column)))
                case "struct" => //df.withColumn(column,lit(null).cast( targetSchema(column)))
                  val a = df(column).getItem("ANXPD") //getField("AACS")
                  println("a:" + a)
                //  val dfSchema = requestFileSchema.fields.f
                //case "array"  => df.withColumn(column,lit(array()).cast(targetSchema(column)))
                case _ => println("b:")
              }
            }

            if (df.columns.contains(column) == false) {
              println("inFunc:-----:" + column + " : " + targetSchema(column))
              targetSchema(column).typeName match {
                case "string" => df.withColumn(column, lit(null).cast(targetSchema(column)))
                case "struct" => df.withColumn(column, lit(null).cast(targetSchema(column)))

                case "array"  => df.withColumn(column, lit(array()).cast(targetSchema(column)))
                case _        => df.withColumn(column, lit(null))
              }
            } else (df)
          }
      }
    }

  def getListOfResponceFiles(dir: String): List[File] = {

    try {
      val d = new File(dir)
      if (d.exists && d.isDirectory) {
        //d.listFiles.filter(_.isFile).toList
        val allFiles = d.listFiles.filter(_.isFile)
        return allFiles.toList
      } else {
        List[File]()
      }
    } catch {
      case e: Exception =>
        println("Error : Exception caught in Helpers.getListOfResponceFiles method")
        e.printStackTrace()
        List[File]()

    }
  }
  
   def getManualDataFileName(dir: String , searchString: String ): String = {

    try {
      val d = new File(dir)
      if (d.exists && d.isDirectory) 
      {
        //d.listFiles.filter(_.isFile).toList
        val allFiles = d.listFiles.filter(_.isFile)// .filter(_.getName.contains(searchString))
        val matchingFiles = allFiles.filter(p => p.getName.startsWith(searchString)).toList
        
        
        println("All files")
         for(file <- allFiles)
         {
           println("path:"+ file.getAbsolutePath)
           println("name:"+ file.getName)
         }
        
        println(" Matching files")
         for(file <- matchingFiles)
         {
           println("path:"+ file.getAbsolutePath)
           println("name:"+ file.getName)
         }
        
        if(matchingFiles.length>1 )
        {
          return ""
        }
        else if (matchingFiles.length==0)
          ""
        else
            matchingFiles(0).getAbsolutePath
       }
      else
      {
        ""
      }
    } catch {
      case e: Exception =>
        println("Error : Exception caught in Helpers.getListOfResponceFiles method")
        e.printStackTrace()
        return ""

    }
  }

  def getListOfFiles(dir: String): List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      //d.listFiles.filter(_.isFile).toList
      val allFiles = d.listFiles.filter(_.isFile)
      val onlyPartFiles = allFiles.filter(p => p.getName.startsWith("part")).toList
      return onlyPartFiles
    } else {
      List[File]()
    }
  }
  def deleteFolder(dir: String): Unit =
    {
      try {
        val directory = new Directory(new File(dir))
        //   directory.deleteRecursively()
        // println("dirPath:"+dir)

        if (directory.isDirectory && directory.exists) {
          if (!directory.deleteRecursively())
            deleteFolder(dir)
          println("Usage : Deleting the temporary folder :" + dir)
        }

      } catch {
        case e: Exception =>
          println("Error : Exception caught in delete temp directory method")
          e.printStackTrace()
        // some file could not be deleted
      }
    }

  //This function will delete all sub folder and files using commons.io.FileUtils from the dir path received in argument
  def deleteFolder3(dir: String): Unit =
    {
      //Function call to delete temp directory all part files
      try {
        //Thread.sleep(30000)
        val tempDir = new File(dir)
        if (tempDir.exists())
          FileUtils.deleteDirectory(tempDir)
        else
          println(s"The folder path : $dir is not exists ")
      } catch {
        case e: Exception =>
          println("Error : Exception caught in Helpers.deleteFolder3 method")
          e.printStackTrace()
      }
    }
  def getHeader(inputFilePath: String): Seq[String] = {
    try {
      //val headerLines=Source.fromFile(inputFilePath).getLines().toList
      //Below line is added to avoid exception in cmd  java.nio.charset.UnmappableCharacterException: Input length = 1
      val headerLines = Source.fromFile(inputFilePath)("UTF-8").getLines().toList
      var lines = Seq[String]()

      for (i <- 0 to 7) //headerLines.length)
      {
        println("Line:" + i + " : " + headerLines(i))
        val line = headerLines(i)
        lines = lines :+ line //.add(line)
        // lines=lines ++ headerLines(i).t
      }
      return lines
      //.filterNot(line => line.startsWith("#")).filter(line => line.contains("="))
      // .map { line => // println(line)
      //   val tokens = line.split("=")
      //  (tokens(0).trim() -> (if (tokens.length >= 2) tokens(1).trim() else ""))
      // }.toMap
    } catch {
      case e: Exception =>
        println("************ Exception Caught in getHeader:" + inputFilePath)
        println(e.printStackTrace())
        e.printStackTrace()
        Seq[String]()
    }
  }

  def getHeader2(inputFilePath: String): Seq[String] = {
    try {
      //val headerLines=Source.fromFile(inputFilePath).getLines().toList
      //Below line is added to avoid exception in cmd  java.nio.charset.UnmappableCharacterException: Input length = 1
      //*   val headerLines=Source.fromFile(inputFilePath)("UTF-8").getLines().toList
      val reader = new BufferedReader(new FileReader(inputFilePath))
      var lines = Seq[String]()

      for (i <- 0 to 8) //headerLines.length)
      {
        //println("Line:"+i+" : "+headerLines(i))
        val line = reader.readLine()
        // println("Line:"+i+" : "+line)
        lines = lines :+ line //.add(line)
        // lines=lines ++ headerLines(i).t
      }

      /*
       for(i <- 0 to 8)//headerLines.length)
       {
         //println("Line:"+i+" : "+headerLines(i))
         val line=headerLines(i)
         lines = lines :+ line//.add(line)
        // lines=lines ++ headerLines(i).t
       }
       * */

      return lines
      //.filterNot(line => line.startsWith("#")).filter(line => line.contains("="))
      // .map { line => // println(line)
      //   val tokens = line.split("=")
      //  (tokens(0).trim() -> (if (tokens.length >= 2) tokens(1).trim() else ""))
      // }.toMap
    } catch {
      case e: Exception =>
        println("************ Exception Caught in getHeader:" + inputFilePath)
        println(e.printStackTrace())
        e.printStackTrace()
        Seq[String]()
    }
  }

  def mergeFiles(allFiles: List[File], headerLines: Seq[String], outputFilePath: String, tempFolder: String): Unit = {
    //val part0 = Source.fromFile("part-00000.txt").getLines
    // val part1 = Source.fromFile("part-00001.txt").getLines
    // val part2 = part0.toList ++ part1.toList

    var allLines = List[String]()

    for (file <- allFiles) {
      //val a=Source.fromFile(file.getAbsoluteFile).getLines().toSeq
      // println("file.getAbsoluteFile:"+file.getAbsoluteFile)

      //Below line is added to avoid exception in cmd  java.nio.charset.UnmappableCharacterException: Input length = 1
      // allLines=  Source.fromFile(file.getAbsoluteFile).getLines().toList  ++ allLines
      allLines = Source.fromFile(file.getAbsoluteFile)("UTF-8").getLines().toList ++ allLines

      //allLines.foreach(println(f))
    }

    //val bufferWrite = new BufferedWriter(new FileWriter(new File(outputFilePath)))
    val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath), true))

    //Wrting header string
    headerLines.foreach(line => bufferWrite.write(line + "\n"))

    //Wrting all part files from spark xml
    allLines.foreach(line => bufferWrite.write(line + "\n"))

    //wrting end line to file
    bufferWrite.write("</REQUEST>")

    bufferWrite.close

    //Adding addtional code for removing temp directory
    try {
      val directory = new Directory(new File(tempFolder))
      //   directory.deleteRecursively()
      // println("dirPath:"+dir)

      if (directory.isDirectory && directory.exists) {
        directory.deleteRecursively()
        println("Usage : Deleting the temporary folder :" + tempFolder)
      }
    } catch {
      case e: Exception =>
        println("Error : Exception caught in delete temp directory method")
        e.printStackTrace()
      // some file could not be deleted
    }
  }
  def mergeFiles2(allFiles: List[File], headerLines: Seq[String], outputFilePath: String, tempFolder: String): Unit = {
    //val bufferWrite = new BufferedWriter(new FileWriter(new File(outputFilePath)))
    val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath), true))

    //Wrting header string
    headerLines.foreach(line => bufferWrite.write(line + "\n"))
    bufferWrite.close

    for (file <- allFiles) {
      //var allLines =List[String]()

      //allLines=  Source.fromFile(file.getAbsoluteFile)("UTF-8").getLines().toList  ++ allLines
      val allLines = Source.fromFile(file.getAbsoluteFile)("UTF-8").getLines().toList
      val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath), true))
      allLines.foreach(line => bufferWrite.write(line + "\n"))
      //  bufferWrite.write(allLines + "\n")
      bufferWrite.close
    }
    val bufferWrite2 = new PrintWriter(new FileOutputStream(new File(outputFilePath), true))
    bufferWrite2.write("</REQUEST>")
    bufferWrite2.close

    //Function call to delete the temp directory
    //temp stop  deleteFolder(tempFolder)

  }

  def getRunDate(dateString: String): java.sql.Date =
    {
      try {

        val array = dateString.split("-")
        if (array(0).toInt > 31 || array(1).toInt > 12) {
          println(s"Usage : Enterd run date is not a valid date or not in expected format, please enter date in dd-MM-yyyy format:" + dateString)
          new java.sql.Date(0)
        } else {

          val tempDate = new java.text.SimpleDateFormat("dd-MM-yyyy").parse(dateString)
          val runDate = new java.sql.Date(tempDate.getTime())
          println("runDate:" + runDate)
          runDate
        }
      } catch {
        case e: Exception =>
          println(s"Usage : Enterd run date is not a valid date or not in expected format, please enter date in dd-MM-yyyy format:" + dateString)
          //println("Error : Aborting the Program ")
          // println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
          new java.sql.Date(0)
      }

    }
   def getRunDate2(dateString: String): java.sql.Date =
    {
      try {

        val year=dateString.slice(0, 4)
        val month=dateString.slice(4, 6)
        val day=dateString.slice(6, 8)
       
        if (day.toInt > 31 || month.toInt > 12) {
          println(s"Usage : Enterd run date is not a valid date or not in expected format, please enter date in dd-MM-yyyy format:" + dateString)
          new java.sql.Date(0)
        } else {

          val tempDate = new java.text.SimpleDateFormat("yyyyMMdd").parse(dateString)
          val runDate = new java.sql.Date(tempDate.getTime())
          println("runDate:" + runDate)
          runDate
        }
      } catch {
        case e: Exception =>
          println(s"Usage : Enterd run date is not a valid date or not in expected format, please enter date in dd-MM-yyyy format:" + dateString)
          //println("Error : Aborting the Program ")
          // println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
          new java.sql.Date(0)
      }

    }

  def moveFiles(oldFilePath: String, newFilePath: String, newName: String): Unit =
    {

      try {
        val sourceDirectory = new File(oldFilePath)

        //println("Path: " + sourceDirectory.getAbsolutePath)
        if (sourceDirectory.exists && sourceDirectory.isDirectory) {
          //d.listFiles.filter(_.isFile).toList
          val allFiles = sourceDirectory.listFiles.filter(_.isFile)
          val onlyPartFiles = allFiles.filter(p => p.getName.startsWith("part")).toList
          //return onlyPartFiles

          for (file <- onlyPartFiles) {
            var i = 0
            // println("partFile: "+ file.getAbsolutePath())
            //val oldFile = new File(file)
            // val newFilePath2 = file.getParentFile.getAbsolutePath.replace(file.getName(), "") + newName

            //  println("newFilePath: "+ newFilePath)

            val newFile = new File(newFilePath + newName)

            try {
              if (newFile.exists())
                newFile.delete()
              FileUtils.moveFile(file, newFile)
              // println("Moved from file"+ file.getName +  " To file :"+ newFile.getName)
            } catch {
              case e: org.apache.commons.io.FileExistsException =>
                println("Usage: Exception File already exists in the destination :" + newFile.getAbsolutePath)
                e: Exception =>
                  println("Exception caught in Helpers.moveFile method")
                  e.printStackTrace();
            }
          }
          //Function call to delete the temp directory
          deleteFolder3(sourceDirectory.getAbsolutePath)
        }
      } catch {
        case e: Exception =>
          println("Exception caught in Helpers.moveFile method")
          e.printStackTrace();
      }
    }
  def generateResponseXMLFile(outputPath: String, df: DataFrame,totalCount:Int ,  runNumber:Int,fileType:String) {
    try {

      val respErrorsList = df.collect()
      val rejectCount=respErrorsList.size
      
      //println("##########rejectCount:"+rejectCount)

      val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputPath), true))

      val msgStartTag = "<MESSAGE>"
      val msgEndTag = "</MESSAGE>"
      
      val respTag_1=
         if (fileType.equalsIgnoreCase("REG")) 
            "<RESPONSE xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"CI_Response_New.xsd\">"
          else
            "<RESPONSE xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"DefaultRsp.xsd\">"
            
          val serviceTag_2=if (fileType.equalsIgnoreCase("REG")) "<SERVICE>REGULAR_AC</SERVICE>" else "<SERVICE>DEFAULT</SERVICE>"
          val actionTag_3=if (fileType.equalsIgnoreCase("REG")) "<ACTION>A</ACTION>" else "<ACTION>M</ACTION>"
          
          val statusFlag= if(rejectCount==0) "OK" else "ERROR" 
            
          val statusTag_4=s"<STATUS>$statusFlag</STATUS>"
          
          //:TODO parameterize member and user id tag values from config 
          val headerStartTag_5="<HEADER>"+ "\n" + "<MEMBER_ID>119</MEMBER_ID>" +"\n" + "<USER_ID>FTSNCBB</USER_ID>"
          
          val runNumberTag_6="<RUN_NO>"+runNumber.toString()+"</RUN_NO>"
          val tottalItemsTag_7="<TOT_ITEMS>"+totalCount.toString()+"</TOT_ITEMS>"
          val errorItemsTag_8="<ERR_ITEMS>"+rejectCount.toString()+"</ERR_ITEMS>"
          
          val headerEndTag_9="</HEADER>"
          
          val respEndTag="</RESPONSE>"
          
          /*<HEADER>
          <MEMBER_ID>119</MEMBER_ID>
          <USER_ID>FTSNCBB</USER_ID>
          <RUN_NO>16408</RUN_NO>
          <TOT_ITEMS>127592</TOT_ITEMS>
          <ERR_ITEMS>74</ERR_ITEMS>
          </HEADER>
          <MESSAGE>*/
          bufferWrite.write(respTag_1 + "\n")
          bufferWrite.write(serviceTag_2 + "\n")
      bufferWrite.write(actionTag_3 + "\n")
      bufferWrite.write(statusTag_4 + "\n")
      bufferWrite.write(headerStartTag_5 + "\n")
      bufferWrite.write(runNumberTag_6 + "\n")
      bufferWrite.write(tottalItemsTag_7 + "\n")
      bufferWrite.write(errorItemsTag_8 + "\n")
      bufferWrite.write(headerEndTag_9 + "\n")
 

          if(rejectCount>0)
          {
        bufferWrite.write(msgStartTag + "\n")
        for (i <- 0 until respErrorsList.length) 
        {
          val row = respErrorsList(i)
          // for(j <- 0 until row.length )
          //{
          val seq = row.get(0)
          val act = row.getString(1)
          val prd = row.getString(2)
          val msg = row.getString(3)
  
          val seqTag = "<ITEM seq=\"" + seq + "\">"
          val actTag = if (fileType.equalsIgnoreCase("REG")) "<AREF>" + act + "</AREF>" else "<PREF>" + act + "</PREF>"
          val prdTag = if (fileType.equalsIgnoreCase("REG")) "<APRD>" + prd + "</APRD>" else "<PPRD>" + prd + "</PPRD>"
          val msgTag = "<ERROR>" + "\n" + "<RSP_MSG>" + msg + "</RSP_MSG>" + "\n" + "</ERROR>"
          val endTag = "<NO_ERRORS>1</NO_ERRORS>" + "\n" + "</ITEM>"
  
          bufferWrite.write(seqTag + "\n")
          bufferWrite.write(actTag + "\n")
          bufferWrite.write(prdTag + "\n")
          bufferWrite.write(msgTag + "\n")
          bufferWrite.write(endTag + "\n")
        }
        bufferWrite.write(msgEndTag + "\n")
        bufferWrite.write(respEndTag)
        bufferWrite.close()
          }
          else // to handle blank message or zero rejections
          {
            bufferWrite.write("<MESSAGE/>"+ "\n")
            bufferWrite.write(respEndTag)
            bufferWrite.close()
          }
      
    } catch {
      case e: Exception => 
        println("*************** Exception caught in generateResponseXMLFile function")
       // log. ("*************** Exception caught in generateResponseXMLFile function")
        e.printStackTrace()
    }
  }

  //generateRegularCuratedXMLFile(RequestXML_Input,RequestXML_Output,rejectAccountList,commonAcctsList, TOTAL_ITEMS)
  def generateRegularCuratedXMLFilewithMerge(inputRequestXMLPath: String, inputManualXMLPath: String,outputPath: String, rejectAccountList: List[String],commonAcctsList: List[String],TOTAL_ITEMS:Int) {
    try {

      val inputRequestXMLFile = new File(inputRequestXMLPath)
      val inputRequestFileBuffer = scala.io.Source.fromFile(inputRequestXMLFile.getAbsoluteFile)("UTF-8")
      
      
      try 
      {
        val outputFile = new File(outputPath)
        if (outputFile.exists())
          outputFile.delete()
      } catch {
        case e: Exception =>
          println("Error : Exception caught in while deleting output file " + outputPath)
          e.printStackTrace()
      }
      
      val excludeList=rejectAccountList++commonAcctsList
      val excludeList2=excludeList.distinct
      var header = true
      var accts = ""
      var testRowCountIndex = 0
      var act = ""
      var prd = ""
      var actKey = ""
      // val excludeList=List("00769424080110PLN","01068403080105PLN")
      val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputPath), true))
      
      for (line <- inputRequestFileBuffer.getLines) 
      {
        if(line.equalsIgnoreCase("<ACCOUNT>") && header )
        {
          header = false
        }

        else if (header )//&& !(line.equalsIgnoreCase("<MESSAGE>"))) 
        {
          // :TODO , update header total account count in tag <TOT_ITEMS>4702</TOT_ITEMS>
          if (line.startsWith("<TOT_ITEMS")) 
          {
            val fileCount = line.substring(11, line.indexOf("</TOT_ITEMS>")).toString().toInt
            //val newCount = fileCount - excludeList.size
            //val updatedLine = "<TOT_ITEMS>" + newCount.toString() + "</TOT_ITEMS>"
            val updatedLine = "<TOT_ITEMS>" + TOTAL_ITEMS.toString() + "</TOT_ITEMS>"
            bufferWrite.write(updatedLine + "\n")
          } 
          else if ( !(line.equalsIgnoreCase("</MESSAGE>")) &&  !(line.equalsIgnoreCase("</REQUEST>")) &&  !(line.equalsIgnoreCase("<ACCOUNT>")))
          {
            println("header line :"+line)
            bufferWrite.write(line + "\n")
          }
        } 

        else if (!header && !(line.equalsIgnoreCase("</ACCOUNT>") && !(line.equalsIgnoreCase("</MESSAGE>")) &&  !(line.equalsIgnoreCase("</REQUEST>")))) 
        {
          accts = accts + line + "\n"
          //<AREF>123456789</AREF>  <APRD>PLN</APRD>
          // :Review and add PPRF for default
          if (line.startsWith("<AREF"))
            act = line.substring(6, line.indexOf("</AREF>"))
          // :Review and add PPRD for default
          if (line.startsWith("<APRD"))
            prd = line.substring(6, line.indexOf("</APRD>"))

        } else if (!header && line.equalsIgnoreCase("</ACCOUNT>") && !(line.equalsIgnoreCase("</MESSAGE>")) &&  !(line.equalsIgnoreCase("</REQUEST>"))) 
        {
          accts = accts + line + "\n"
          //println("act:"+act)
          //println("prd:"+prd)
          actKey = act + prd
          // println("actKey:" + actKey)
          // println(accts)
          if (!(excludeList2.contains(actKey)))
            bufferWrite.write(accts)
          accts = ""
          act = ""
          prd = ""
        } // end if account closetag
      } // end for loop for all lines
      inputRequestFileBuffer.close()
      
      accts = ""
      //#####Start Merging manula data XML file
      val inputManualXMLFile = new File(inputManualXMLPath)
      val inputManualFileBuffer = scala.io.Source.fromFile(inputManualXMLFile.getAbsoluteFile)("UTF-8")
      
       for (line <- inputManualFileBuffer.getLines) 
       {
         if ( !(line.equalsIgnoreCase("</ACCOUNT>"))) 
         {
          accts = accts + line + "\n"
          // :Review and add PPRF for default
          if (line.startsWith("<AREF"))
            act = line.substring(6, line.indexOf("</AREF>"))
          // :Review and add PPRD for default
          if (line.startsWith("<APRD"))
            prd = line.substring(6, line.indexOf("</APRD>"))

        } 
        else if (line.equalsIgnoreCase("</ACCOUNT>")) 
        {
          accts = accts + line + "\n"
          actKey = act + prd
          if (!(rejectAccountList.contains(actKey)))
            bufferWrite.write(accts)
          accts = ""
          act = ""
          prd = ""
      } // end if account closetag
      } // end for loop for all lines
      inputManualFileBuffer.close()
      //#########End manual data XML file
      bufferWrite.write("</MESSAGE>")
      bufferWrite.write("</REQUEST>")
      bufferWrite.close()
      
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }
  
def generateRegularCuratedXMLFilewithMerge_V2(inputRequestXMLPath: String, inputManualXMLPath: String,outputPath: String, rejectAccountList: List[String],commonAcctsList: List[String],TOTAL_ITEMS:Int) {
    try {

      val inputRequestXMLFile = new File(inputRequestXMLPath)
      val inputRequestFileBuffer = scala.io.Source.fromFile(inputRequestXMLFile.getAbsoluteFile)("UTF-8")
      
      
      try 
      {
        val outputFile = new File(outputPath)
        if (outputFile.exists())
          outputFile.delete()
      } catch {
        case e: Exception =>
          println("Error : Exception caught in while deleting output file " + outputPath)
          e.printStackTrace()
      }
      
      val excludeList=rejectAccountList++commonAcctsList
      val excludeList2=excludeList.distinct // To Remove duplicates
      
      val excludeList3 = if (TOTAL_ITEMS == 0 ) excludeList2.drop(1) else excludeList2 // To drop one record from exclude list as we have generate file with one record if all input records are invalid
      
      println("TOTAL_ITEMS:"+TOTAL_ITEMS)
      println("excludeList2 count:"+excludeList2.size)
      println("excludeList3 count:"+excludeList3.size)
      
      
      var header = true
      val accts = new StringBuilder("")  
      val act = new StringBuilder("")  
      val prd = new StringBuilder("")  
      // val excludeList=List("00769424080110PLN","01068403080105PLN")
      val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputPath), true))
      
      for (line <- inputRequestFileBuffer.getLines) 
      {
        if(line.equalsIgnoreCase("<ACCOUNT>") && header )
        {
          header = false
        }
        else if (header )//&& !(line.equalsIgnoreCase("<MESSAGE>"))) 
        {
          // :TODO , update header total account count in tag <TOT_ITEMS>4702</TOT_ITEMS>
          if (line.startsWith("<TOT_ITEMS")) 
          {
            val fileCount = line.substring(11, line.indexOf("</TOT_ITEMS>")).toString().toInt
            //val newCount = fileCount - excludeList.size
            //val updatedLine = "<TOT_ITEMS>" + newCount.toString() + "</TOT_ITEMS>"
            val updatedLine = "<TOT_ITEMS>" + TOTAL_ITEMS.toString() + "</TOT_ITEMS>"
            bufferWrite.write(updatedLine + "\n")
          } 
          else
            bufferWrite.write(line + "\n")
        } 

        if (!header && !(line.equalsIgnoreCase("</ACCOUNT>")) && !(line.equalsIgnoreCase("</MESSAGE>")) &&  !(line.equalsIgnoreCase("</REQUEST>"))) 
        {
          //accts ++=  line + "\n"
          accts.append( line + "\n")
          //accts = accts + line + "\n"
          //<AREF>123456789</AREF>  <APRD>PLN</APRD>
          // :Review and add PPRF for default
          if (line.startsWith("<AREF"))
            act.append(line.substring(6, line.indexOf("</AREF>")))
          // :Review and add PPRD for default
          if (line.startsWith("<APRD"))
            prd.append( line.substring(6, line.indexOf("</APRD>")))
           // println("accts:"+accts)
            }
        else if (!header && line.equalsIgnoreCase("</ACCOUNT>") && !(line.equalsIgnoreCase("</MESSAGE>")) &&  !(line.equalsIgnoreCase("</REQUEST>"))) 
        {
          accts.append( line + "\n") 
          //if (!(excludeList2.contains(act.toString() + prd.toString())))
          if (!(excludeList3.contains(act.toString() + prd.toString())))
            bufferWrite.write(accts.toString())
          accts.clear()
          act.clear()
          prd.clear()
         }
      } // end for loop for all lines
      inputRequestFileBuffer.close()
    // println("***********accts:"+accts)
       
     //  System.exit(0)
     // accts = ""
      //#####Start Merging manula data XML file
      System.out.println("inputManualXMLFile:"+inputManualXMLPath)
      if(inputManualXMLPath=="" )
      {
        System.out.println("********* received empty inputManualXMLFile:")
        bufferWrite.write("</MESSAGE>")
        bufferWrite.write("</REQUEST>")
        bufferWrite.close()
      }
      else
      {
        try
        {
            System.out.println("inputManualXMLFile:"+inputManualXMLPath)
          val inputManualXMLFile = new File(inputManualXMLPath)
          val inputManualFileBuffer = scala.io.Source.fromFile(inputManualXMLFile.getAbsoluteFile)("UTF-8")
           for (line <- inputManualFileBuffer.getLines) 
           {
             if ( !(line.equalsIgnoreCase("</ACCOUNT>"))) 
             {
              //accts ++=  line  + "\n"
               accts.append( line + "\n")
              // :Review and add PPRF for default
              if (line.startsWith("<AREF"))
                act.append(line.substring(6, line.indexOf("</AREF>")))
              // :Review and add PPRD for default
              if (line.startsWith("<APRD"))
                prd.append(line.substring(6, line.indexOf("</APRD>")))
    
            } 
            else if (line.equalsIgnoreCase("</ACCOUNT>")) 
            {
              //accts ++=  line + "\n"
              accts.append( line + "\n")
             // println("accts2:"+accts)
              if (!(rejectAccountList.contains(act.toString() + prd.toString())))
                bufferWrite.write(accts.toString())
                accts.clear()
               act.clear()
              prd.clear()
           } // end if account closetag
          } // end for loop for all lines
          inputManualFileBuffer.close()
          //#########End manual data XML file
          bufferWrite.write("</MESSAGE>")
          bufferWrite.write("</REQUEST>")
          bufferWrite.close()
          }
          catch
          {
            case e: Exception => e.printStackTrace()
             bufferWrite.write("</MESSAGE>")
            bufferWrite.write("</REQUEST>")
            bufferWrite.close()
          }
        }
      } catch {
        case e: Exception =>
          e.printStackTrace()
      }
  }

  def generateRegularCuratedXMLFile(inputPath: String, outputPath: String, excludeList: List[String]) {
    try {

      val file = new File(inputPath)
      val requestFile = scala.io.Source.fromFile(file.getAbsoluteFile)("UTF-8")
      try {
        val outputFile = new File(outputPath)
        if (outputFile.exists())
          outputFile.delete()
      } catch {
        case e: Exception =>
          println("Error : Exception caught in while deleting output file " + outputPath)
          e.printStackTrace()
      }
      var header = true
      var accts = ""
      var testRowCountIndex = 0
      var act = ""
      var prd = ""
      var actKey = ""
      // val excludeList=List("00769424080110PLN","01068403080105PLN")
      val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputPath), true))
      for (line <- requestFile.getLines) {
        if (header & !(line.equalsIgnoreCase("<MESSAGE>"))) {
          // :TODO , update header total account count in tag <TOT_ITEMS>4702</TOT_ITEMS>
          if (line.startsWith("<TOT_ITEMS")) {
            val fileCount = line.substring(11, line.indexOf("</TOT_ITEMS>")).toString().toInt
            val newCount = fileCount - excludeList.size
            val updatedLine = "<TOT_ITEMS>" + newCount.toString() + "</TOT_ITEMS>"
            bufferWrite.write(updatedLine + "\n")
          } else {
            //println("header:"+header)
            bufferWrite.write(line + "\n")
          }
        } else {
          header = false
        }

        if (!header && !(line.equalsIgnoreCase("</ACCOUNT>"))) {
          accts = accts + line + "\n"
          //<AREF>123456789</AREF>  <APRD>PLN</APRD>
          // :Review and add PPRF for default
          if (line.startsWith("<AREF"))
            act = line.substring(6, line.indexOf("</AREF>"))
          // :Review and add PPRD for default
          if (line.startsWith("<APRD"))
            prd = line.substring(6, line.indexOf("</APRD>"))

        } else if (line.equalsIgnoreCase("</ACCOUNT>")) {
          accts = accts + line + "\n"
          //println("act:"+act)
          //println("prd:"+prd)
          actKey = act + prd
          // println("actKey:" + actKey)
          // println(accts)
          if (!(excludeList.contains(actKey)))
            bufferWrite.write(accts)
          accts = ""
          act = ""
          prd = ""

          /*
          testRowCountIndex += 1
          if (testRowCountIndex == 5) {
            bufferWrite.write("</MESSAGE>" + "\n")
            bufferWrite.write("</REQUEST>")
            bufferWrite.close()
            requestFile.close()
            System.exit(1)
          }*/
        } // end if account closetag
      } // end for loop for all lines
      bufferWrite.write("</MESSAGE>")
      bufferWrite.write("</REQUEST>")
      bufferWrite.close()
      requestFile.close()
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }

  def generateDefaultCuratedXMLFile(inputPath: String, outputPath: String, excludeList: List[String]) {
    try {

      val file = new File(inputPath)
      val requestFile = scala.io.Source.fromFile(file.getAbsoluteFile)("UTF-8")
      try {
        val outputFile = new File(outputPath)
        if (outputFile.exists())
          outputFile.delete()
      } catch {
        case e: Exception =>
          println("Error : Exception caught in while deleting output file " + outputPath)
          e.printStackTrace()
      }
      var header = true
      var accts = ""
      var testRowCountIndex = 0
      var act = ""
      var prd = ""
      var actKey = ""
      // val excludeList=List("00769424080110PLN","01068403080105PLN")
      val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputPath), true))
      for (line <- requestFile.getLines) {
        if (header & !(line.equalsIgnoreCase("<MESSAGE>"))) {
          // :TODO , update header total account count in tag <TOT_ITEMS>4702</TOT_ITEMS>
          if (line.startsWith("<TOT_ITEMS")) {
            val fileCount = line.substring(11, line.indexOf("</TOT_ITEMS>")).toString().toInt
            val newCount = fileCount - excludeList.size
            val updatedLine = "<TOT_ITEMS>" + newCount.toString() + "</TOT_ITEMS>"
            bufferWrite.write(updatedLine + "\n")
          } else {
            //println("header:"+header)
            bufferWrite.write(line + "\n")
          }
        } else {
          header = false
        }

        if (!header && !(line.equalsIgnoreCase("</BAD_DEBT>"))) {
          accts = accts + line + "\n"
          //<AREF>123456789</AREF>  <APRD>PLN</APRD>
          // :Review and add PPRF for default
          if (line.startsWith("<PREF"))
            act = line.substring(6, line.indexOf("</PREF>"))
          // :Review and add PPRD for default
          if (line.startsWith("<PPRD"))
            prd = line.substring(6, line.indexOf("</PPRD>"))

        } else if (line.equalsIgnoreCase("</BAD_DEBT>")) {
          accts = accts + line + "\n"
          //println("act:"+act)
          //println("prd:"+prd)
          actKey = act + prd
          //println("actKey:" + actKey)
          // println(accts)
          if (!(excludeList.contains(actKey)))
            bufferWrite.write(accts)
          accts = ""
          act = ""
          prd = ""

          /*
          testRowCountIndex += 1
          if (testRowCountIndex == 5) {
            bufferWrite.write("</MESSAGE>" + "\n")
            bufferWrite.write("</REQUEST>")
            bufferWrite.close()
            requestFile.close()
            System.exit(1)
          }*/
        } // end if account closetag
      } // end for loop for all lines
      bufferWrite.write("</MESSAGE>")
      bufferWrite.write("</REQUEST>")
      bufferWrite.close()
      requestFile.close()
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }

  def mergeFiles3(allFiles: List[File], headerLines: Seq[String], outputFilePath: String, tempFolder: String): Unit =
    {
      val bufferWrite = new BufferedWriter(new FileWriter(new File(outputFilePath)))
      //val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath),true))

      //Wrting header string
      headerLines.foreach(line => bufferWrite.write(line + "\n"))

      bufferWrite.close

      for (file <- allFiles) {

        //val allLines=Source.fromFile(file.getAbsoluteFile)("UTF-8").getLines().toList

        val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath), true))
        // val source: BufferedSource = scala.io.Source.fromFile(file.getAbsoluteFile)
        val source = scala.io.Source.fromFile(file.getAbsoluteFile)("UTF-8")

        for (line <- source.getLines) {
          bufferWrite.write(line + "\n")
        }

        source.close()
        //  bufferWrite.write(allLines + "\n")
        bufferWrite.close
      }
      val bufferWrite2 = new PrintWriter(new FileOutputStream(new File(outputFilePath), true))
      bufferWrite2.write("</REQUEST>")
      bufferWrite2.close

      //Function call to delete the temp directory
      deleteFolder3(tempFolder)

    }

  def writeFileLocalAppend(outputFilePath: String): Unit =
    {

      // val outputFile = new BufferedWriter(new FileWriter(outputFilePath))

      val outFile = (new PrintWriter(new FileOutputStream(new File(outputFilePath), true)))
      // val outFile = new FileOutputStream(new File("Test.txt"),true)

      val endLine = "</REQUEST>"
      outFile.write("<test1>")
      outFile.println("Test2")
      outFile.append(endLine)

      // outputFile.append(endLine)
      //  outputFile.close()
      outFile.close()

    }

  def printInputParams2(params :QCLConfigParams):Unit =
      {
        //val length=params.
        
      //val schema = ScalaReflection.schemaFor[QCLInputParams2].dataType.asInstanceOf[StructType]
      //schema.printTreeString
          //println ("DELTA_TABLE_NAME_BASE : "+params.DELTA_TABLE_NAME_BASE)
      //println ("DELTA_TABLE_NAME_BASERAW : "+params.DELTA_TABLE_NAME_BASERAW)
      //println ("DELTA_TABLE_NAME_CONTROL : "+params.DELTA_TABLE_NAME_CONTROL)
      println ("DELTA_TABLE_PATH_BASE : "+params.DELTA_TABLE_PATH_BASE)
      //println ("DELTA_TABLE_PATH_REPORTING : "+params.DELTA_TABLE_PATH_REPORTING)
      //println ("DELTA_TABLE_PATH_SNAPSHOT : "+params.DELTA_TABLE_PATH_SNAPSHOT)
      println ("DELTA_TABLE_PATH_WORKING : "+params.DELTA_TABLE_PATH_WORKING)
      //println ("INPUT_FILE_HISTDATA_CHARACTERSET : "+params.INPUT_FILE_HISTDATA_CHARACTERSET)
      //println ("INPUT_FILE_HISTDATA_DELIMETER : "+params.INPUT_FILE_HISTDATA_DELIMETER)
      //println ("INPUT_FILE_HISTDATA_FORMAT : "+params.INPUT_FILE_HISTDATA_FORMAT)
      //println ("INPUT_FILE_HISTDATA_HEADER : "+params.INPUT_FILE_HISTDATA_HEADER)
      //println ("INPUT_FILE_HISTDATA_PARSINGMODE : "+params.INPUT_FILE_HISTDATA_PARSINGMODE)
      println ("INPUT_FILE_HISTDATA_PATH : "+params.INPUT_FILE_HISTDATA_PATH)
      //println ("INPUT_FILE_MANUALDATA_CHARACTERSET : "+params.INPUT_FILE_MANUALDATA_CHARACTERSET)
      //println ("INPUT_FILE_HISTDATA_DATEFORMAT : "+params.INPUT_FILE_HISTDATA_DATEFORMAT)
      //println ("INPUT_FILE_MANUALDATA_DATEFORMAT : "+params.INPUT_FILE_MANUALDATA_DATEFORMAT)
      //println ("INPUT_FILE_MANUALDATA_DELIMETER : "+params.INPUT_FILE_MANUALDATA_DELIMETER)
      //println ("INPUT_FILE_MANUALDATA_FORMAT : "+params.INPUT_FILE_MANUALDATA_FORMAT)
      //println ("INPUT_FILE_MANUALDATA_HEADER : "+params.INPUT_FILE_MANUALDATA_HEADER)
      //println ("INPUT_FILE_MANUALDATA_PARSINGMODE : "+params.INPUT_FILE_MANUALDATA_PARSINGMODE)
      //println ("INPUT_FILE_MANUALDATA_PATH : "+params.INPUT_FILE_MANUALDATA_PATH)
      //println ("INPUT_FILE_XMLREQUEST_CHARACTERSET : "+params.INPUT_FILE_XMLREQUEST_CHARACTERSET)
      println ("INPUT_FILE_XMLREQUEST_PATH : "+params.INPUT_FILE_XMLREQUEST_PATH)
      //println ("INPUT_FILE_XMLREQUEST_ROWTAG : "+params.INPUT_FILE_XMLREQUEST_ROWTAG)
      //println ("INPUT_FILE_XMLRESPONSE_CHARACTERSET : "+params.INPUT_FILE_XMLRESPONSE_CHARACTERSET)
      println ("INPUT_FILE_XMLRESPONSE_PATH : "+params.INPUT_FILE_XMLRESPONSE_PATH)
      //println ("INPUT_FILE_XMLRESPONSE_ROWTAG : "+params.INPUT_FILE_XMLRESPONSE_ROWTAG)
      //println ("OUTPUT_FILE_REPORTS_DELIMETER : "+params.OUTPUT_FILE_REPORTS_DELIMETER)
      //println ("OUTPUT_FILE_REPORTS_FORMAT : "+params.OUTPUT_FILE_REPORTS_FORMAT)
      println ("OUTPUT_FILE_REPORTS_PATH : "+params.OUTPUT_FILE_REPORTS_PATH)
      //println ("OUTPUT_FILE_XMLREQUET_PATH : "+params.OUTPUT_FILE_XMLREQUET_PATH)
      //println ("OUTPUT_FILE_XMLREQUET_ROOTTAG : "+params.OUTPUT_FILE_XMLREQUET_ROOTTAG)
      //println ("OUTPUT_FILE_XMLREQUET_ROWTAG : "+params.OUTPUT_FILE_XMLREQUET_ROWTAG)
      println ("OUTPUT_FILE_XMLRESPONSE_PATH : "+params.OUTPUT_FILE_XMLRESPONSE_PATH)
      //println ("OUTPUT_FILE_XMLRESPONSE_ROOTTAG : "+params.OUTPUT_FILE_XMLRESPONSE_ROOTTAG)
      //println ("OUTPUT_FILE_XMLRESPONSE_ROWTAG : "+params.OUTPUT_FILE_XMLRESPONSE_ROWTAG)

        
      }
 

  def getTimeDifference(startTime: java.sql.Timestamp, endTime: java.sql.Timestamp): String =
    {
      val exeTime2 = (endTime.getTime - startTime.getTime)
      val rtMins = exeTime2 / (60 * 1000)
      val rtHrs = exeTime2 / (60 * 60 * 1000)
      val rtDays = exeTime2 / (24 * 60 * 60 * 1000)
      val rtSecs = (exeTime2 / 1000)

      val rtSecsStr = rtSecs - (rtMins * 60)
      val rtMinsStr = rtMins - (rtHrs * 60)
      val rtHrsStr = rtHrs - (rtDays * 24)

      if (rtDays >= 1)
        s"$rtDays:Days $rtHrsStr:Hours $rtMinsStr:Minutes $rtSecsStr:Seconds"
      else if (rtDays < 1 && rtHrs >= 1)
        s"$rtHrsStr:Hours $rtMinsStr:Minutes $rtSecsStr:Seconds"
      else if (rtDays < 1 && rtHrs < 1 && rtMins >= 1)
        s"$rtMinsStr:Minutes $rtSecsStr:Seconds"
      else if (rtDays < 1 && rtHrs < 1 && rtMins < 1 && rtSecs >= 1)
        s"$rtSecsStr:Seconds"
      else
        s"$rtDays:Days $rtHrsStr:Hours $rtMinsStr:Minutes $rtSecsStr:Seconds"
    }

  // Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
  def getDefaultRequestXMLMapClass_V2_0(df: DataFrame): Dataset[DefaultRequestXMLMapClass] =
    {
      val TagggedDF = df.select(
        col("PREF"),
        col("PPRD"),
        col("BAL"),
        col("STS"),
        col("STSDATE"))
        .withColumn("BAL", col("BAL").cast(DoubleType))
        .withColumnRenamed("BAL", "OutStandingBalance") //OutstandingAmount
        .withColumnRenamed("PREF", "AccountNumber")
        .withColumnRenamed("PPRD", "ProductType")
        .withColumn("DefaultStatusDate", to_date(expr("concat(STSDATE.STSDAY, STSDATE.STSMON,STSDATE.STSYEAR)"), "ddMMyyyy"))
        .withColumnRenamed("STS", "DefaultStatus")
        .drop(col("STSDATE"))

      import spark.implicits._
      val caseClassDS = TagggedDF.as[DefaultRequestXMLMapClass]
      caseClassDS
    }
  
    // Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
  def getDefaultRequestXMLMapClass_V6(df: DataFrame): Dataset[DefaultRequestXMLMapClass_V6] =
    {
      val TagggedDF = df.select(
        col("PREF"),
        col("PPRD"),
        col("BAL"),
        col("STS"),
        col("STSDATE"))
        .withColumn("BAL", col("BAL").cast(DoubleType))
        .withColumnRenamed("BAL", "OutStandingBalance") //OutstandingAmount
        .withColumnRenamed("PREF", "AccountNumber")
        .withColumnRenamed("PPRD", "ProductType")
        .withColumn("DefaultStatusDate", to_date(expr("concat(STSDATE.STSDAY, STSDATE.STSMON,STSDATE.STSYEAR)"), "ddMMyyyy"))
        .withColumnRenamed("STS", "DefaultStatus")
        .withColumn("manualUpdateFlag",lit("N"))
        .withColumn("MU_RequestorId",lit(""))
        .withColumn("MU_RequestorEmail",lit(""))
        .withColumn("MU_Reason",lit(""))
        .withColumn("MU_RequestedDate", lit(null).cast(DateType))
        .drop(col("STSDATE"))
                                 //   .as[RegularRequestXMLMapClass_V4]


      import spark.implicits._
      val caseClassDS = TagggedDF.as[DefaultRequestXMLMapClass_V6]
      
      println("##############getDefaultRequestXMLMapClass_V6 Returning DF:") 
      caseClassDS.show(false)
      caseClassDS
    }
   // Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
  def getRegularRequestXMLMapClass_V5(df: DataFrame): Dataset[RegularRequestXMLMapClass_V4] =
    {
    
      val ACYC_ColummnsList=df.select(col("ACYC.*")).schema.fieldNames.toList
      
      
      
      val TagggedDF = df.select(
        col("AREF"),
        col("AOPN"),
        col("APRD"),
        col("ALMT"),
        col("ASAL"),
        col("AEXP"),
        col("APST"),
        col("AINST"),
        col("AFRQ"),
        col("ATNR"),
        col("ASEC"),
        //col("ACYC.ACYCID"),
        //col("ACYC.ALSPD"),
        //col("ACYC.ALSTAM"),
        //col("ACYC.AACS"),
        //col("ACYC.ACUB"),
        //col("ACYC.AODB"),
        //col("ACYC.AASOF"),
        //col("ACYC.ANXPD"),
        col("ACYC.*"),
        col("CONSUMER.CID.CID1"),
        col("CONSUMER.CID.CID2"),
        col("CONSUMER.CAPL"))
        .withColumn("ALMT", col("ALMT").cast(DoubleType))
        .withColumn("AINST", col("AINST").cast(DoubleType))
        .withColumn("ALSTAM", col("ALSTAM").cast(DoubleType))
        .withColumn("ACUB", col("ACUB").cast(DoubleType))
        .withColumn("AODB", col("AODB").cast(DoubleType))
        .withColumn("ATNR", col("ATNR").cast(IntegerType))
        .withColumn("ACYCID", col("ACYCID").cast(IntegerType))
        .withColumnRenamed("AREF", "AccountNumber")
        .withColumnRenamed("APRD", "ProductType")
        .withColumnRenamed("ASAL", "SalaryAssignmentFlag")
        .withColumnRenamed("AFRQ", "PaymentFrequency")
        .withColumnRenamed("ASEC", "SecurityType")
        .withColumn("IssueDate", to_date(expr("concat(AOPN.AOPND, AOPN.AOPNM,AOPN.AOPNY)"), "ddMMyyyy"))
        .withColumn("ExpiryDate", to_date(expr("concat(AEXP.AEXPD, AEXP.AEXPM,AEXP.AEXPY)"), "ddMMyyyy"))
        .withColumn("AsOfDate", to_date(expr("concat(AASOF.AASOFD, AASOF.AASOFM,AASOF.AASOFY)"), "ddMMyyyy"))
        .withColumnRenamed("APST", "ProductStatus")
        .withColumnRenamed("AACS", "PaymentStatus")
        .withColumnRenamed("ATNR", "Tenure")
        .withColumnRenamed("AINST", "InstallmentAmount")
        .withColumnRenamed("ALMT", "OriginalAmount")
        .withColumnRenamed("ACUB", "OutStandingBalance") //OutstandingAmount
        .withColumnRenamed("ACYCID", "LastCycleID")
        .withColumnRenamed("ALSTAM", "LastAmountPaid")
        //.withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
        //.withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
        .withColumnRenamed("AODB", "PastDueBalance")
        .withColumnRenamed("CID1", "IDType")
        .withColumnRenamed("CID2", "IDNumber")
        .withColumnRenamed("CAPL", "ApplicantType")
        //: TO DO Change the AsOfDate to today date OR load date OR CIUploadDate
        .drop(col("AOPN"))
        .drop(col("AEXP"))
        //.drop(col("ALSPD"))
        .drop(col("AASOF"))
      //.drop(col("ANXPD"))

      val TagggedDF2 =
        if (df.select(col("ACYC.*")).schema.fieldNames.contains("ANXPD"))
          TagggedDF.withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
        else
          TagggedDF.withColumn("NextPaymentDate", lit(null).cast(DateType))

      val TagggedDF3 =
        if (df.select(col("ACYC.*")).schema.fieldNames.contains("ALSPD"))
          TagggedDF2.withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
        else
          TagggedDF2.withColumn("LastPaymentDate", lit(null).cast(DateType))

      import spark.implicits._
      val caseClassDS = TagggedDF3.drop(col("ANXPD")).drop(col("ALSPD"))
                      .withColumn("manualUpdateFlag",lit("N"))
                      .withColumn("MU_RequestorId",lit(""))
                      .withColumn("MU_RequestorEmail",lit(""))
                      .withColumn("MU_Reason",lit(""))
                      .withColumn("MU_RequestedDate", lit(null).cast(DateType))
                      .as[RegularRequestXMLMapClass_V4]
      caseClassDS
    }
    // Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
  def getRegularRequestXMLMapClass_V4(df: DataFrame): Dataset[RegularRequestXMLMapClass_V4] =
    {
      val TagggedDF = df.select(
        col("AREF"),
        col("AOPN"),
        col("APRD"),
        col("ALMT"),
        col("ASAL"),
        col("AEXP"),
        col("APST"),
        col("AINST"),
        col("AFRQ"),
        col("ATNR"),
        col("ASEC"),
        //col("ACYC.ACYCID"),
        //col("ACYC.ALSPD"),
        //col("ACYC.ALSTAM"),
        //col("ACYC.AACS"),
        //col("ACYC.ACUB"),
        //col("ACYC.AODB"),
        //col("ACYC.AASOF"),
        //col("ACYC.ANXPD"),
        col("ACYC.*"),
        col("CONSUMER.CID.CID1"),
        col("CONSUMER.CID.CID2"),
        col("CONSUMER.CAPL"))
        .withColumn("ALMT", col("ALMT").cast(DoubleType))
        .withColumn("AINST", col("AINST").cast(DoubleType))
        .withColumn("ALSTAM", col("ALSTAM").cast(DoubleType))
        .withColumn("ACUB", col("ACUB").cast(DoubleType))
        .withColumn("AODB", col("AODB").cast(DoubleType))
        .withColumn("ATNR", col("ATNR").cast(IntegerType))
        .withColumn("ACYCID", col("ACYCID").cast(IntegerType))
        .withColumnRenamed("AREF", "AccountNumber")
        .withColumnRenamed("APRD", "ProductType")
        .withColumnRenamed("ASAL", "SalaryAssignmentFlag")
        .withColumnRenamed("AFRQ", "PaymentFrequency")
        .withColumnRenamed("ASEC", "SecurityType")
        .withColumn("IssueDate", to_date(expr("concat(AOPN.AOPND, AOPN.AOPNM,AOPN.AOPNY)"), "ddMMyyyy"))
        .withColumn("ExpiryDate", to_date(expr("concat(AEXP.AEXPD, AEXP.AEXPM,AEXP.AEXPY)"), "ddMMyyyy"))
        .withColumn("AsOfDate", to_date(expr("concat(AASOF.AASOFD, AASOF.AASOFM,AASOF.AASOFY)"), "ddMMyyyy"))
        .withColumnRenamed("APST", "ProductStatus")
        .withColumnRenamed("AACS", "PaymentStatus")
        .withColumnRenamed("ATNR", "Tenure")
        .withColumnRenamed("AINST", "InstallmentAmount")
        .withColumnRenamed("ALMT", "OriginalAmount")
        .withColumnRenamed("ACUB", "OutStandingBalance") //OutstandingAmount
        .withColumnRenamed("ACYCID", "LastCycleID")
        .withColumnRenamed("ALSTAM", "LastAmountPaid")
        //.withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
        //.withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
        .withColumnRenamed("AODB", "PastDueBalance")
        .withColumnRenamed("CID1", "IDType")
        .withColumnRenamed("CID2", "IDNumber")
        .withColumnRenamed("CAPL", "ApplicantType")
        //: TO DO Change the AsOfDate to today date OR load date OR CIUploadDate
        .drop(col("AOPN"))
        .drop(col("AEXP"))
        //.drop(col("ALSPD"))
        .drop(col("AASOF"))
      //.drop(col("ANXPD"))

      val TagggedDF2 =
        if (df.select(col("ACYC.*")).schema.fieldNames.contains("ANXPD"))
          TagggedDF.withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
        else
          TagggedDF.withColumn("NextPaymentDate", lit(null).cast(DateType))

      val TagggedDF3 =
        if (df.select(col("ACYC.*")).schema.fieldNames.contains("ALSPD"))
          TagggedDF2.withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
        else
          TagggedDF2.withColumn("LastPaymentDate", lit(null).cast(DateType))

      import spark.implicits._
      val caseClassDS = TagggedDF3.drop(col("ANXPD")).drop(col("ALSPD"))
                      .withColumn("manualUpdateFlag",lit("N"))
                      .withColumn("MU_RequestorId",lit(""))
                      .withColumn("MU_RequestorEmail",lit(""))
                      .withColumn("MU_Reason",lit(""))
                      .withColumn("MU_RequestedDate", lit(null).cast(DateType))
                      .as[RegularRequestXMLMapClass_V4]
      caseClassDS
    }
  // Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
  def getRegularRequestXMLMapClass_V2_0(df: DataFrame): Dataset[RegularRequestXMLMapClass] =
    {
      val TagggedDF = df.select(
        col("AREF"),
        col("AOPN"),
        col("APRD"),
        col("ALMT"),
        col("ASAL"),
        col("AEXP"),
        col("APST"),
        col("AINST"),
        col("AFRQ"),
        col("ATNR"),
        col("ASEC"),
        //col("ACYC.ACYCID"),
        //col("ACYC.ALSPD"),
        //col("ACYC.ALSTAM"),
        //col("ACYC.AACS"),
        //col("ACYC.ACUB"),
        //col("ACYC.AODB"),
        //col("ACYC.AASOF"),
        //col("ACYC.ANXPD"),
        col("ACYC.*"),
        col("CONSUMER.CID.CID1"),
        col("CONSUMER.CID.CID2"))
        .withColumn("ALMT", col("ALMT").cast(DoubleType))
        .withColumn("AINST", col("AINST").cast(DoubleType))
        .withColumn("ALSTAM", col("ALSTAM").cast(DoubleType))
        .withColumn("ACUB", col("ACUB").cast(DoubleType))
        .withColumn("AODB", col("AODB").cast(DoubleType))
        .withColumn("ATNR", col("ATNR").cast(IntegerType))
        .withColumn("ACYCID", col("ACYCID").cast(IntegerType))
        .withColumnRenamed("AREF", "AccountNumber")
        .withColumnRenamed("APRD", "ProductType")
        .withColumnRenamed("ASAL", "SalaryAssignmentFlag")
        .withColumnRenamed("AFRQ", "PaymentFrequency")
        .withColumnRenamed("ASEC", "SecurityType")
        .withColumn("IssueDate", to_date(expr("concat(AOPN.AOPND, AOPN.AOPNM,AOPN.AOPNY)"), "ddMMyyyy"))
        .withColumn("ExpiryDate", to_date(expr("concat(AEXP.AEXPD, AEXP.AEXPM,AEXP.AEXPY)"), "ddMMyyyy"))
        .withColumn("AsOfDate", to_date(expr("concat(AASOF.AASOFD, AASOF.AASOFM,AASOF.AASOFY)"), "ddMMyyyy"))
        .withColumnRenamed("APST", "ProductStatus")
        .withColumnRenamed("AACS", "PaymentStatus")
        .withColumnRenamed("ATNR", "Tenure")
        .withColumnRenamed("AINST", "InstallmentAmount")
        .withColumnRenamed("ALMT", "OriginalAmount")
        .withColumnRenamed("ACUB", "OutStandingBalance") //OutstandingAmount
        .withColumnRenamed("ACYCID", "LastCycleID")
        .withColumnRenamed("ALSTAM", "LastAmountPaid")
        //.withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
        //.withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
        .withColumnRenamed("AODB", "PastDueBalance")
        .withColumnRenamed("CID1", "IDType")
        .withColumnRenamed("CID2", "IDNumber")
        //: TO DO Change the AsOfDate to today date OR load date OR CIUploadDate
        .drop(col("AOPN"))
        .drop(col("AEXP"))
        //.drop(col("ALSPD"))
        .drop(col("AASOF"))
      //.drop(col("ANXPD"))

      val TagggedDF2 =
        if (df.select(col("ACYC.*")).schema.fieldNames.contains("ANXPD"))
          TagggedDF.withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
        else
          TagggedDF.withColumn("NextPaymentDate", lit(null).cast(DateType))

      val TagggedDF3 =
        if (df.select(col("ACYC.*")).schema.fieldNames.contains("ALSPD"))
          TagggedDF2.withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
        else
          TagggedDF2.withColumn("LastPaymentDate", lit(null).cast(DateType))

      import spark.implicits._
      val caseClassDS = TagggedDF3.drop(col("ANXPD")).drop(col("ALSPD"))
                      .withColumn("manualUpdateFlag",lit("N")).as[RegularRequestXMLMapClass]
      caseClassDS
    }

  // Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
  def getRequestXMLCaseClassDS_V1_2(df: DataFrame): Dataset[InputXMLMapCaseClass] =
    {
      val TagggedDF = df.select(
        col("AREF"),
        col("AOPN"),
        col("APRD"),
        col("ALMT"),
        col("ASAL"),
        col("AEXP"),
        col("APST"),
        col("AINST"),
        col("AFRQ"),
        col("ATNR"),
        col("ASEC"),
        col("ACON"),
        col("ACYC.ACYCID"),
        col("ACYC.ALSPD"),
        col("ACYC.ALSTAM"),
        col("ACYC.AACS"),
        col("ACYC.ACUB"),
        col("ACYC.AODB"),
        col("ACYC.AASOF"),
        col("ACYC.ANXPD"),
        col("CONSUMER.CAPL"),
        col("CONSUMER.CID.CID1"),
        col("CONSUMER.CID.CID2"))
        .withColumn("ALMT", col("ALMT").cast(DoubleType))
        .withColumn("AINST", col("AINST").cast(DoubleType))
        .withColumn("ALSTAM", col("ALSTAM").cast(DoubleType))
        .withColumn("ACUB", col("ACUB").cast(DoubleType))
        .withColumn("AODB", col("AODB").cast(DoubleType))
        .withColumn("ATNR", col("ATNR").cast(IntegerType))
        .withColumn("ACON", col("ACON").cast(IntegerType))
        .withColumn("ACYCID", col("ACYCID").cast(IntegerType))
        .withColumnRenamed("AREF", "AccountNumber")
        .withColumn("IssueDate", to_date(expr("concat(AOPN.AOPND, AOPN.AOPNM,AOPN.AOPNY)"), "ddMMyyyy"))
        .withColumnRenamed("APRD", "ProductType")
        .withColumnRenamed("ALMT", "OriginalAmount")
        .withColumnRenamed("ASAL", "SalaryAssignmentFlag")
        .withColumn("ExpiryDate", to_date(expr("concat(AEXP.AEXPD, AEXP.AEXPM,AEXP.AEXPY)"), "ddMMyyyy"))
        .withColumnRenamed("APST", "ProductStatus")
        .withColumnRenamed("AINST", "InstallmentAmount")
        .withColumnRenamed("AFRQ", "PaymentFrequency")
        .withColumnRenamed("ATNR", "Tenure")
        .withColumnRenamed("ASEC", "SecurityType")
        .withColumnRenamed("ACON", "NumberOfApplicants")
        .withColumnRenamed("ACYCID", "LastCycleID")
        .withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
        .withColumnRenamed("ALSTAM", "LastAmountPaid")
        .withColumnRenamed("AACS", "PaymentStatus")
        .withColumnRenamed("ACUB", "OutstandingAmount")
        .withColumnRenamed("AODB", "PastDueBalance")
        .withColumn("AsOfDate", to_date(expr("concat(AASOF.AASOFD, AASOF.AASOFM,AASOF.AASOFY)"), "ddMMyyyy"))
        .withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
        .withColumnRenamed("CAPL", "ApplicationType")
        .withColumnRenamed("CID1", "IDType")
        .withColumnRenamed("CID2", "IDNumber")
        //: TO DO Change the AsOfDate to today date OR load date OR CIUploadDate
        .withColumn("DaysDiff", datediff(col("IssueDate"), col("AsOfDate")) === 0)
        .withColumn("NEW_ACCT_FLAG", when(col("DaysDiff").isNull, false).otherwise(col("DaysDiff")))
        .drop(col("AOPN"))
        .drop(col("AEXP"))
        .drop(col("ALSPD"))
        .drop(col("AASOF"))
        .drop(col("ANXPD"))

      import spark.implicits._
      val caseClassDS = TagggedDF.as[InputXMLMapCaseClass]
      caseClassDS
    }

  // Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
  //20220602 : to do : Few columns are optional in input XML based on the data availability ,hence add flexible select and retrun default values for missing columns based on caseclass datatype
  def has_Column(df: DataFrame, columnName: String) = Try(df(columnName)).isSuccess

  def checkColum(df: DataFrame, ColumnName: String, DataType: String) =
    if (Try(df(ColumnName)).isSuccess == true) {
      df(ColumnName)
    } else {

      DataType match {

        case "string" => lit("")
        case "struct" => lit(null).cast("struct<AEXPD:string,AEXPM:string,AEXPY:string>")
        // lit(null).cast(StructType(Nil))
        // lit(StructType(Nil))
        // lit(null)
        // lit(new GenericRowWithSchema(Array(), StructType(Nil)))
        case _        => lit(null)
      }
      // lit(null)

    }

  def getFileName(filePath: String): String = {

   
    if(filePath.contains("/"))
    filePath.substring(filePath.lastIndexOf("/") + 1)
    else
      filePath.substring(filePath.lastIndexOf("\\") + 1)
    

  }

  def getRequestFileDetails(requestFileName: String, runDate: java.sql.Date): DataFrame = {

    try {
      val requestFile = new File(requestFileName)

      if (requestFile.exists && requestFile.isFile()) {
        println("isFile: " + requestFile.isFile())
        println("Path: " + requestFile.getAbsolutePath)
        //println("Name: "+ requestFile.getName)

        //  .withColumn("FILE_TYP", col("FILENAME").substr(4, 3))
        //   .withColumn("RunNumber", col("FILENAME").substr(7, 7))
        //   .withColumn("Product", col("FILENAME").substr(14, 3))

        val RUNDATE = runDate
        val RUNTIMESTAMP = new java.sql.Timestamp(System.currentTimeMillis())
        //val RUNNUMBER=(requestFile.getName).toString().slice(7, 7).toString()
        //val RUNNUMBER=FILENAME.slice(7, 7)
        // val FILENAME=requestFile.getName.substring(0,requestFile.getName.lastIndexOf("."))

        //val FILENAME=getMyName(requestFile)//.getName.substring(0,requestFile.getName.lastIndexOf("."))

        val FILENAME = requestFile.getName.toList

        println("FILENAMELength:" + FILENAME.size)

        /*val FILETYPE=FILENAME.slice(0, 3).mkString
         val RUNNUMBER=FILENAME.slice(3, 10).mkString // requestFile.getName.substring(0,requestFile.getName.lastIndexOf(".")).substring(7, 7)
        val FILEPRODUCT= FILENAME.slice(10, 13).mkString //requestFile.getName.substring(0,requestFile.getName.lastIndexOf(".")).slice(14, 3)
        val KEY=s"$FILETYPE$RUNNUMBER$FILEPRODUCT".toString()
        */

        val FILETYPE = FILENAME.slice(3, 6).mkString
        val RUNNUMBER = FILENAME.slice(6, 13).mkString.toInt // requestFile.getName.substring(0,requestFile.getName.lastIndexOf(".")).substring(7, 7)
        val FILEPRODUCT = FILENAME.slice(13, 16).mkString //requestFile.getName.substring(0,requestFile.getName.lastIndexOf(".")).slice(14, 3)
        val KEY1 = s"$FILETYPE$RUNNUMBER$FILEPRODUCT".toString()
        val KEY2 = s"$FILETYPE$FILEPRODUCT".toString()

        //println("FILENAME: "+ FILENAME)
        //println("RUNNUMBER: "+ RUNNUMBER)
        //println("FILETYPE: "+ FILETYPE)
        //println("FILEPRODUCT: "+ FILEPRODUCT)
        //println("KEY: "+ KEY)

        //val a=requestFile.lastModified()

        val fileDate = new java.sql.Date(requestFile.lastModified())
        println("fileDate: " + fileDate)

        val FILENAME2 = FILENAME.mkString

        // val DS=new RequestFileDetails(KEY,FILENAME,RUNDATE,RUNTIMESTAMP,RUNNUMBER,FILETYPE,FILEPRODUCT,0,0,0,0,0,0,"","")

        //  val DS=List( RequestFileDetails(KEY,FILENAE,RUNDATE,RUNTIMESTAMP,RUNNUMBER,FILETYPE,FILEPRODUCT,0,0,0,0,0,0,"",""))

        import spark.implicits._
        val DS = Seq(RequestFileStats(KEY1, KEY2, requestFile.getName, RUNDATE, RUNTIMESTAMP, RUNNUMBER, FILETYPE, FILEPRODUCT, 0, 0, 0, 0, 0, 0, "", ""))
        val df = DS.toDF

        df.printSchema()
        df.show()
        df
        //println("Name: "+ requestFile.ge)
      } else null

      //requestFile.
    } catch {
      case e: Exception =>
        println("Error : Exception caught in Helpers.getRequestFileDetails method")
        e.printStackTrace()
        //List[File]()
        null

    }
  }
  val udfGetFileName = udf[String, String](getFileName)
  // val udfCheckColum=udf[Column,DataFrame, String ,String](checkColum)
}

 