package com.fds.qcl

import io.delta.tables._
import io.delta._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
import utils.SimahRuleChecker._
import utils.QCLInputParams._

object QCLResponseLoader_V3 {
  
  def  responseProcessor(spark : SparkSession,FILE_NAME:String , RUN_DATE:java.sql.Date, params:utils.QCLInputParams2 , log:Logger):Unit = {

       val fileName =FILE_NAME// params.INPUT_FILE_XMLRESPONSE_NAME
     
      val currentKey1 = fileName.substring(3, 16)
      val currentKey2 = fileName.substring(3, 6) + fileName.substring(13, 16)
      val currentRunNumber = fileName.substring(6, 13).toInt
      val fileType = fileName.substring(3, 6)
      val fileProduct = fileName.substring(13, 16)
      log.info("Filename:" + fileName)
      log.info("currentKey1:" + currentKey1)
      log.info("currentKey2:" + currentKey2)
      log.info("currentRunNumber:" + currentRunNumber)

      val controlTablePath=params.DELTA_TABLE_PATH_BASE+params.DELTA_TABLE_NAME_CONTROL
			val tempTablePath=params.DELTA_TABLE_PATH_WORKING+currentKey1  
			val baseTablePath=params.DELTA_TABLE_PATH_BASE+params.DELTA_TABLE_NAME_BASE
      val fileNamePrepend = RUN_DATE.toString().replace("-", "") + "_" + currentKey1
   
      try {
        val exeControlSql = s"""select * FROM delta.`$controlTablePath` where key1='$currentKey1'""".stripMargin
        import spark.implicits._
        val requestDetailsDF = spark.sql(exeControlSql).na.fill("").distinct().as[RequestFileStats2] //.filter('KEY2 === lit(currentKey2))
        //maxRunDF.printSchema()
        //requestDetailsDF.show()

        if (!requestDetailsDF.isEmpty && requestDetailsDF.count() > 0) {
          val requestKeyRecord = requestDetailsDF.collect()(0)

          val requestKey2 = requestKeyRecord.KEY2
          val requestKey1 = requestKeyRecord.KEY1
          val requestFilename = requestKeyRecord.FILENAME
          val requestRunNumber = requestKeyRecord.RUNNUMBER
          val requestRunDate = requestKeyRecord.RUNDATE

          log.info("requestKey1:" + requestKey1)
          log.info("requestFilename:" + requestFilename)
          log.info("requestRunNumber:" + requestRunNumber)
          log.info("requestRunDate:" + requestRunDate)

          val req_RESP_STS_SDVL = requestKeyRecord.RESP_STS_SDVL
          val req_RESP_STS_SIMAH = requestKeyRecord.RESP_STS_SIMAH

          if (req_RESP_STS_SDVL == "" || req_RESP_STS_SDVL == null)
            log.info(s"SDVL Response is not updated for key $requestKey1")
          else
            log.info("SDVL Response is updated with status :" + req_RESP_STS_SDVL)

          //Setting the Temporary folder
          if (req_RESP_STS_SIMAH != "" && req_RESP_STS_SIMAH != null) {
            log.warn(s"Simah response is already updated in control table for key :$requestKey1  with status $req_RESP_STS_SIMAH")
						log.error("Aborting the program  ")
						log.error(".....QCL Response Processor Execution Aborted @"+ new java.sql.Timestamp(System.currentTimeMillis()))
						System.exit(1)
          } 
          else 
          {
            val responseFileName = params.INPUT_FILE_XMLRESPONSE_PATH + FILE_NAME
            try 
            {
              val responseFile = new File(responseFileName)

              if (!responseFile.exists || !responseFile.isFile()) {
                log.warn(s"ResponseFile: $responseFileName is not exists , check input params and re-execute the program")
                log.error(" Aborting the QCL Response Processor")
                System.exit(1)
              }
            } catch {
              case e: Exception =>
                log.error(s"Exception caught while reading ResponseFile: $responseFileName , aborting the program")
                System.exit(1)
                log.error(e)
            }
            log.info(s"SIMAH Response is not loaded for key $requestKey1 , Starting Response load..")
            val tempFolder = s"$params.INPUT_FILE_XMLRESPONSE_PATH sparkTmp_$$requestKey1"
            try
            {
            val responseDF = spark.read.format("com.databricks.spark.xml")
              //.option("rowTag", "ITEM") //RESPONSE
              .option("inferSchema", false)
              .option("rowTag", params.INPUT_FILE_XMLRESPONSE_ROWTAG)
              .schema(utils.SimahCaseClasses.responseFileSchema)
              //.option("rowTag", "RESPONSE")
              //.option("rowTag", "ITEM")
              //#         .option("samplingRatio", "1")
              .load(responseFileName)
              //.withColumn("FileName1", lit(params.INPUT_FILE_XMLREQUEST_NAME))
              .withColumn("file", input_file_name)
              .withColumn("FILENAME", udfGetFileName(input_file_name))
              .withColumn("FILE_TYP", col("FILENAME").substr(4, 3))
              .withColumn("RunNumber", col("FILENAME").substr(7, 7))
              .withColumn("Product", col("FILENAME").substr(14, 3))

            //responseDF.printSchema()
            //responseDF.show()

            val flattenedResponseDF = makeItFlat(responseDF)

            //flattenedResponseDF.printSchema()
            //flattenedResponseDF.show()

            import spark.implicits._
            val respDF = flattenedResponseDF.select(
              'HEADER_RUN_NO.as("RUN_NO"),
              when('MESSAGE_ITEM_PPRD.isNull, 'MESSAGE_ITEM_APRD).otherwise('MESSAGE_ITEM_PPRD).as("FILE_TYP"),
              when('MESSAGE_ITEM_PREF.isNull, 'MESSAGE_ITEM_AREF).otherwise('MESSAGE_ITEM_PREF).as("ACCOUNT_NUMBER"),
              'MESSAGE_ITEM_ERROR_RSP_MSG.as("RSP_MSG"),
              'MESSAGE_ITEM_ERROR_DATA.as("DATA"),
              'MESSAGE_ITEM_ERROR_FIELD.as("FIELD_TAG"),
              'SERVICE,
              'STATUS)

            //respDF.show()

            log.info(s"Response file $FILE_NAME count:" + respDF.count())

            val summaryDF = flattenedResponseDF.select(
              col("ACTION"),
              col("HEADER_ERR_ITEMS").as("ERROR_ITEMS"),
              col("HEADER_MEMBER_ID").as("MEMBER_ID"),
              col("HEADER_RUN_NO").as("RUN_NO"),
              col("HEADER_TOT_ITEMS").as("TOTAL_ITEMS"),
              col("HEADER_USER_ID").as("USER_ID"),
              col("SERVICE"),
              col("STATUS"))
              .distinct()
              
            summaryDF.show()
            val tmp = "_resp"
            val tempTablePath2=params.DELTA_TABLE_PATH_WORKING+currentKey1+tmp
            
            try
            {
              val tempTableSQL = s"CREATE OR REPLACE TABLE delta.`$tempTablePath2` (AccountNumber STRING , ProductType STRING , RSP_MSG STRING ) USING DELTA"
              spark.sql(tempTableSQL)
              log.info(s"Working table  :$tempTablePath2 created")
              val tempDf = respDF.select(col("ACCOUNT_NUMBER").alias("AccountNumber"), col("FILE_TYP").alias("ProductType"), col("RSP_MSG"))
              //tempDf.printSchema()
              //tempDf.show()
              tempDf.write.format("delta").mode("overwrite").save(tempTablePath2)
              log.info(s"inserted data to working table :$tempTablePath2")
              val tempDf2 = spark.sql(s"select *  FROM delta.`$tempTablePath2` ")
              //tempDf2.show()
            }
            catch {
                case e: Exception =>
                 log.error(" Exception caught while saving RejectionReconReport ")
                  log.error(e)
            }

            try {
              log.info(s"Started updating  data to working table :$tempTablePath")
              ////log.info("Start Time :" + new java.sql.Timestamp(System.currentTimeMillis()))

              val updateSql = s"MERGE INTO delta.`$tempTablePath` AS resp USING delta.`$tempTablePath2` AS sresp ON resp.AccountNumber = sresp.AccountNumber WHEN MATCHED THEN UPDATE SET resp.SIMAH_REJ_FLAG = 'Y' , resp.SIMAH_REJ_MSG = sresp.RSP_MSG"

              spark.sql(updateSql)
              //log.info("End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
              log.info(s"Completed updating working table with simah response  data ")

              val rejValidationDF = spark.sql(s"select *  FROM delta.`$tempTablePath` ")
                .withColumn("Mismatch_Flag", when(('SDV_REJ_FLAG === "N" && 'SIMAH_REJ_FLAG === "N") || ('SDV_REJ_FLAG === "Y" && 'SIMAH_REJ_FLAG === "Y"), lit("N")).otherwise(lit("Y")))
                .filter('SDV_REJ_FLAG === "Y" || 'SIMAH_REJ_FLAG === "Y")

              //rejValidationDF.show()

              val outputPath = params.OUTPUT_FILE_REPORTS_PATH
              try {
                log.info("Started saving the RejectionReconReport file")

                val tmpFolderName = fileNamePrepend + "_" + "RejectionReconReport"
                val newfileName = tmpFolderName + ".csv"

                rejValidationDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath + tmpFolderName)
                moveFiles(outputPath + tmpFolderName, outputPath, newfileName)
                log.info("Completed saving the file with name : " + outputPath + newfileName)
              } catch {
                case e: Exception =>
                 log.error("Exception caught while saving RejectionReconReport ")
                  log.error(e)
              }
            
            
              //Start history table update
              try {
                log.info("Started updating history table @ "+ new java.sql.Timestamp(System.currentTimeMillis()))
                 val historyUpdateSql = s"""MERGE INTO delta.`$baseTablePath` AS hist
                                    |USING (select * from delta.`$tempTablePath` where SIMAH_REJ_FLAG='N' ) AS curr
                                    |ON hist.AccountNumber = curr.AccountNumber and hist.ProductType = curr.ProductType and hist.ProductStatus != 'C' and hist.DefaultStatus not in ('FS','NS')
                                    |WHEN MATCHED THEN UPDATE SET
                                    |hist.AsOfDate = curr.AsOfDate ,
                                    |hist.ExpiryDate = curr.ExpiryDate ,
                                    |hist.InstallmentAmount = curr.InstallmentAmount ,
                                    |hist.IssueDate = curr.IssueDate ,
                                    |hist.LastAmountPaid = curr.LastAmountPaid ,
                                    |hist.LastCycleID = curr.LastCycleID ,
                                    |hist.LastPaymentDate = curr.LastPaymentDate ,
                                    |hist.NextPaymentDate = curr.NextPaymentDate ,
                                    |hist.OriginalAmount = curr.OriginalAmount ,
                                    |hist.OutStandingBalance = curr.OutStandingBalance ,
                                    |hist.PastDueBalance = curr.PastDueBalance ,
                                    |hist.PaymentFrequency = curr.PaymentFrequency ,
                                    |hist.PaymentStatus = curr.PaymentStatus ,
                                    |hist.ProductStatus = curr.ProductStatus ,
                                    |hist.SalaryAssignment = curr.SalaryAssignmentFlag ,
                                    |hist.SecurityType = curr.SecurityType ,
                                    |hist.Tenure = curr.Tenure ,
                                    |hist.CIUpdateDate = '$RUN_DATE' """.stripMargin

                val regularHistoryUpdateSql2 = s"""MERGE INTO delta.`$baseTablePath` AS hist
                                    |USING (select * from delta.`$tempTablePath` where SIMAH_REJ_FLAG='N' ) AS curr
                                    |ON hist.AccountNumber = curr.AccountNumber and hist.ProductType = curr.ProductType and hist.ProductStatus != 'C' and (hist.DefaultStatus is null or hist.DefaultStatus not in ('FS','NS'))
                                    |WHEN MATCHED THEN UPDATE SET
                                    |hist.AsOfDate = curr.AsOfDate ,
                                    |hist.ExpiryDate = curr.ExpiryDate ,
                                    |hist.InstallmentAmount = curr.InstallmentAmount ,
                                    |hist.IssueDate = curr.IssueDate ,
                                    |hist.LastAmountPaid = curr.LastAmountPaid ,
                                    |hist.LastCycleID = curr.LastCycleID ,
                                    |hist.LastPaymentDate = curr.LastPaymentDate ,
                                    |hist.NextPaymentDate = curr.NextPaymentDate ,
                                    |hist.OriginalAmount = curr.OriginalAmount ,
                                    |hist.OutStandingBalance = curr.OutStandingBalance ,
                                    |hist.PastDueBalance = curr.PastDueBalance ,
                                    |hist.PaymentFrequency = curr.PaymentFrequency ,
                                    |hist.PaymentStatus = curr.PaymentStatus ,
                                    |hist.ProductStatus = curr.ProductStatus ,
                                    |hist.SalaryAssignment = curr.SalaryAssignmentFlag ,
                                    |hist.SecurityType = curr.SecurityType ,
                                    |hist.CloseDate = case when curr.ProductStatus='C' then '$RUN_DATE' when hist.ProductStatus != 'W' and curr.ProductStatus='W' then curr.AsOfDate else hist.CloseDate end ,
                                    |hist.Tenure = curr.Tenure ,
                                    |hist.CIUpdateDate = '$RUN_DATE' ,
                                    |hist.DefaultStatus = case when hist.ProductStatus != 'W' and curr.ProductStatus='W' and (hist.DefaultStatus='NULL' or hist.DefaultStatus=null or hist.DefaultStatus='') then 'OS' else hist.DefaultStatus end,
                                    |hist.DefaultLoadDate = case when hist.ProductStatus != 'W' and curr.ProductStatus='W' then '$RUN_DATE' else hist.DefaultLoadDate end ,
                                    |hist.DefaultOriginalAmount= case when   hist.ProductStatus != 'W' and curr.ProductStatus='W' then curr.OutStandingBalance else hist.DefaultOriginalAmount end ,
                                    |hist.DefaultOutStandingAmount= case when   hist.ProductStatus != 'W' and curr.ProductStatus='W' then curr.OutStandingBalance else hist.DefaultOutStandingAmount end """.stripMargin

                val defaultHistoryUpdateSql = s"""MERGE INTO delta.`$baseTablePath` AS hist
                                    |USING (select * from delta.`$tempTablePath` where SIMAH_REJ_FLAG='N' ) AS curr
                                    |ON hist.AccountNumber = curr.AccountNumber and hist.ProductType = curr.ProductType and hist.ProductStatus != 'C' and hist.DefaultStatus is not null and hist.DefaultStatus not in ('FS','NS')
                                    |WHEN MATCHED THEN UPDATE SET
                                    |hist.DefaultStatus = curr.DefaultStatus ,
                                    |hist.DefaultStatusDate = curr.DefaultStatusDate ,
                                    |hist.DefaultChangeDate =  case when hist.DefaultStatus != curr.DefaultStatus then  '$RUN_DATE' else hist.DefaultChangeDate end,
                                    |hist.DefaultOutStandingAmount= curr.OutStandingBalance """.stripMargin

                val regularHistoryInsertSql = s"""MERGE INTO delta.`$baseTablePath` AS hist
                                    |USING (select * from delta.`$tempTablePath` where SIMAH_REJ_FLAG='N') AS curr
                                    |ON hist.AccountNumber = curr.AccountNumber and hist.ProductType = curr.ProductType
                                    |WHEN NOT MATCHED THEN
                                    |INSERT(AccountNumber,AsOfDate,ExpiryDate,InstallmentAmount,IssueDate,
                                    |LastAmountPaid,LastCycleID,LastPaymentDate,NextPaymentDate,
                                    |OriginalAmount,OutStandingBalance,PastDueBalance,PaymentFrequency,
                                    |PaymentStatus,ProductStatus,ProductType,SalaryAssignment,SecurityType,
                                    |Tenure,CIUpdateDate,CIUploadDate)
                                    |VALUES(curr.AccountNumber,curr.AsOfDate,curr.ExpiryDate,curr.InstallmentAmount,curr.IssueDate,
                                    |curr.LastAmountPaid,curr.LastCycleID,curr.LastPaymentDate,curr.NextPaymentDate,
                                    |curr.OriginalAmount,curr.OutStandingBalance,curr.PastDueBalance,curr.PaymentFrequency,
                                    |curr.PaymentStatus,curr.ProductStatus,curr.ProductType,curr.SalaryAssignmentFlag,curr.SecurityType,
                                    |curr.Tenure,'$RUN_DATE','$RUN_DATE')  """.stripMargin

                if (fileType.equalsIgnoreCase("REG")) {
                  //spark.sql(historyMergeSql)
                  //spark.sql(historyUpdateSql)
                  spark.sql(regularHistoryUpdateSql2)
                  spark.sql(regularHistoryInsertSql)
                } else if (fileType.equalsIgnoreCase("DEF")) 
                {
                  spark.sql(defaultHistoryUpdateSql)
                } else {
                  log.warn(s"Invalid file type: $fileType    ")
                 log.error(" Aborting the Program , Plase Check provided file type , file type can be either REG(REGULAR) or DEF (DEFAULT)")
                  System.exit(1)
                }

                log.info("History table update completed successfully @" + new java.sql.Timestamp(System.currentTimeMillis()))
              } // end try block for history table update
              catch {
                case e: Exception =>
                 log.error("Exception caught while updating  history table ")
                 log.error("Aborting QCL ResponseProcessor")
                  log.error(e)
                  System.exit(1)
              } // end catch history update block

              try {
                log.info("Started updating control table with response stats")

                val respSummaryRow = summaryDF.collect()(0)

                //val ACTION=respSummaryRow.get(0)
                val ERROR_ITEMS = respSummaryRow.get(1).toString().toInt
                //val MEMBER_ID=respSummaryRow.get(2)
                val RUN_NO = respSummaryRow.get(3).toString().toInt
                val TOTAL_ITEMS = respSummaryRow.get(4).toString().toInt
                val SERVICE = respSummaryRow.get(6).toString()
                val RESP_STATUS = respSummaryRow.get(7).toString()
                /*
                +------+-----------+---------+------+-----------+-------+----------+------+
                |ACTION|ERROR_ITEMS|MEMBER_ID|RUN_NO|TOTAL_ITEMS|USER_ID|   SERVICE|STATUS|
                +------+-----------+---------+------+-----------+-------+----------+------+
                |     A|        103|      119| 15720|      29922|FTSNCBB|REGULAR_AC| ERROR|
                +------+-----------+---------+------+-----------+-------+----------+------+    */

                // Update //COUNT_REJ_SIMAH|COUNT_REJ_TOTAL|COUNT_REJ_EXTRA|COUNT_REJ_MISSING|RESP_STS_SIMAH
                val missing_count = rejValidationDF.filter('SIMAH_REJ_FLAG === "Y" && 'SDV_REJ_FLAG === "N").count().toInt
                val extra_count = rejValidationDF.filter('SIMAH_REJ_FLAG === "N" && 'SDV_REJ_FLAG === "Y").count().toInt
                val total_rej_count = extra_count + ERROR_ITEMS

                val exeControlupdateSql = s"""UPDATE delta.`$controlTablePath` SET
                |COUNT_REJ_SIMAH=$ERROR_ITEMS ,
                |COUNT_REJ_TOTAL=$total_rej_count ,
                |COUNT_REJ_MISSING=$missing_count ,           
                |RESP_STS_SIMAH='$RESP_STATUS' ,
                |COUNT_REJ_EXTRA=$extra_count
                |where key1='$currentKey1'""".stripMargin

                spark.sql(exeControlupdateSql)

                //spark.sql(s"UPDATE delta.`$controlTablePath` SET id = (id + 100) WHERE (id % 2 == 0)")
                spark.sql(s"SELECT * FROM delta.`$controlTablePath` where key1='$currentKey1'").show()
                log.info(s"Completed updating control table with response stats for key : $currentKey1")

                try {
                  //log.info("Usage : Start : Saving the rejValidationDF file")
                  val exeDF = spark.sql(s"SELECT * FROM delta.`$controlTablePath` where RUNTIMESTAMP is not null ")
                  exeDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(params.OUTPUT_FILE_REPORTS_PATH + "SDV_Execution_Stats")
                  moveFiles(params.OUTPUT_FILE_REPORTS_PATH + "SDV_Execution_Stats", params.OUTPUT_FILE_REPORTS_PATH, "SDV_Execution_Stats.csv")
                  //log.info("Usage : End : Saved the file : " +params.OUTPUT_FILE_DQ_PATH  + "SDV_Execution_Stats.csv")
                } catch {
                  case e: Exception =>
                   log.error("Exception caught while saving SDV_Execution_Stats ")
                    log.error(e)
                }

              } // End of control table update Try block
              catch {
                case e: Exception =>
                 log.error("Exception caught while updating  respponse stats in control table ")
                  log.error(e)
                  System.exit(1)
              } // End of control table update catch block

              try {

                //val deltaTable = DeltaTable.forPath(spark, tempTablePath)
                //deltaTable.delete()
                // spark.sql(s"DROP TABLE IF EXISTS $tempTablePath")
                //val tempTable = new File(tempTablePath)
                //if (tempTable.exists()) FileUtils.deleteDirectory(tempTable)
                deleteFolder3(tempTablePath)
                log.info(s"Working table $tempTablePath deleted / dropped")
              } catch {
                case e: Exception =>
                  log.error(s"Exception caught while deleting working table: $tempTablePath ")
                  log.error(e)
              }
              
              }catch {
                case e: Exception =>
                 log.error("Exception caught while loading response file "+FILE_NAME)
                  log.error(e)
              } // End try response load

            } // end main try block
            catch {
              case e: Exception =>
                log.error(e)

            }

          } //end else block for previous key status update

        } //end of maxRunDF empty check if  block
        else {
          log.warn(s"Unable to fetch the previous run details for file type: $fileType and product_type:$fileProduct ")
					log.error("Aborting the Program ")
					log.error("QCL Respponse Processor Execution Aborted @"+ new java.sql.Timestamp(System.currentTimeMillis()))
					System.exit(1)        
					}

      } // end of main try block
      catch {
        case e: Exception =>
          log.error("Exception caught in QCL Respponse Processor main block")
          log.error(e)
      }
  }

}