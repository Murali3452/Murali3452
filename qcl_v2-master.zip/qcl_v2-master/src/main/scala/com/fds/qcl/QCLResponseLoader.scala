package com.fds.qcl

import io.delta.tables._
import io.delta._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter ,File ,FileOutputStream,PrintWriter}

//import utils.SimahCaseClasses._
////#import utils.SimahCaseClasses_V1_2._
import utils.SimahCaseClasses._
//import utils.CBDataValidatorHelpers_V1_1._
////#import utils.CBDataValidatorHelpers_V2_0._
import utils.QCLHelperFunctions._
//import utils.SimahRuleChecker_V1_0._
//import utils.SimahRuleChecker_V1_2._
////#import utils.SimahRuleChecker_V1_3._
import utils.SimahRuleChecker._
////#import utils.CBDataValidatorParams_V1_1._
import utils.QCLInputParams._


object QCLResponseLoader {
	def main(args: Array[String]) {
		Logger.getLogger("org").setLevel(Level.ERROR)
		val conf = new SparkConf().setAppName("LogFileParser").setMaster("local[*]").set("spark.testing.memory", "2147480000") //local
		val spark = SparkSession
		.builder()
		.appName("SparkSQL")
		.master("local[*]")
		.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
		.config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
		.config(conf)
		//#.config("spark.sql.warehouse.dir", "C:\\Bigdata\\warehouse\\deltatable_sqlpaths2")
		//.config("spark.sql.warehouse.dir", "E:\\Murali\\bigdata_folder\\DataProfiling\\deltalake\\warehouse\\deltatable_sql")
		//.config("spark.sql.warehouse.dir", "E:\\Murali\\bigdata_folder\\DataProfiling\\Simah\\LAKEHOUSE\\BASE")
		.getOrCreate()
		//E:\Murali\bigdata_folder\DataProfiling\Simah\LAKEHOUSE\BASE
		val programStartTime = spark.sparkContext.broadcast(new java.sql.Timestamp(System.currentTimeMillis()))
		println(".....SimahDataValidator Execution Started @"+ programStartTime.value)
		//val log = Logger.getLogger("FILE")
		if(args == null || args.length== 0 || args.length== 1 || (!args(0).equalsIgnoreCase("-config")) || args.length != 3 || args(2).length() !=10 )
		{
			println("Usage : Insufficiant Number of arguments , kindly input config parameters and try again")
			println("Usage : Sample command :SimahDataValidator -config \\configfilepath\\configfilename")
			println("Error : Aborting the Program ")
			println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
			System.exit(1)
		}
		else
		{ 
			val params= setParams(args(1))
					if(params.configFileLoad)
						printParams(params)
						else
						{
							println(s"Usage : Unable to load the config file kindly check the provided path is correct :"+args(1))
							println("Error : Aborting the Program ")
							println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
							System.exit(1)
						}
			val runDate=getRunDate(args(2))
					if (runDate == new java.sql.Date(0))
					{
						println(s"Usage : Restart the program by supplying rundate in dd-MM-yyyy format:"+args(2))
						println("Error : Aborting the Program ")
						println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
						System.exit(1)
					}//else println(s"runDate: $runDate")
			//val fileName=params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME
			val fileName=params.INPUT_FILE_XMLRESPONSE_NAME
					//val currentKey1=params.INPUT_FILE_XMLREQUEST_NAME.substring(3, 16)
					//val currentKey2=params.INPUT_FILE_XMLREQUEST_NAME.substring(3,6)+params.INPUT_FILE_XMLREQUEST_NAME.substring(13, 16)
					//val currentRunNumber=params.INPUT_FILE_XMLREQUEST_NAME.substring(6, 13).toInt
					val currentKey1=fileName.substring(3, 16)
					val currentKey2=fileName.substring(3,6)+fileName.substring(13, 16)
					val currentRunNumber=fileName.substring(6, 13).toInt
					val fileType=fileName.substring(3,6)
					val fileProduct=fileName.substring(13, 16)
					println("Filename:"+fileName)
					println("currentKey1:"+currentKey1)
					println("currentKey2:"+currentKey2)
					println("currentRunNumber:"+currentRunNumber)
					val controlTablePath="C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/exe_control_table"
					val tempTablePath=s"C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/TEMP/$currentKey1"
					val baseTablePath="C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/base_hist"
					val fileNamePrepend=runDate.toString().replace("-","")+"_"+currentKey1        
					println("TempTable Path:"+tempTablePath)
					/*try
			    {  //val sql1=s"DELETE FROM delta.`$controlTablePath` WHERE KEY1='$currentKey1'"
						   val sql= s"UPDATE delta.`$controlTablePath` SET RESP_STS_SIMAH=''  WHERE KEY1='$currentKey1'"
								println("sql:"+sql)
								//spark.sql(sql)
								println(s"Deleted control table record for key:$currentKey1")
			    }
			  catch
			  {
			    case e:Exception => 
			      e.printStackTrace() 
			   }
			  System.exit(1)
        */
			try
			{
				val exeControlSql=s"""select * FROM delta.`$controlTablePath` where key1='$currentKey1'""".stripMargin
						//val sqlstr=s"select ext.* FROM delta.`$controlTablePath` as ext inner join (select KEY2,max(RUNNUMBER) as MAXRUNNUMBER   FROM delta.`$controlTablePath` group by KEY2) as  maxrun on  ext.RUNNUMBER=maxrun.MAXRUNNUMBER and ext.key2=maxrun.key2"
						//  val sqlstr2=s"select KEY2,max(RUNNUMBER) as MAXRUNNUMBER   FROM delta.`$controlTablePath` group by KEY2"
						//spark.sql(s"select *  FROM delta.`$controlTablePath`").show() 
						import spark.implicits._
						val requestDetailsDF=spark.sql(exeControlSql).na.fill("").distinct().as[RequestFileStats2]//.filter('KEY2 === lit(currentKey2))
								//maxRunDF.printSchema()
								requestDetailsDF.show()
								if(!requestDetailsDF.isEmpty && requestDetailsDF.count() > 0 )
								{
									val requestKeyRecord=requestDetailsDF.collect()(0)
											val requestKey2=requestKeyRecord.KEY2
											val requestKey1=requestKeyRecord.KEY1
											val requestFilename=requestKeyRecord.FILENAME
											val requestRunNumber=requestKeyRecord.RUNNUMBER
											val requestRunDate=requestKeyRecord.RUNDATE
											println("requestKey1:"+requestKey1)
											println("requestFilename:"+requestFilename)
											println("requestRunNumber:"+requestRunNumber)
											println("requestRunDate:"+requestRunDate)
											val req_RESP_STS_SDVL=requestKeyRecord.RESP_STS_SDVL
											val req_RESP_STS_SIMAH= requestKeyRecord.RESP_STS_SIMAH
											if(req_RESP_STS_SDVL == "" || req_RESP_STS_SDVL == null)
												println(s"SDVL Response is not updated for key $requestKey1")
												else
													println("SDVL Response is updated with status :"+req_RESP_STS_SDVL)
													//Setting the Temporary folder
													if(req_RESP_STS_SIMAH != "" &&  req_RESP_STS_SIMAH  != null )
													{
														println(s"Usage : Simah response is already updated in control table for key :$requestKey1  with status $req_RESP_STS_SIMAH")
														println("Error : Exiting the program  ")
														println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
														System.exit(1)
													}
													else
													{
														println(s"SIMAH Response is not loaded for key $requestKey1 , Starting Response load..")
														val tempFolder=s"$params.INPUT_FILE_XMLRESPONSE_PATH sparkTmp_$$requestKey1"
														val responseDF = spark.read.format("com.databricks.spark.xml")
														//.option("rowTag", "ITEM") //RESPONSE
														.option("inferSchema",false)
														.option("rowTag", params.INPUT_FILE_XMLRESPONSE_ROWTAG)
														.schema(utils.SimahCaseClasses.responseFileSchema)
														//.option("rowTag", "RESPONSE")
														//.option("rowTag", "ITEM")
														//#         .option("samplingRatio", "1")
														.load(params.INPUT_FILE_XMLRESPONSE_PATH+params.INPUT_FILE_XMLRESPONSE_NAME)
														.withColumn("FileName1", lit(params.INPUT_FILE_XMLREQUEST_NAME))                                             
														.withColumn("file",input_file_name)
														.withColumn("FILENAME",udfGetFileName(input_file_name))
														.withColumn("FILE_TYP", col("FILENAME").substr(4, 3))
														.withColumn("RunNumber", col("FILENAME").substr(7, 7))
														.withColumn("Product", col("FILENAME").substr(14, 3))
														responseDF.printSchema()
														responseDF.show()
														val flattenedResponseDF = makeItFlat(responseDF)
														flattenedResponseDF.printSchema()
														flattenedResponseDF.show()
														import spark.implicits._
														val respDF=flattenedResponseDF.select (
																'HEADER_RUN_NO.as("RUN_NO"),
																when ('MESSAGE_ITEM_PPRD.isNull , 'MESSAGE_ITEM_APRD).otherwise('MESSAGE_ITEM_PPRD).as("FILE_TYP"),
																when ('MESSAGE_ITEM_PREF.isNull , 'MESSAGE_ITEM_AREF).otherwise('MESSAGE_ITEM_PREF).as("ACCOUNT_NUMBER"),
																'MESSAGE_ITEM_ERROR_RSP_MSG.as("RSP_MSG"),
																'MESSAGE_ITEM_ERROR_DATA.as("DATA"),
																'MESSAGE_ITEM_ERROR_FIELD.as("FIELD_TAG"),
																'SERVICE,
																'STATUS
																)
														respDF.show()
														println("respDF count:" + respDF.count())
														val summaryDF=             flattenedResponseDF.select(col("ACTION"),
																col("HEADER_ERR_ITEMS").as("ERROR_ITEMS"),
																col("HEADER_MEMBER_ID").as("MEMBER_ID"),
																col("HEADER_RUN_NO").as("RUN_NO"),
																col("HEADER_TOT_ITEMS").as("TOTAL_ITEMS"),
																col("HEADER_USER_ID").as("USER_ID"),
																col("SERVICE"),
																col("STATUS"))
														.distinct()
														summaryDF.show()
														val tmp="_resp"
														val tempTablePath2=s"C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/TEMP/$currentKey1$tmp"
														val tempTableSQL=s"CREATE OR REPLACE TABLE delta.`$tempTablePath2` (AccountNumber STRING , ProductType STRING , RSP_MSG STRING ) USING DELTA"
														spark.sql(tempTableSQL)
														println(s"temp table created :$tempTablePath2")
														val tempDf=respDF.select(col("ACCOUNT_NUMBER").alias("AccountNumber"),col("FILE_TYP").alias("ProductType"),col("RSP_MSG"))
														//tempDf.printSchema()
														//tempDf.show()
														tempDf.write.format("delta").mode("overwrite").save(tempTablePath2)
														println(s"inserted data to temp table :$tempTablePath2")
														val tempDf2= spark.sql(s"select *  FROM delta.`$tempTablePath2` ")
														tempDf2.show()
														try
														{
															println(s"start updating the data to temp table :$tempTablePath")
															println("Start Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
															val updateSql=s"MERGE INTO delta.`$tempTablePath` AS resp USING delta.`$tempTablePath2` AS sresp ON resp.AccountNumber = sresp.AccountNumber WHEN MATCHED THEN UPDATE SET resp.SIMAH_REJ_FLAG = 'Y' , resp.SIMAH_REJ_MSG = sresp.RSP_MSG"
															spark.sql(updateSql)
															println("End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
															println(s"updated the table with actual response  data ")
															val rejValidationDF= spark.sql(s"select *  FROM delta.`$tempTablePath` ")
															.withColumn("Mismatch_Flag", when( ('SDV_REJ_FLAG==="N" && 'SIMAH_REJ_FLAG==="N") || ('SDV_REJ_FLAG==="Y" && 'SIMAH_REJ_FLAG==="Y")  ,lit("N")).otherwise(lit("Y")) )
															.filter('SDV_REJ_FLAG==="Y" || 'SIMAH_REJ_FLAG==="Y")
															rejValidationDF.show()
															val outputPath=params.OUTPUT_FILE_ERR_PATH
															try
															{
																println("Usage : Start : Saving the RejectionReconReport file")
																val tmpFolderName=fileNamePrepend+"_"+"RejectionReconReport"
																		val newfileName=tmpFolderName+".csv"
																		rejValidationDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
																		moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
																		println("Usage : End : Saved the file with name : " + outputPath + newfileName)
															}
															catch{
															case e: Exception =>
															println("Error : Exception caught while saving RejectionReconReport ")
															e.printStackTrace()
															}
															try
															{
																println("Updating control table with response stats")
																val respSummaryRow=summaryDF.collect()(0)
																//val ACTION=respSummaryRow.get(0)
																val ERROR_ITEMS=respSummaryRow.get(1).toString().toInt
																//val MEMBER_ID=respSummaryRow.get(2)
																val RUN_NO=respSummaryRow.get(3).toString().toInt
																val TOTAL_ITEMS=respSummaryRow.get(4).toString().toInt
																val SERVICE=respSummaryRow.get(6).toString()
																val RESP_STATUS=respSummaryRow.get(7).toString()

																// Update //COUNT_REJ_SIMAH|COUNT_REJ_TOTAL|COUNT_REJ_EXTRA|COUNT_REJ_MISSING|RESP_STS_SIMAH
																val missing_count=rejValidationDF.filter('SIMAH_REJ_FLAG==="Y" && 'SDV_REJ_FLAG==="N").count().toInt
																val extra_count=rejValidationDF.filter('SIMAH_REJ_FLAG==="N" && 'SDV_REJ_FLAG==="Y").count().toInt
																val total_rej_count =extra_count+ERROR_ITEMS
																val exeControlupdateSql=s"""UPDATE delta.`$controlTablePath` SET
																|COUNT_REJ_SIMAH=$ERROR_ITEMS ,
																|COUNT_REJ_TOTAL=$total_rej_count ,
																|COUNT_REJ_MISSING=$missing_count ,           
																|RESP_STS_SIMAH='$RESP_STATUS' ,
																|COUNT_REJ_EXTRA=$extra_count
																|where key1='$currentKey1'""".stripMargin
																spark.sql(exeControlupdateSql)
																//spark.sql(s"UPDATE delta.`$controlTablePath` SET id = (id + 100) WHERE (id % 2 == 0)")
																spark.sql(s"SELECT * FROM delta.`$controlTablePath` where key1='$currentKey1'").show()
																println("Updated control table table with response stats")
																try
																{
																	//println("Usage : Start : Saving the rejValidationDF file")
																	val exeDF=spark.sql(s"SELECT * FROM delta.`$controlTablePath`")
																			exeDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(params.OUTPUT_FILE_ERR_PATH +"SDV_Execution_Stats")
																			moveFiles(params.OUTPUT_FILE_ERR_PATH +"SDV_Execution_Stats",params.OUTPUT_FILE_ERR_PATH, "SDV_Execution_Stats.csv")
																			//println("Usage : End : Saved the file : " +params.OUTPUT_FILE_DQ_PATH  + "SDV_Execution_Stats.csv")
																}
																catch{
																case e: Exception =>
																println("Error : Exception caught while saving SDV_Execution_Stats ")
																e.printStackTrace()
																}
															} // End of control table update Try block
															catch{
															case e: Exception =>
															println("Error : Exception caught while updating  respponse stats in control table ")
															e.printStackTrace()
															System.exit(1)
															} // End of control table update catch block
															//Start history table update
															try
															{
																println(" Start Updating history table")
																println("Start Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
																val historyUpdateSql=s"""MERGE INTO delta.`$baseTablePath` AS hist
																|USING (select * from delta.`$tempTablePath` where SIMAH_REJ_FLAG='N' ) AS curr
																|ON hist.AccountNumber = curr.AccountNumber and hist.ProductType = curr.ProductType and hist.ProductStatus != 'C' and hist.DefaultStatus not in ('FS','NS')
																|WHEN MATCHED THEN UPDATE SET
																|hist.AsOfDate = curr.AsOfDate ,
																|hist.ExpiryDate = curr.ExpiryDate ,
																|hist.InstallmentAmount = curr.InstallmentAmount ,
																|hist.IssueDate = curr.IssueDate ,
																|hist.LastAmountPaid = curr.LastAmountPaid ,
																|hist.LastCycleID = curr.LastCycleID ,
																|hist.LastPaymentDate = curr.LastPaymentDate ,
																|hist.NextPaymentDate = curr.NextPaymentDate ,
																|hist.OriginalAmount = curr.OriginalAmount ,
																|hist.OutStandingBalance = curr.OutStandingBalance ,
																|hist.PastDueBalance = curr.PastDueBalance ,
																|hist.PaymentFrequency = curr.PaymentFrequency ,
																|hist.PaymentStatus = curr.PaymentStatus ,
																|hist.ProductStatus = curr.ProductStatus ,
																|hist.SalaryAssignment = curr.SalaryAssignmentFlag ,
																|hist.SecurityType = curr.SecurityType ,
																|hist.Tenure = curr.Tenure ,
																|hist.CIUpdateDate = '$runDate' """.stripMargin
																val historyInsertSql=s"""MERGE INTO delta.`$baseTablePath` AS hist
																|USING (select * from delta.`$tempTablePath` where SIMAH_REJ_FLAG='N') AS curr
																|ON hist.AccountNumber = curr.AccountNumber and hist.ProductType = curr.ProductType
																|WHEN NOT MATCHED THEN
																|INSERT(AccountNumber,AsOfDate,ExpiryDate,InstallmentAmount,IssueDate,
																|LastAmountPaid,LastCycleID,LastPaymentDate,NextPaymentDate,
																|OriginalAmount,OutStandingBalance,PastDueBalance,PaymentFrequency,
																|PaymentStatus,ProductStatus,ProductType,SalaryAssignment,SecurityType,
																|Tenure,CIUpdateDate,CIUploadDate)
																|VALUES(curr.AccountNumber,curr.AsOfDate,curr.ExpiryDate,curr.InstallmentAmount,curr.IssueDate,
																|curr.LastAmountPaid,curr.LastCycleID,curr.LastPaymentDate,curr.NextPaymentDate,
																|curr.OriginalAmount,curr.OutStandingBalance,curr.PastDueBalance,curr.PaymentFrequency,
																|curr.PaymentStatus,curr.ProductStatus,curr.ProductType,curr.SalaryAssignmentFlag,curr.SecurityType,
																|curr.Tenure,'$runDate','$runDate')  """.stripMargin
																val historyMergeSql=s"""MERGE INTO delta.`$baseTablePath` AS hist
																|USING (select * from delta.`$tempTablePath` where SIMAH_REJ_FLAG='N') AS curr
																|ON hist.AccountNumber = curr.AccountNumber and hist.ProductType = curr.ProductType
																|WHEN MATCHED THEN UPDATE SET
																|hist.AsOfDate = curr.AsOfDate ,
																|hist.ExpiryDate = curr.ExpiryDate ,
																|hist.InstallmentAmount = curr.InstallmentAmount ,
																|hist.IssueDate = curr.IssueDate ,
																|hist.LastAmountPaid = curr.LastAmountPaid ,
																|hist.LastCycleID = curr.LastCycleID ,
																|hist.LastPaymentDate = curr.LastPaymentDate ,
																|hist.NextPaymentDate = curr.NextPaymentDate ,
																|hist.OriginalAmount = curr.OriginalAmount ,
																|hist.OutStandingBalance = curr.OutStandingBalance ,
																|hist.PastDueBalance = curr.PastDueBalance ,
																|hist.PaymentFrequency = curr.PaymentFrequency ,
																|hist.PaymentStatus = curr.PaymentStatus ,
																|hist.ProductStatus = curr.ProductStatus ,
																|hist.SalaryAssignment = curr.SalaryAssignmentFlag ,
																|hist.SecurityType = curr.SecurityType ,
																|hist.Tenure = curr.Tenure ,
																|hist.CIUpdateDate = '$runDate'
																|WHEN NOT MATCHED THEN
																|INSERT(AccountNumber,AsOfDate,ExpiryDate,InstallmentAmount,IssueDate,
																|LastAmountPaid,LastCycleID,LastPaymentDate,NextPaymentDate,
																|OriginalAmount,OutStandingBalance,PastDueBalance,PaymentFrequency,
																|PaymentStatus,ProductStatus,ProductType,SalaryAssignment,SecurityType,
																|Tenure,CIUpdateDate,CIUploadDate)
																|VALUES(curr.AccountNumber,curr.AsOfDate,curr.ExpiryDate,curr.InstallmentAmount,curr.IssueDate,
																|curr.LastAmountPaid,curr.LastCycleID,curr.LastPaymentDate,curr.NextPaymentDate,
																|curr.OriginalAmount,curr.OutStandingBalance,curr.PastDueBalance,curr.PaymentFrequency,
																|curr.PaymentStatus,curr.ProductStatus,curr.ProductType,curr.SalaryAssignmentFlag,curr.SecurityType,
																|curr.Tenure,'$runDate','$runDate')  """.stripMargin
																//spark.sql(historyMergeSql)    
																spark.sql(historyUpdateSql) 
																spark.sql(historyInsertSql)
																println(" Hostory table Update completed successfully")
																println("End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
															} // end try block for history table update
															catch
															{
															case e: Exception =>
															println("Error : Exception caught while updating  history table ")
															e.printStackTrace()
															System.exit(1)
															} // end catch history update block
														} // end main try block
														catch
														{
														case e: Exception =>
														e.printStackTrace()
														}
														println(".....SimahDataValidator Execution Completed @"+ new java.sql.Timestamp(System.currentTimeMillis()))
														println("Start Time :" + programStartTime.value)
														println("End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
														println("Execution Time: " + getTimeDifference(programStartTime.value,new java.sql.Timestamp(System.currentTimeMillis())))
														System.exit(0)
														/// ************************************************************** End of response steps   
														import spark.implicits._
														val histCaseclassDF =spark.sql(s" *  FROM delta.`C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/base_hist` as A")//.as[InputHistMapCaseClass2]
														val requestXMLDF = spark.read.format("com.databricks.spark.xml")
														.option("inferSchema",false)
														.option("rowTag", params.INPUT_FILE_XMLREQUEST_ROWTAG)//.option("rowTag", "ACCOUNT")
														.load(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME)//.load(curXMLFilePath)
														val finalRequestXMLDF=addMissingColumns(requestXMLDF,requestXMLFileREGSchema)
														val requestXMLCaseClassDF=getRegularRequestXMLMapClass_V2_0(finalRequestXMLDF)
														val curHistDS=requestXMLCaseClassDF.join(histCaseclassDF ,
																requestXMLCaseClassDF("AccountNumber") === histCaseclassDF("H_AccountNumber") &&
																requestXMLCaseClassDF("ProductType") === histCaseclassDF("H_ProductType")
																, "left")
														.withColumn("NEW_ACCT_FLAG", when('H_AccountNumber.isNotNull,lit(false)).otherwise(lit(true))).as[RequestPlusHistCaseClass]
																// .withColumn("NewFlag", when('H_ProductType.isNull , true ).otherwise(false) )
																curHistDS.cache()
																val dataQualityDF= requestXMLCaseClassDF
																val errorsDF= respDF
																val reqWithRejDetails=requestXMLCaseClassDF.join(errorsDF,Seq("AccountNumber","ProductType"),"left" )
																.withColumn("SDV_REJ_FLAG", when('ErrorIDs.isNull || 'ErrorIDs===null || 'ErrorIDs==="" , lit("N")).otherwise(lit("Y")))
																.withColumn("SIMAH_REJ_FLAG",  lit("N"))
																.withColumn("SIMAH_REJ_MSG",  lit(""))
																.withColumnRenamed("ErrorMsgs", "SDV_REJ_MSG")
																println("Temporary Table schema")
																reqWithRejDetails.printSchema()
																reqWithRejDetails.show()
																val rejectRecDF=  errorsDF.filter(col("ValidFlag")=!=("VALID")).toDF().join(requestXMLCaseClassDF , Seq("AccountNumber","ProductType") , "inner")
																val sdvRespDF =rejectRecDF.select(col("AccountNumber").alias("AREF") ,col("ProductType").alias("APRD"),col("ErrorMsgs").alias("RSP_MSG") )
																val dqRecordsDF=dataQualityDF.filter(col("ValidFlag")=!=("VALID")).join(requestXMLCaseClassDF , Seq("AccountNumber","ProductType") , "inner")
																val validRequestRecordsDF=requestXMLDF.join(errorsDF.select('AccountNumber.as("AREF")).filter(col("ValidFlag")===("VALID")).toDF() , Seq("AREF") )
																val NewAcctsDF=curHistDS.
																select('AccountNumber,'IssueDate,'ProductType,'OriginalAmount,'SalaryAssignmentFlag,
																		'ExpiryDate,'ProductStatus,'InstallmentAmount,'PaymentFrequency,'Tenure,'SecurityType,
																		'LastCycleID,'LastPaymentDate,'LastAmountPaid,'PaymentStatus,'OutstandingBalance,
																		'PastDueBalance,'AsOfDate,'NextPaymentDate,'IDType,'IDNumber,'NEW_ACCT_FLAG).filter('H_AccountNumber.isNull)
																println("Start gatharing the run stats")
																val COUNT_INFILE_REC=requestXMLDF.count().toInt
																val COUNT_OUTFILE_REC=validRequestRecordsDF.count().toInt
																val COUNT_REJ_SDVL=rejectRecDF.count().toInt
																val COUNT_REJ_SIMAH=0
																val COUNT_REJ_TOTAL=COUNT_REJ_SDVL // Update after loading SIMAH response COUNT_REJ_SIMAH+COUNT_REJ_SDVL
																val COUNT_REJ_EXTRA=0          // Update after loading SIMAH response
																val COUNT_REJ_MISSING=0       // Update after loading SIMAH response
																val COUNT_ACCTS_NEW=NewAcctsDF.count().toInt
																val COUNT_DQ_REC=dqRecordsDF.count().toInt
																val RESP_STS_SDVL= { if(COUNT_REJ_SDVL>0) "REJ" else "OK"}
														val RESP_STS_SIMAH="" // Update after loading SIMAH response COUNT_REJ_SIMAH+COUNT_REJ_SDVL
																println("End gatharing the run stats") 
																//Block to prepare the header
																//Uncomment for version 1 files  val headerLines=getHeader(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME)
																val headerLines=getHeader2(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME)
																val totalItems= "<TOT_ITEMS>" + COUNT_OUTFILE_REC +"</TOT_ITEMS>"
																val endLines = Seq(totalItems , "</HEADER>" )
																val finalHeaderString=headerLines ++ endLines
																//End of block to header preparation
																//Start of code blcok to write the temp request xml file by filtering the error records
																try
														{
																	println("Usage : Start : Saving the curated XML file Records file")
																	validRequestRecordsDF
																	// .coalesce(1)
																	.repartition(1)
																	.write.mode("overwrite")
																	.format("com.databricks.spark.xml")
																	.option("rootTag", params.OUTPUT_FILE_XMLREQUET_ROOTTAG) //.option("rootTag", "MESSAGE")
																	.option("rowTag", params.OUTPUT_FILE_XMLREQUET_ROWTAG) //.option("rowTag", "ACCOUNT")
																	//.save(params.OUTPUT_FILE_XMLREQUET_PATH + params.OUTPUT_FILE_XMLREQUET_NAME)
																	//.save(params.OUTPUT_FILE_XMLREQUET_PATH +"tmp")
																	.save(tempFolder)
																	//Function call to merge all part files
																	try { mergeFiles3(getListOfFiles(tempFolder),finalHeaderString, params.OUTPUT_FILE_XMLREQUET_PATH + params.OUTPUT_FILE_XMLREQUET_NAME,tempFolder)}
																	catch
																	{
																	case e: Exception =>
																	println("Error : Exception caught in delete temp directory / merge files method")
																	e.printStackTrace()
																	}
																	println("Usage : End : Saved the curated XML file :" +params.OUTPUT_FILE_XMLREQUET_PATH + params.OUTPUT_FILE_XMLREQUET_NAME)
														}
														catch
														{
														case e: Exception =>
														println("Error : Exception caught in writing curated XML file")
														e.printStackTrace()
														}
														//End of block for curated request xml file generation
														try
														{
															println("Start appending control table with current run stats")
															val currentTime=new java.sql.Timestamp(System.currentTimeMillis())
															val runStatsDF=Seq(RequestFileStats2 (currentKey1,currentKey2,fileName,runDate,currentTime,currentRunNumber,fileType,fileProduct,COUNT_INFILE_REC,COUNT_OUTFILE_REC,COUNT_REJ_SDVL,COUNT_REJ_SIMAH,COUNT_REJ_TOTAL,COUNT_REJ_EXTRA,COUNT_REJ_MISSING,COUNT_ACCTS_NEW,COUNT_DQ_REC,RESP_STS_SDVL,"")).toDF()
															runStatsDF.write.format("delta").mode("append").save(controlTablePath)
															println("End appending control table with current run stats")
															println(s"inserted control table with current run stats for key1:$currentKey1")
															spark.sql(s"select *  FROM delta.`$controlTablePath` where KEY1 = '$currentKey1'").show()
														}
														catch
														{
														case e:Exception =>
														println("Exception caught while appending control table with current run stats")
														e.printStackTrace()
														}
													}//end else block for previous key status update
								}//end of maxRunDF empty check if  block
								else
								{
									println(s"Usage : unable to fetch the previous run details for file type: $fileType and product_type:$fileProduct ")
									println("Error : Aborting the Program ")
									println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
									System.exit(1)
								}
			} // end of main try block
			catch
			{
			case e:Exception =>
			println("Exception caught in main block")
			e.printStackTrace()
			}
		} // close args else block
	}
}