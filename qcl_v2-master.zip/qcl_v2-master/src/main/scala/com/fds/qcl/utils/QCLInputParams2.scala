package com.fds.qcl.utils


import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import org.apache.spark.sql._
import org.apache.spark.sql.types._

case class QCLInputParams2(propMap: Map[String,String] , qclHome: String)
{
	
			val configFileLoad = if(propMap.isEmpty) false else true
      
			val DELTA_TABLE_PATH_BASE             :String =if(propMap.getOrElse("DELTA_TABLE_PATH_BASE", "").isEmpty()) s"$qclHome/deltalake/base/" else propMap.get("DELTA_TABLE_PATH_BASE").get
			val DELTA_TABLE_PATH_WORKING          :String =if(propMap.getOrElse("DELTA_TABLE_PATH_WORKING", "").isEmpty()) s"$qclHome/deltalake/working/" else propMap.get("DELTA_TABLE_PATH_WORKING").get
			val DELTA_TABLE_PATH_SNAPSHOT         :String =if(propMap.getOrElse("DELTA_TABLE_PATH_SNAPSHOT", "").isEmpty()) s"$qclHome/deltalake/snapshot/" else propMap.get("DELTA_TABLE_PATH_SNAPSHOT").get
			val DELTA_TABLE_PATH_REPORTING        :String =if(propMap.getOrElse("DELTA_TABLE_PATH_REPORTING", "").isEmpty()) s"$qclHome/deltalake/reporting/" else propMap.get("DELTA_TABLE_PATH_REPORTING").get
			
			val DELTA_TABLE_NAME_BASE             :String =if(propMap.getOrElse("DELTA_TABLE_NAME_BASE", "").isEmpty()) "base_hist" else propMap.get("DELTA_TABLE_NAME_BASE").get
			val DELTA_TABLE_NAME_BASERAW          :String =if(propMap.getOrElse("DELTA_TABLE_NAME_BASERAW", "").isEmpty()) "base_hist_raw" else propMap.get("DELTA_TABLE_NAME_BASERAW").get
			val DELTA_TABLE_NAME_CONTROL          :String =if(propMap.getOrElse("DELTA_TABLE_NAME_CONTROL", "").isEmpty()) "exe_control" else propMap.get("DELTA_TABLE_NAME_CONTROL").get
      
			val  INPUT_FILE_HISTDATA_CHARACTERSET :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_CHARACTERSET","").isEmpty())  "UTF-16" else propMap.get("INPUT_FILE_HISTDATA_CHARACTERSET").get
      val  INPUT_FILE_HISTDATA_DELIMETER    :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_DELIMETER","").isEmpty())  "," else propMap.get("INPUT_FILE_HISTDATA_DELIMETER").get
      val  INPUT_FILE_HISTDATA_FORMAT       :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_FORMAT","").isEmpty())  "csv" else propMap.get("INPUT_FILE_HISTDATA_FORMAT").get
      val  INPUT_FILE_HISTDATA_HEADER       :Boolean =propMap.getOrElse("INPUT_FILE_HISTDATA_HEADER","true").toBoolean
      val  INPUT_FILE_HISTDATA_PARSINGMODE  :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_PARSINGMODE","").isEmpty())  "DROPMALFORMED" else propMap.get("INPUT_FILE_HISTDATA_PARSINGMODE").get
      val  INPUT_FILE_HISTDATA_PATH         :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_PATH","").isEmpty())  s"$qclHome/input/history/" else propMap.get("INPUT_FILE_HISTDATA_PATH").get
      val  INPUT_FILE_MANUALDATA_CHARACTERSET:String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_CHARACTERSET","").isEmpty())  "UTF-8" else propMap.get("INPUT_FILE_MANUALDATA_CHARACTERSET").get
      val  INPUT_FILE_HISTDATA_DATEFORMAT    :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_DATEFORMAT","").isEmpty())  "dd-MM-yyyy" else propMap.get("INPUT_FILE_HISTDATA_DATEFORMAT").get
      val  INPUT_FILE_MANUALDATA_DATEFORMAT  :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_DATEFORMAT","").isEmpty())  "dd-MM-yyyy" else propMap.get("INPUT_FILE_MANUALDATA_DATEFORMAT").get
      val  INPUT_FILE_MANUALDATA_DELIMETER   :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_DELIMETER","").isEmpty())  "," else propMap.get("INPUT_FILE_MANUALDATA_DELIMETER").get
      val  INPUT_FILE_MANUALDATA_FORMAT      :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_FORMAT","").isEmpty())  "csv" else propMap.get("INPUT_FILE_MANUALDATA_FORMAT").get
      val  INPUT_FILE_MANUALDATA_HEADER      :Boolean =propMap.getOrElse("INPUT_FILE_HISTDATA_HEADER","true").toBoolean
      val  INPUT_FILE_MANUALDATA_PARSINGMODE :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_PARSINGMODE","").isEmpty())  "DROPMALFORMED" else propMap.get("INPUT_FILE_MANUALDATA_PARSINGMODE").get
      val  INPUT_FILE_MANUALDATA_PATH        :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_PATH","").isEmpty())  s"$qclHome/input/manualupdate/" else propMap.get("INPUT_FILE_MANUALDATA_PATH").get
      val  INPUT_FILE_XMLREQUEST_CHARACTERSET:String =if(propMap.getOrElse("INPUT_FILE_XMLREQUEST_CHARACTERSET","").isEmpty())  "UTF-8" else propMap.get("INPUT_FILE_XMLREQUEST_CHARACTERSET").get
      val  INPUT_FILE_XMLREQUEST_PATH        :String =if(propMap.getOrElse("INPUT_FILE_XMLREQUEST_PATH","").isEmpty())  s"$qclHome/input/request/" else propMap.get("INPUT_FILE_XMLREQUEST_PATH").get
      val  INPUT_FILE_XMLREQUEST_ROWTAG      :String =if(propMap.getOrElse("INPUT_FILE_XMLREQUEST_ROWTAG","").isEmpty())  "ACCOUNT"  else propMap.get("INPUT_FILE_XMLREQUEST_ROWTAG").get
      val  INPUT_FILE_XMLRESPONSE_CHARACTERSET:String =if(propMap.getOrElse("INPUT_FILE_XMLRESPONSE_CHARACTERSET","").isEmpty())  "UTF-8" else propMap.get("INPUT_FILE_XMLRESPONSE_CHARACTERSET").get
      val  INPUT_FILE_XMLRESPONSE_PATH        :String =if(propMap.getOrElse("INPUT_FILE_XMLRESPONSE_PATH","").isEmpty())  s"$qclHome/input/response/" else propMap.get("INPUT_FILE_XMLRESPONSE_PATH").get
      val  INPUT_FILE_XMLRESPONSE_ROWTAG      :String =if(propMap.getOrElse("INPUT_FILE_XMLRESPONSE_ROWTAG","").isEmpty())  "RESPONSE" else propMap.get("INPUT_FILE_XMLRESPONSE_ROWTAG").get
      val  OUTPUT_FILE_REPORTS_DELIMETER      :String =if(propMap.getOrElse("OUTPUT_FILE_REPORTS_DELIMETER","").isEmpty())  "," else propMap.get("OUTPUT_FILE_REPORTS_DELIMETER").get
      val  OUTPUT_FILE_REPORTS_FORMAT         :String =if(propMap.getOrElse("OUTPUT_FILE_REPORTS_FORMAT","").isEmpty())  "csv" else propMap.get("OUTPUT_FILE_REPORTS_FORMAT").get
      val  OUTPUT_FILE_REPORTS_PATH           :String =if(propMap.getOrElse("OUTPUT_FILE_REPORTS_PATH","").isEmpty())  s"$qclHome/output/reports/" else propMap.get("OUTPUT_FILE_REPORTS_PATH").get
      val  OUTPUT_FILE_XMLREQUET_PATH         :String =if(propMap.getOrElse("OUTPUT_FILE_XMLREQUET_PATH","").isEmpty())  s"$qclHome/output/request/" else propMap.get("OUTPUT_FILE_XMLREQUET_PATH").get
      val  OUTPUT_FILE_XMLREQUET_ROOTTAG      :String =if(propMap.getOrElse("OUTPUT_FILE_XMLREQUET_ROOTTAG","").isEmpty())  "MESSAGE" else propMap.get("OUTPUT_FILE_XMLREQUET_ROOTTAG").get
      val  OUTPUT_FILE_XMLREQUET_ROWTAG       :String =if(propMap.getOrElse("OUTPUT_FILE_XMLREQUET_ROWTAG"," ").isEmpty())  "ACCOUNT" else propMap.get("OUTPUT_FILE_XMLREQUET_ROWTAG").get
      val  OUTPUT_FILE_XMLRESPONSE_PATH       :String =if(propMap.getOrElse("OUTPUT_FILE_XMLRESPONSE_PATH","").isEmpty())  s"$qclHome/output/response/" else propMap.get("OUTPUT_FILE_XMLRESPONSE_PATH").get
      val  OUTPUT_FILE_XMLRESPONSE_ROOTTAG    :String =if(propMap.getOrElse("OUTPUT_FILE_XMLRESPONSE_ROOTTAG","").isEmpty())  "MESSAGE" else propMap.get("OUTPUT_FILE_XMLRESPONSE_ROOTTAG").get
      val  OUTPUT_FILE_XMLRESPONSE_ROWTAG     :String =if(propMap.getOrElse("OUTPUT_FILE_XMLRESPONSE_ROWTAG","").isEmpty())  "ACCOUNT" else propMap.get("OUTPUT_FILE_XMLRESPONSE_ROWTAG").get
      val  OUTPUT_FILE_LOGS_PATH               :String =if(propMap.getOrElse("OUTPUT_FILE_LOGS_PATH","").isEmpty())  s"$qclHome/logs/" else propMap.get("OUTPUT_FILE_LOGS_PATH").get
      
		
}
object QCLInputParams2 {
	def setParams( qclHome :String):QCLInputParams2=
		{
				val propMap=
						try
				{
							Source.fromFile(s"$qclHome/config/qcl_config.properties").getLines().filterNot(line => line.startsWith("#")).filter(line => line.contains("="))
							.map { line => // println(line)
							val tokens = line.split("=")
							(tokens(0).trim() -> (if (tokens.length >= 2) tokens(1).trim() else ""))
							}.toMap
				}
				catch{
				case e:Exception  =>
				println("************ Exception Caught in reading the Configuration File:"+s"$qclHome/config/qcl_config.properties")
				e.printStackTrace()
				Map[String,String]()
				}
				//val schemaFile=spark.sparkContext.textFile(input_schemafile).map(x=>x.split('|')).collect()
				new QCLInputParams2(propMap ,qclHome)
		}
	//val params2=DataProfilerParams
}