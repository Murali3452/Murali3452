package com.fds.qcl.utils

import SimahCaseClasses._

import java.text.DecimalFormat
import java.sql.Timestamp
import java.sql.Date
import org.apache.spark.sql.functions._
import org.apache.spark._
import org.apache.spark.SparkContext._
import scala.util.Try
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import java.util.regex.Pattern
import scala.util.matching.Regex
import scala.io._
import org.apache.commons.io.FileUtils
//import scala.io.{Source, BufferedSource}
import scala.collection.mutable.LinkedHashSet
import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.ListBuffer
import scala.collection.mutable.ArrayBuffer
import java.io.{ BufferedWriter, FileWriter ,File ,FileOutputStream,PrintWriter,BufferedReader,FileReader}
import scala.collection.JavaConversions._
import scala.reflect.io.Directory
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.catalyst.ScalaReflection

object QCLHelperFunctions
{
	val conf = new SparkConf().setAppName("SimahRuleChecker").setMaster("local[*]").set("spark.testing.memory", "2147480000").set("spark.kryoserializer.buffer.max", "512") //local
			val spark = SparkSession.builder.appName("SimahRuleChecker_App").config(conf).getOrCreate() //local
			def isSchemaNested(df: DataFrame): Boolean = {
					df.schema.fields.flatMap(field => {
						field.dataType match {
						case arrayType: ArrayType => {
							Array(true)
						}
						case mapType: MapType => {
							Array(true)
						}
						case structType: StructType => {
							Array(true)
						}
						case _ => {
							Array(false)
						}
						}
					}).exists(b => b)
	}
	private def flattenSchema(schema: StructType, prefix: String = null): Array[Column] = {
			schema.fields.flatMap(field => {
				val columnName = if (prefix == null) field.name else prefix + "." + field.name
						field.dataType match {
						case arrayType: ArrayType => {
							Array[Column](explode_outer(col(columnName)).as(columnName.replace(".", "_")))
						}
						case mapType: MapType => {
							None
						}
						case structType: StructType => {
							flattenSchema(structType, columnName)
						}
						case _ => {
							val columnNameWithUnderscores = columnName.replace(".", "_")
									val metadata = new MetadataBuilder().putString("encoding", "ZSTD").build()
									Array(col(columnName).as(columnNameWithUnderscores, metadata))
						}
				}
			}).filter(field => field != None)
	}
	def makeItFlat(df: DataFrame): DataFrame = {
			if (isSchemaNested(df)) {
				val flattenedSchema = flattenSchema(df.schema)
						makeItFlat(df.select(flattenedSchema: _*))
			} else {
				df
			}
	}
	def addMissingColumns(df: DataFrame, requestFileSchema: StructType) : DataFrame =
		{
				val targetSchema = requestFileSchema.fields.map(x=> (x.name.toString() , x.dataType )).toMap
						val targetColumns=requestFileSchema.fieldNames.toList

						targetColumns.foldLeft(df)
						{
					(df,column) =>
					{
						if(df.columns.contains(column) == false)
						{
							println("inFunc:-----:"+ column +" : "+targetSchema(column) )
							targetSchema(column).typeName match
							{
							case "string" => df.withColumn(column,lit(null).cast(targetSchema(column)))
							case "struct" => df.withColumn(column,lit(null).cast( targetSchema(column)))
							case "array"  => df.withColumn(column,lit(array()).cast(targetSchema(column)))
							case _        => df.withColumn(column,lit(null))
							}
						}
						else (df)
					}
						}
		}

	
	def getListOfResponceFiles(dir: String): List[File] = {
			try {
				val d = new File(dir)
						if (d.exists && d.isDirectory) {
							//d.listFiles.filter(_.isFile).toList
							val allFiles = d.listFiles.filter(_.isFile)
									return allFiles.toList
						} else {
							List[File]()
						}
			} catch {
			case e: Exception =>
			println("Error : Exception caught in Helpers.getListOfResponceFiles method")
			e.printStackTrace()
			List[File]()
			}
	}
	def getListOfFiles(dir: String):List[File] = {
			val d = new File(dir)
					if (d.exists && d.isDirectory)
					{
						//d.listFiles.filter(_.isFile).toList
						val allFiles=d.listFiles.filter(_.isFile)
								val onlyPartFiles=allFiles.filter(p => p.getName.startsWith("part")).toList
								return onlyPartFiles
					} else {
						List[File]()
					}
	}
	def deleteFolder(dir: String): Unit =
		{
				try {
					val directory = new Directory(new File(dir))
							//   directory.deleteRecursively()
							// println("dirPath:"+dir)
							if (directory.isDirectory && directory.exists)
							{
								if(! directory.deleteRecursively() )
									deleteFolder(dir)
									println("Usage : Deleting the temporary folder :"+dir)
							}
				} catch {
				case e: Exception =>
				println("Error : Exception caught in delete temp directory method")
				e.printStackTrace()
				// some file could not be deleted
				}
		}
	//This function will delete all sub folder and files using commons.io.FileUtils from the dir path received in argument
	def deleteFolder3(dir: String): Unit =
		{
				//Function call to delete temp directory all part files
				try{
					//Thread.sleep(30000)
					val tempDir = new File(dir)
							if (tempDir.exists())
								FileUtils.deleteDirectory(tempDir)
								else
									println(s"The folder path : $dir is not exists ")
				} catch {
				case e: Exception =>
				println("Error : Exception caught in Helpers.deleteFolder3 method")
				e.printStackTrace()
				}
		}
	def getHeader(inputFilePath : String ):Seq[String]={
			try
			{
				//val headerLines=Source.fromFile(inputFilePath).getLines().toList
				//Below line is added to avoid exception in cmd  java.nio.charset.UnmappableCharacterException: Input length = 1
				val headerLines=Source.fromFile(inputFilePath)("UTF-8").getLines().toList
						var lines =Seq[String]()
						for(i <- 0 to 7)//headerLines.length)
						{
							println("Line:"+i+" : "+headerLines(i))
							val line=headerLines(i)
							lines = lines :+ line//.add(line)
							// lines=lines ++ headerLines(i).t
						}
				return lines
						//.filterNot(line => line.startsWith("#")).filter(line => line.contains("="))
						// .map { line => // println(line)
						//   val tokens = line.split("=")
						//  (tokens(0).trim() -> (if (tokens.length >= 2) tokens(1).trim() else ""))
						// }.toMap
			}
			catch{
			case e:Exception  =>
			println("************ Exception Caught in getHeader:"+inputFilePath)
			println(e.printStackTrace())
			e.printStackTrace()
			Seq[String]()
			}
	}
	def getHeader2(inputFilePath : String ):Seq[String]={
			try
			{
				//val headerLines=Source.fromFile(inputFilePath).getLines().toList
				//Below line is added to avoid exception in cmd  java.nio.charset.UnmappableCharacterException: Input length = 1
				//*   val headerLines=Source.fromFile(inputFilePath)("UTF-8").getLines().toList
				val reader = new BufferedReader(new FileReader(inputFilePath))
						var lines =Seq[String]()
						for(i <- 0 to 8)//headerLines.length)
						{
							//println("Line:"+i+" : "+headerLines(i))
							val line=reader.readLine()
									// println("Line:"+i+" : "+line)
									lines = lines :+ line//.add(line)
									// lines=lines ++ headerLines(i).t
						}
				/*
       for(i <- 0 to 8)//headerLines.length)
       {
         //println("Line:"+i+" : "+headerLines(i))
         val line=headerLines(i)
         lines = lines :+ line//.add(line)
        // lines=lines ++ headerLines(i).t
       }
				 * */
				return lines
						//.filterNot(line => line.startsWith("#")).filter(line => line.contains("="))
						// .map { line => // println(line)
						//   val tokens = line.split("=")
						//  (tokens(0).trim() -> (if (tokens.length >= 2) tokens(1).trim() else ""))
						// }.toMap
			}
			catch{
			case e:Exception  =>
			println("************ Exception Caught in getHeader:"+inputFilePath)
			println(e.printStackTrace())
			e.printStackTrace()
			Seq[String]()
			}
	}
	def mergeFiles(allFiles : List[File] ,headerLines: Seq[String], outputFilePath:String,tempFolder:String ):Unit = {
			//val part0 = Source.fromFile("part-00000.txt").getLines
			// val part1 = Source.fromFile("part-00001.txt").getLines
			// val part2 = part0.toList ++ part1.toList
			var allLines =List[String]()
					for(file <- allFiles)
					{
						//val a=Source.fromFile(file.getAbsoluteFile).getLines().toSeq
						// println("file.getAbsoluteFile:"+file.getAbsoluteFile)
						//Below line is added to avoid exception in cmd  java.nio.charset.UnmappableCharacterException: Input length = 1
						// allLines=  Source.fromFile(file.getAbsoluteFile).getLines().toList  ++ allLines
						allLines=  Source.fromFile(file.getAbsoluteFile)("UTF-8").getLines().toList  ++ allLines
								//allLines.foreach(println(f))
					}
			//val bufferWrite = new BufferedWriter(new FileWriter(new File(outputFilePath)))
			val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath),true))
					//Wrting header string
					headerLines.foreach(line => bufferWrite.write(line + "\n"))
					//Wrting all part files from spark xml
					allLines.foreach(line => bufferWrite.write(line + "\n"))
					//wrting end line to file
					bufferWrite.write("</REQUEST>")
					bufferWrite.close
					//Adding addtional code for removing temp directory
					try {
						val directory = new Directory(new File(tempFolder))
								//   directory.deleteRecursively()
								// println("dirPath:"+dir)
								if (directory.isDirectory && directory.exists)
								{
									directory.deleteRecursively()
									println("Usage : Deleting the temporary folder :"+tempFolder)
								}
					} catch {
					case e: Exception =>
					println("Error : Exception caught in delete temp directory method")
					e.printStackTrace()
					// some file could not be deleted
					}
	}
	def mergeFiles2(allFiles : List[File] ,headerLines: Seq[String], outputFilePath:String,tempFolder:String ):Unit = {
			//val bufferWrite = new BufferedWriter(new FileWriter(new File(outputFilePath)))
			val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath),true))
					//Wrting header string
					headerLines.foreach(line => bufferWrite.write(line + "\n"))
					bufferWrite.close
					for(file <- allFiles)
					{
						//var allLines =List[String]()
						//allLines=  Source.fromFile(file.getAbsoluteFile)("UTF-8").getLines().toList  ++ allLines
						val allLines=Source.fromFile(file.getAbsoluteFile)("UTF-8").getLines().toList
								val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath),true))
								allLines.foreach(line => bufferWrite.write(line + "\n"))
								//  bufferWrite.write(allLines + "\n")
								bufferWrite.close
					}
			val bufferWrite2 = new PrintWriter(new FileOutputStream(new File(outputFilePath),true))
					bufferWrite2.write("</REQUEST>")
					bufferWrite2.close
					//Function call to delete the temp directory
					//temp stop  deleteFolder(tempFolder)
	}
	def getRunDate(dateString : String):java.sql.Date=
		{
				try{
					val array=dateString.split("-")
							if(array(0).toInt > 31 || array(1).toInt > 12)
							{
								println(s"Usage : Enterd run date is not a valid date or not in expected format, please enter date in dd-MM-yyyy format:"+dateString)
								new java.sql.Date(0)
							}
							else
							{
								val  tempDate=new java.text.SimpleDateFormat("dd-MM-yyyy").parse(dateString)
										val runDate=new java.sql.Date(tempDate.getTime())
										println("runDate:"+runDate)
										runDate
							}
				}
				catch{
				case e : Exception =>
				println(s"Usage : Enterd run date is not a valid date or not in expected format, please enter date in dd-MM-yyyy format:"+dateString)
				//println("Error : Aborting the Program ")
				// println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
				new java.sql.Date(0)
				}  
		}
	def moveFiles(oldFilePath:String ,newFilePath:String, newName:String):Unit=
		{
				try{
					val sourceDirectory = new File(oldFilePath)
							println("Path: " + sourceDirectory.getAbsolutePath)
							if (sourceDirectory.exists && sourceDirectory.isDirectory)
							{
								//d.listFiles.filter(_.isFile).toList
								val allFiles=sourceDirectory.listFiles.filter(_.isFile)
										val onlyPartFiles=allFiles.filter(p => p.getName.startsWith("part")).toList
										//return onlyPartFiles
										for (file <- onlyPartFiles)
										{
											var i=0
													println("partFile: "+ file.getAbsolutePath())
													//val oldFile = new File(file)
													// val newFilePath2 = file.getParentFile.getAbsolutePath.replace(file.getName(), "") + newName
													println("newFilePath: "+ newFilePath)
													val   newFile = new File(newFilePath+newName)
													try {
														if(newFile.exists())
															newFile.delete()
															FileUtils.moveFile(file, newFile)
															println("Moved from file"+ file.getName +  " To file :"+ newFile.getName)
													}catch
													{case
														e:org.apache.commons.io.FileExistsException=>
														println("Usage: Exception File already exists in the destination :"+newFile.getAbsolutePath)
														e:Exception  =>
														println("Exception caught in Helpers.moveFile method")
														e.printStackTrace();
													}
										}
								//Function call to delete the temp directory
								deleteFolder3(sourceDirectory.getAbsolutePath)
							}
				}catch
				{case
					e:Exception  =>
					println("Exception caught in Helpers.moveFile method")
					e.printStackTrace();
				}
		}
	def mergeFiles3(allFiles : List[File] ,headerLines: Seq[String], outputFilePath:String,tempFolder:String ):Unit =
		{
				val bufferWrite = new BufferedWriter(new FileWriter(new File(outputFilePath)))
						//val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath),true))
						//Wrting header string
						headerLines.foreach(line => bufferWrite.write(line + "\n"))
						bufferWrite.close
						for(file <- allFiles)
						{
							//val allLines=Source.fromFile(file.getAbsoluteFile)("UTF-8").getLines().toList
							val bufferWrite = new PrintWriter(new FileOutputStream(new File(outputFilePath),true))
									// val source: BufferedSource = scala.io.Source.fromFile(file.getAbsoluteFile)
									val source = scala.io.Source.fromFile(file.getAbsoluteFile)("UTF-8")
									for (line <- source.getLines)
									{
										bufferWrite.write(line + "\n")
									}
							source.close()
							//  bufferWrite.write(allLines + "\n")
							bufferWrite.close
						}
				val bufferWrite2 = new PrintWriter(new FileOutputStream(new File(outputFilePath),true))
						bufferWrite2.write("</REQUEST>")
						bufferWrite2.close
						//Function call to delete the temp directory
						deleteFolder3(tempFolder)
		}
	def writeFileLocalAppend( outputFilePath: String): Unit =
		{
				// val outputFile = new BufferedWriter(new FileWriter(outputFilePath))
				val outFile = (new PrintWriter(new FileOutputStream(new File(outputFilePath),true)))
						// val outFile = new FileOutputStream(new File("Test.txt"),true)
						val endLine="</REQUEST>"
						outFile.write("<test1>")
						outFile.println("Test2")
						outFile.append(endLine)
						// outputFile.append(endLine)
						//  outputFile.close()
						outFile.close()
		}
	
	def printParams2(params :QCLInputParams2):Unit =
	{
	  //val length=params.
	  
      //val schema = ScalaReflection.schemaFor[QCLInputParams2].dataType.asInstanceOf[StructType]
      //schema.printTreeString
	    println ("DELTA_TABLE_NAME_BASE : "+params.DELTA_TABLE_NAME_BASE)
      println ("DELTA_TABLE_NAME_BASERAW : "+params.DELTA_TABLE_NAME_BASERAW)
      println ("DELTA_TABLE_NAME_CONTROL : "+params.DELTA_TABLE_NAME_CONTROL)
      println ("DELTA_TABLE_PATH_BASE : "+params.DELTA_TABLE_PATH_BASE)
      println ("DELTA_TABLE_PATH_REPORTING : "+params.DELTA_TABLE_PATH_REPORTING)
      println ("DELTA_TABLE_PATH_SNAPSHOT : "+params.DELTA_TABLE_PATH_SNAPSHOT)
      println ("DELTA_TABLE_PATH_WORKING : "+params.DELTA_TABLE_PATH_WORKING)
      println ("INPUT_FILE_HISTDATA_CHARACTERSET : "+params.INPUT_FILE_HISTDATA_CHARACTERSET)
      println ("INPUT_FILE_HISTDATA_DELIMETER : "+params.INPUT_FILE_HISTDATA_DELIMETER)
      println ("INPUT_FILE_HISTDATA_FORMAT : "+params.INPUT_FILE_HISTDATA_FORMAT)
      println ("INPUT_FILE_HISTDATA_HEADER : "+params.INPUT_FILE_HISTDATA_HEADER)
      println ("INPUT_FILE_HISTDATA_PARSINGMODE : "+params.INPUT_FILE_HISTDATA_PARSINGMODE)
      println ("INPUT_FILE_HISTDATA_PATH : "+params.INPUT_FILE_HISTDATA_PATH)
      println ("INPUT_FILE_MANUALDATA_CHARACTERSET : "+params.INPUT_FILE_MANUALDATA_CHARACTERSET)
      println ("INPUT_FILE_HISTDATA_DATEFORMAT : "+params.INPUT_FILE_HISTDATA_DATEFORMAT)
      println ("INPUT_FILE_MANUALDATA_DATEFORMAT : "+params.INPUT_FILE_MANUALDATA_DATEFORMAT)
      println ("INPUT_FILE_MANUALDATA_DELIMETER : "+params.INPUT_FILE_MANUALDATA_DELIMETER)
      println ("INPUT_FILE_MANUALDATA_FORMAT : "+params.INPUT_FILE_MANUALDATA_FORMAT)
      println ("INPUT_FILE_MANUALDATA_HEADER : "+params.INPUT_FILE_MANUALDATA_HEADER)
      println ("INPUT_FILE_MANUALDATA_PARSINGMODE : "+params.INPUT_FILE_MANUALDATA_PARSINGMODE)
      println ("INPUT_FILE_MANUALDATA_PATH : "+params.INPUT_FILE_MANUALDATA_PATH)
      println ("INPUT_FILE_XMLREQUEST_CHARACTERSET : "+params.INPUT_FILE_XMLREQUEST_CHARACTERSET)
      println ("INPUT_FILE_XMLREQUEST_PATH : "+params.INPUT_FILE_XMLREQUEST_PATH)
      println ("INPUT_FILE_XMLREQUEST_ROWTAG : "+params.INPUT_FILE_XMLREQUEST_ROWTAG)
      println ("INPUT_FILE_XMLRESPONSE_CHARACTERSET : "+params.INPUT_FILE_XMLRESPONSE_CHARACTERSET)
      println ("INPUT_FILE_XMLRESPONSE_PATH : "+params.INPUT_FILE_XMLRESPONSE_PATH)
      println ("INPUT_FILE_XMLRESPONSE_ROWTAG : "+params.INPUT_FILE_XMLRESPONSE_ROWTAG)
      println ("OUTPUT_FILE_REPORTS_DELIMETER : "+params.OUTPUT_FILE_REPORTS_DELIMETER)
      println ("OUTPUT_FILE_REPORTS_FORMAT : "+params.OUTPUT_FILE_REPORTS_FORMAT)
      println ("OUTPUT_FILE_REPORTS_PATH : "+params.OUTPUT_FILE_REPORTS_PATH)
      println ("OUTPUT_FILE_XMLREQUET_PATH : "+params.OUTPUT_FILE_XMLREQUET_PATH)
      println ("OUTPUT_FILE_XMLREQUET_ROOTTAG : "+params.OUTPUT_FILE_XMLREQUET_ROOTTAG)
      println ("OUTPUT_FILE_XMLREQUET_ROWTAG : "+params.OUTPUT_FILE_XMLREQUET_ROWTAG)
      println ("OUTPUT_FILE_XMLRESPONSE_PATH : "+params.OUTPUT_FILE_XMLRESPONSE_PATH)
      println ("OUTPUT_FILE_XMLRESPONSE_ROOTTAG : "+params.OUTPUT_FILE_XMLRESPONSE_ROOTTAG)
      println ("OUTPUT_FILE_XMLRESPONSE_ROWTAG : "+params.OUTPUT_FILE_XMLRESPONSE_ROWTAG)

	  
	}
	def printParams(params :QCLInputParams):Unit =
		{
				println("Usage : Start of Printing the Config file Parameters ........ ")
				println ("DELTA_TABLE_PATH_BASE : "+params.DELTA_TABLE_PATH_BASE)
				println ("DELTA_TABLE_PATH_TEMP : "+params.DELTA_TABLE_PATH_TEMP)
				println ("DELTA_TABLE_NAME_BASE : "+params.DELTA_TABLE_NAME_BASE)
				println ("DELTA_TABLE_NAME_BASERAW : "+params.DELTA_TABLE_NAME_BASERAW)
				println ("DELTA_TABLE_NAME_CONTROL : "+params.DELTA_TABLE_NAME_CONTROL)
				//println ("INPUT_SOURCE : "+params.INPUT_SOURCE)
				println ("INPUT_FILE_HISTDATA_LOCATION : "+params.INPUT_FILE_HISTDATA_LOCATION)
				//println ("INPUT_FILE_HISTDATA_PATH : "+params.INPUT_FILE_HISTDATA_PATH)
				//println ("INPUT_FILE_HISTDATA_NAME : "+params.INPUT_FILE_HISTDATA_NAME)
				println ("INPUT_FILE_HISTDATA_DELIMETER : "+params.INPUT_FILE_HISTDATA_DELIMETER)
				println ("INPUT_FILE_HISTDATA_FORMAT : "+params.INPUT_FILE_HISTDATA_FORMAT)
				// println ("INPUT_FILE_HISTDATA_HEADER : "+params.INPUT_FILE_HISTDATA_HEADER)
				// println ("INPUT_FILE_HISTDATA_CHARACTERSET : "+params.INPUT_FILE_HISTDATA_CHARACTERSET)
				// println ("INPUT_FILE_HISTDATA_PARSINGMODE : "+params.INPUT_FILE_HISTDATA_PARSINGMODE)
				// println ("INPUT_FILE_XMLREQUEST_LOCATION : "+params.INPUT_FILE_XMLREQUEST_LOCATION)
				println ("INPUT_FILE_XMLREQUEST_PATH : "+params.INPUT_FILE_XMLREQUEST_PATH)
				//  println ("INPUT_FILE_XMLREQUEST_NAME : "+params.INPUT_FILE_XMLREQUEST_NAME)
				// println ("INPUT_FILE_XMLREQUEST_CHARACTERSET : "+params.INPUT_FILE_XMLREQUEST_CHARACTERSET)
				// println ("INPUT_FILE_XMLREQUEST_ROWTAG : "+params.INPUT_FILE_XMLREQUEST_ROWTAG)
				//  println ("OUTPUT_SOURCE : "+params.OUTPUT_SOURCE)
				//println ("OUTPUT_FILE_DQ_LOCATION : "+params.OUTPUT_FILE_DQ_LOCATION)
				println ("OUTPUT_FILE_DQ_PATH : "+params.OUTPUT_FILE_DQ_PATH)
				//println ("OUTPUT_FILE_DQ_NAME : "+params.OUTPUT_FILE_DQ_NAME)
				//println ("OUTPUT_FILE_DQ_FORMAT : "+params.OUTPUT_FILE_DQ_FORMAT)
				//println ("OUTPUT_FILE_DQ_DELIMETER : "+params.OUTPUT_FILE_DQ_DELIMETER)
				println ("OUTPUT_FILE_ERR_LOCATION : "+params.OUTPUT_FILE_ERR_LOCATION)
				// println ("OUTPUT_FILE_ERR_PATH : "+params.OUTPUT_FILE_ERR_PATH)
				// println ("OUTPUT_FILE_ERR_NAME : "+params.OUTPUT_FILE_ERR_NAME)
				// println ("OUTPUT_FILE_ERR_FORMAT : "+params.OUTPUT_FILE_ERR_FORMAT)
				// println ("OUTPUT_FILE_ERR_DELIMETER : "+params.OUTPUT_FILE_ERR_DELIMETER)
				// println ("OUTPUT_FILE_XMLREQUET_LOCATION : "+params.OUTPUT_FILE_XMLREQUET_LOCATION)
				println ("OUTPUT_FILE_XMLREQUET_PATH : "+params.OUTPUT_FILE_XMLREQUET_PATH)
				// println ("OUTPUT_FILE_XMLREQUET_NAME : "+params.OUTPUT_FILE_XMLREQUET_NAME)
				// println ("OUTPUT_FILE_XMLREQUET_ROOTTAG : "+params.OUTPUT_FILE_XMLREQUET_ROOTTAG)
				// println ("OUTPUT_FILE_XMLREQUET_ROWTAG : "+params.OUTPUT_FILE_XMLREQUET_ROWTAG)
				// println ("INPUT_FILE_XMLRESPONSE_LOCATION : "+params.INPUT_FILE_XMLRESPONSE_LOCATION)
				println ("INPUT_FILE_XMLRESPONSE_PATH : "+params.INPUT_FILE_XMLRESPONSE_PATH)
				// println ("INPUT_FILE_XMLRESPONSE_NAME : "+params.INPUT_FILE_XMLRESPONSE_NAME)
				// println ("INPUT_FILE_XMLRESPONSE_CHARACTERSET : "+params.INPUT_FILE_XMLRESPONSE_CHARACTERSET)
				// println ("INPUT_FILE_XMLRESPONSE_ROWTAG : "+params.INPUT_FILE_XMLRESPONSE_ROWTAG)
				println("Usage : End of Printing the Config file Parameters ........ ")
		}
	def getTimeDifference(startTime: java.sql.Timestamp, endTime: java.sql.Timestamp): String =
		{
				val exeTime2 = (endTime.getTime - startTime.getTime)
						val rtMins = exeTime2 / (60 * 1000)
						val rtHrs = exeTime2 / (60 * 60 * 1000)
						val rtDays = exeTime2 / (24 * 60 * 60 * 1000)
						val rtSecs = (exeTime2 / 1000)
						val rtSecsStr = rtSecs - (rtMins * 60)
						val rtMinsStr = rtMins - (rtHrs * 60)
						val rtHrsStr = rtHrs - (rtDays * 24)
						if (rtDays >= 1)
							s"$rtDays:Days $rtHrsStr:Hours $rtMinsStr:Minutes $rtSecsStr:Seconds"
							else if (rtDays < 1 && rtHrs >= 1)
								s"$rtHrsStr:Hours $rtMinsStr:Minutes $rtSecsStr:Seconds"
								else if (rtDays < 1 && rtHrs < 1 && rtMins >= 1)
									s"$rtMinsStr:Minutes $rtSecsStr:Seconds"
									else if (rtDays < 1 && rtHrs < 1 && rtMins < 1 && rtSecs >= 1)
										s"$rtSecsStr:Seconds"
										else
											s"$rtDays:Days $rtHrsStr:Hours $rtMinsStr:Minutes $rtSecsStr:Seconds"
		}
	// Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
	def getRegularRequestXMLMapClass_V2_0(df: DataFrame): Dataset[RegularRequestXMLMapClass] =
		{
				val TagggedDF=df.select(
						col("AREF"),
						col("AOPN"),
						col("APRD"),
						col("ALMT"),
						col("ASAL"),
						col("AEXP"),
						col("APST"),
						col("AINST"),
						col("AFRQ"),
						col("ATNR"),
						col("ASEC"),
						col("ACYC.ACYCID"),
						col("ACYC.ALSPD"),
						col("ACYC.ALSTAM"),
						col("ACYC.AACS"),
						col("ACYC.ACUB"),
						col("ACYC.AODB"),
						col("ACYC.AASOF"),
						col("ACYC.ANXPD"),
						col("CONSUMER.CID.CID1"),
						col("CONSUMER.CID.CID2")
						)
						.withColumn("ALMT", col("ALMT").cast(DoubleType))
						.withColumn("AINST", col("AINST").cast(DoubleType))
						.withColumn("ALSTAM", col("ALSTAM").cast(DoubleType))
						.withColumn("ACUB", col("ACUB").cast(DoubleType))
						.withColumn("AODB", col("AODB").cast(DoubleType))
						.withColumn("ATNR", col("ATNR").cast(IntegerType))
						.withColumn("ACYCID", col("ACYCID").cast(IntegerType))
						.withColumnRenamed( "AREF","AccountNumber")
						.withColumnRenamed("APRD","ProductType")
						.withColumnRenamed("ASAL","SalaryAssignmentFlag")
						.withColumnRenamed("AFRQ","PaymentFrequency")
						.withColumnRenamed("ASEC","SecurityType")
						.withColumn("IssueDate", to_date(expr("concat(AOPN.AOPND, AOPN.AOPNM,AOPN.AOPNY)"), "ddMMyyyy"))
						.withColumn("ExpiryDate", to_date(expr("concat(AEXP.AEXPD, AEXP.AEXPM,AEXP.AEXPY)"), "ddMMyyyy"))
						.withColumn("AsOfDate", to_date(expr("concat(AASOF.AASOFD, AASOF.AASOFM,AASOF.AASOFY)"), "ddMMyyyy"))
						.withColumnRenamed("APST","ProductStatus")
						.withColumnRenamed("AACS","PaymentStatus")
						.withColumnRenamed("ATNR","Tenure")
						.withColumnRenamed("AINST","InstallmentAmount")
						.withColumnRenamed("ALMT","OriginalAmount")
						.withColumnRenamed("ACUB","OutStandingBalance") //OutstandingAmount
						.withColumnRenamed("ACYCID","LastCycleID")
						.withColumnRenamed("ALSTAM","LastAmountPaid")
						.withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
						.withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
						.withColumnRenamed("AODB","PastDueBalance")
						.withColumnRenamed("CID1","IDType")
						.withColumnRenamed("CID2","IDNumber")
						//: TO DO Change the AsOfDate to today date OR load date OR CIUploadDate
						.drop(col("AOPN"))
						.drop(col("AEXP"))
						.drop(col("ALSPD"))
						.drop(col("AASOF"))
						.drop(col("ANXPD"))
						import spark.implicits._
						val caseClassDS=  TagggedDF.as[RegularRequestXMLMapClass]
								caseClassDS
		}
	// Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
	def getRequestXMLCaseClassDS_V1_2(df: DataFrame): Dataset[InputXMLMapCaseClass] =
		{
				val TagggedDF=df.select(
						col("AREF"),
						col("AOPN"),
						col("APRD"),
						col("ALMT"),
						col("ASAL"),
						col("AEXP"),
						col("APST"),
						col("AINST"),
						col("AFRQ"),
						col("ATNR"),
						col("ASEC"),
						col("ACON"),
						col("ACYC.ACYCID"),
						col("ACYC.ALSPD"),
						col("ACYC.ALSTAM"),
						col("ACYC.AACS"),
						col("ACYC.ACUB"),
						col("ACYC.AODB"),
						col("ACYC.AASOF"),
						col("ACYC.ANXPD"),
						col("CONSUMER.CAPL"),
						col("CONSUMER.CID.CID1"),
						col("CONSUMER.CID.CID2"))
						.withColumn("ALMT", col("ALMT").cast(DoubleType))
						.withColumn("AINST", col("AINST").cast(DoubleType))
						.withColumn("ALSTAM", col("ALSTAM").cast(DoubleType))
						.withColumn("ACUB", col("ACUB").cast(DoubleType))
						.withColumn("AODB", col("AODB").cast(DoubleType))
						.withColumn("ATNR", col("ATNR").cast(IntegerType))
						.withColumn("ACON", col("ACON").cast(IntegerType))
						.withColumn("ACYCID", col("ACYCID").cast(IntegerType))
						.withColumnRenamed( "AREF","AccountNumber")
						.withColumn("IssueDate", to_date(expr("concat(AOPN.AOPND, AOPN.AOPNM,AOPN.AOPNY)"), "ddMMyyyy"))
						.withColumnRenamed("APRD","ProductType")
						.withColumnRenamed("ALMT","OriginalAmount")
						.withColumnRenamed("ASAL","SalaryAssignmentFlag")
						.withColumn("ExpiryDate", to_date(expr("concat(AEXP.AEXPD, AEXP.AEXPM,AEXP.AEXPY)"), "ddMMyyyy"))
						.withColumnRenamed("APST","ProductStatus")
						.withColumnRenamed("AINST","InstallmentAmount")
						.withColumnRenamed("AFRQ","PaymentFrequency")
						.withColumnRenamed("ATNR","Tenure")
						.withColumnRenamed("ASEC","SecurityType")
						.withColumnRenamed("ACON","NumberOfApplicants")
						.withColumnRenamed("ACYCID","LastCycleID")
						.withColumn("LastPaymentDate", to_date(expr("concat(ALSPD.ALSPDD, ALSPD.ALSPDM,ALSPD.ALSPDY)"), "ddMMyyyy"))
						.withColumnRenamed("ALSTAM","LastAmountPaid")
						.withColumnRenamed("AACS","PaymentStatus")
						.withColumnRenamed("ACUB","OutstandingAmount")
						.withColumnRenamed("AODB","PastDueBalance")
						.withColumn("AsOfDate", to_date(expr("concat(AASOF.AASOFD, AASOF.AASOFM,AASOF.AASOFY)"), "ddMMyyyy"))
						.withColumn("NextPaymentDate", to_date(expr("concat(ANXPD.ANXPDD, ANXPD.ANXPDM,ANXPD.ANXPDY)"), "ddMMyyyy"))
						.withColumnRenamed("CAPL","ApplicationType")
						.withColumnRenamed("CID1","IDType")
						.withColumnRenamed("CID2","IDNumber")
						//: TO DO Change the AsOfDate to today date OR load date OR CIUploadDate
						.withColumn("DaysDiff",  datediff(col("IssueDate"),col("AsOfDate")) === 0) 
						.withColumn("NEW_ACCT_FLAG", when (col("DaysDiff").isNull ,false).otherwise(col("DaysDiff")))
						.drop(col("AOPN"))
						.drop(col("AEXP"))
						.drop(col("ALSPD"))
						.drop(col("AASOF"))
						.drop(col("ANXPD"))
						import spark.implicits._
						val caseClassDS=  TagggedDF.as[InputXMLMapCaseClass]
								caseClassDS
		}
	// Mapping of input XML TAGS to Spec Column names and type casting the columns and converting as CaseClass Dataset
	//20220602 : to do : Few columns are optional in input XML based on the data availability ,hence add flexible select and retrun default values for missing columns based on caseclass datatype
	def has_Column(df: DataFrame, columnName: String) = Try(df(columnName)).isSuccess

			def checkColum(df: DataFrame, ColumnName: String , DataType: String) =
			if (Try(df(ColumnName)).isSuccess == true) {
				df(ColumnName)
			}
			else 
			{
				DataType match
				{
				case  "string" => lit("")
				case "struct" => lit(null).cast("struct<AEXPD:string,AEXPM:string,AEXPY:string>")
				// lit(null).cast(StructType(Nil))
				// lit(StructType(Nil))
				// lit(null)
				// lit(new GenericRowWithSchema(Array(), StructType(Nil)))
				case _ => lit(null)
				}
				// lit(null)
			}
	def getFileName(filePath: String): String = {
			filePath.substring(filePath.lastIndexOf("/")+1)
	}
	def getRequestFileDetails(requestFileName: String, runDate: java.sql.Date): DataFrame = {
			try
			{
				val requestFile = new File(requestFileName)
						if (requestFile.exists && requestFile.isFile())
						{
							println("isFile: "+ requestFile.isFile())
							println("Path: "+ requestFile.getAbsolutePath)
							//println("Name: "+ requestFile.getName)
							//  .withColumn("FILE_TYP", col("FILENAME").substr(4, 3))
							//   .withColumn("RunNumber", col("FILENAME").substr(7, 7))
							//   .withColumn("Product", col("FILENAME").substr(14, 3))
							val RUNDATE=runDate
							val RUNTIMESTAMP=new java.sql.Timestamp(System.currentTimeMillis())
							//val RUNNUMBER=(requestFile.getName).toString().slice(7, 7).toString()
							//val RUNNUMBER=FILENAME.slice(7, 7)
							// val FILENAME=requestFile.getName.substring(0,requestFile.getName.lastIndexOf("."))
							//val FILENAME=getMyName(requestFile)//.getName.substring(0,requestFile.getName.lastIndexOf("."))
							val FILENAME=requestFile.getName.toList
							println("FILENAMELength:"+ FILENAME.size)
							/*val FILETYPE=FILENAME.slice(0, 3).mkString
         val RUNNUMBER=FILENAME.slice(3, 10).mkString // requestFile.getName.substring(0,requestFile.getName.lastIndexOf(".")).substring(7, 7)
        val FILEPRODUCT= FILENAME.slice(10, 13).mkString //requestFile.getName.substring(0,requestFile.getName.lastIndexOf(".")).slice(14, 3)
        val KEY=s"$FILETYPE$RUNNUMBER$FILEPRODUCT".toString()
							 */
							val FILETYPE=FILENAME.slice(3, 6).mkString
							val RUNNUMBER=FILENAME.slice(6, 13).mkString.toInt // requestFile.getName.substring(0,requestFile.getName.lastIndexOf(".")).substring(7, 7)
							val FILEPRODUCT= FILENAME.slice(13, 16).mkString //requestFile.getName.substring(0,requestFile.getName.lastIndexOf(".")).slice(14, 3)
							val KEY1=s"$FILETYPE$RUNNUMBER$FILEPRODUCT".toString()
							val KEY2=s"$FILETYPE$FILEPRODUCT".toString()
							//println("FILENAME: "+ FILENAME)
							//println("RUNNUMBER: "+ RUNNUMBER)
							//println("FILETYPE: "+ FILETYPE)
							//println("FILEPRODUCT: "+ FILEPRODUCT)
							//println("KEY: "+ KEY)
							//val a=requestFile.lastModified()
							val fileDate=new java.sql.Date(requestFile.lastModified())
							println("fileDate: "+ fileDate)
							val FILENAME2=FILENAME.mkString
							// val DS=new RequestFileDetails(KEY,FILENAME,RUNDATE,RUNTIMESTAMP,RUNNUMBER,FILETYPE,FILEPRODUCT,0,0,0,0,0,0,"","")
							//  val DS=List( RequestFileDetails(KEY,FILENAE,RUNDATE,RUNTIMESTAMP,RUNNUMBER,FILETYPE,FILEPRODUCT,0,0,0,0,0,0,"",""))
							import spark.implicits._
							val DS=Seq( RequestFileStats(KEY1,KEY2,requestFile.getName,RUNDATE,RUNTIMESTAMP,RUNNUMBER,FILETYPE,FILEPRODUCT, 0,0,0,0,0,0,"",""))
							val df=DS.toDF
							df.printSchema()
							df.show()
							df
							//println("Name: "+ requestFile.ge)
						}
						else null
						//requestFile.
			} catch {
			case e: Exception =>
			println("Error : Exception caught in Helpers.getRequestFileDetails method")
			e.printStackTrace()
			//List[File]()
			null
			}
	}
	val udfGetFileName = udf[String, String](getFileName)
			// val udfCheckColum=udf[Column,DataFrame, String ,String](checkColum)
}