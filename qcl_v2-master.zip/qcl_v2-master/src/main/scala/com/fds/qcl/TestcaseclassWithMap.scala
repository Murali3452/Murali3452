package com.fds.qcl

object TestcaseclassWithMap {
  
   case class Student(id:String, name:String, teacher:String )
   
   // define case class
case class Criteria (
	`authCompanyId`: Option[String] = None,
	`internalInterchangeId`: Option[String] = None,
	`documentIdentifier`: Option[String] = None,
	`distribution`: Option[String] = None,
	`direction`: Option[String] = None,
	`sendType`: Option[String] = None,
	`documentType`: Option[String] = None,
	`dateFrom`: Option[String] = None,
	`dateTo`: Option[String] = None
)
   
    def main(args: Array[String]) {
   
     val myList = List( Student("1","Ramesh","Isabela"), Student("2","Elena","Mark"),Student("3","invalidKey","Someteacher"))
      
      //val a = myList.foreach( i=> (i.name ->  i.teacher)).toMap.filter(i.name != "invalidKey")
     
     val myMap = myList.collect {
  case student if student.name != "invalidKey" => student.name -> student.teacher
}.toMap
   }
   
   
   // 1. create instance
val c = Criteria(`authCompanyId` = Option("32232"), 
                 `distribution` = Option("MAIL"), 
                 `sendType` = Option("PROD"), 
                 `dateFrom` = Option("2017-11-15"))
                 
            val paramList=     c.getClass.getDeclaredFields.map(_.getName)
            println("##paramList")           
            paramList.foreach(println)
            
            val valusList=c.productIterator.to

            println("##valusList")
            valusList.foreach(println)
            
            val zipPandV=c.getClass.getDeclaredFields.map(_.getName).zip(c.productIterator.to)
            
            val map=c.getClass.getDeclaredFields.map(_.getName).zip(c.productIterator.to).toMap
            
            val myMap=for ((k, Some(v)) <- c.getClass.getDeclaredFields.map(_.getName).zip(c.productIterator.to).toMap) yield k -> v.asInstanceOf[String]
            
             println("##Map")
            myMap.foreach(println)
            
            
  
}