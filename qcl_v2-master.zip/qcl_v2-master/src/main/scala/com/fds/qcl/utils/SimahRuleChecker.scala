package com.fds.qcl.utils

import SimahCaseClasses._

import java.text.DecimalFormat
import java.sql.Timestamp
import java.sql.Date
import org.apache.spark.sql.functions._
import org.apache.spark._
import org.apache.spark.SparkContext._
import scala.util.Try
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import java.util.regex.Pattern
import scala.util.matching.Regex
import scala.io.Source
import scala.collection.mutable.LinkedHashSet
import scala.collection.mutable.ArrayBuffer
import java.time.Period
import org.apache.spark.sql.expressions.UserDefinedFunction

object SimahRuleChecker {
  //val conf = new SparkConf().setAppName("SimahRuleChecker").setMaster("local[*]").set("spark.testing.memory", "2147480000").set("spark.kryoserializer.buffer.max", "512") //local
  //          val spark = SparkSession.builder.appName("SimahRuleChecker_App").config(conf).getOrCreate() //local
  val PFProductGroup = List("ADFL", "CDL", "DPLN", "DSTFM", "EDUF", "MGLD", "PLN", "RPLN", "RSFM", "SFB", "SME", "STFM", "TPLN") //ProductGroupPersonalLoan PLN PRDGRPPLN
  val CCProductGroup = List("CDC", "CHC", "CRC", "LCRC", "POD", "TOD") //Product Group PCR Credit Cards CRC                PRDGRPPCR
  val ALProductGroup = List("RSMEI", "RSMEL", "RVIN", "RVLS", "SMEI", "SMEL", "VEHE", "VESP", "VIN", "VLS", "VRA") //Product Group Vehicle               VLB        PRDGRPVEH
  val MTGProductGroup = List("AMTG", "AQAR", "EMTG", "IMTG", "INPR", "MMTG", "MSKN", "MTG", "OMTG", "RERA", "RMSKN", "RMTG", "SMTG", "TMTG") //ProductGroupMortgage           MTG      PRDGRPMTG
  val PHProductGroup = List("ELCB", "LND", "MBL", "NET", "RCSR", "WAT") //Product Group PH                              PRDGRPPH
  val RNPProductGroup = List("MBL", "PLN", "WAT") // Product Group Risk of Non-payment    PRDGRPSU

  def getHistoryDQReport(
    AccountNumber:            String,
    ProductType:              String,
    SalaryAssignment:         String,
    SecurityType:             String,
    PaymentFrequency:         String,
    IssueDate:                java.sql.Date,
    ExpiryDate:               java.sql.Date,
    AsOfDate:                 java.sql.Date,
    CloseDate:                java.sql.Date,
    ProductStatus:            String,
    PaymentStatus:            String,
    Tenure:                   Option[Integer],
    InstallmentAmount:        Option[Double],
    OriginalAmount:           Option[Double],
    OutStandingBalance:       Option[Double],
    LastCycleID:              Option[Integer],
    LastAmountPaid:           Option[Double],
    LastPaymentDate:          java.sql.Date,
    NextPaymentDate:          java.sql.Date,
    PastDueBalance:           Option[Double],
    DefaultStatus:            String,
    DefaultLoadDate:          java.sql.Date,
    DefaultOriginalAmount:    Option[Double],
    DefaultOutStandingAmount: Option[Double],
    DefaultStatusDate:        java.sql.Date,
    DefaultChangeDate:        java.sql.Date,
    CIUploadDate:             java.sql.Date,
    CIUpdateDate:             java.sql.Date,
    CurrentStatus:            String,
    ReportedDate:             java.sql.Date,
    DPR:                      Option[Integer],
    DPA:                      Option[Integer],
    RJC:                      Option[Integer]): HistoryDQReport_V_01 =
    {
      var validFlag = "VALID"
      var ErrorIds = ""
      var ErroeMsgs = ""
      //# # This list is used to validate the rules for OriginalAmount and OutStandingAmount
      val ProductTypeList = List("PLN", "RPLN", "MTG")
      // val IssueDate=new java.sql.Date(CIUploadDate.getTime)
      // val ExpiryDate=new java.sql.Date(CIUploadDate.getTime)
      // val LastPaymentDate=new java.sql.Date(CIUploadDate.getTime)
      // val NextPaymentDate=new java.sql.Date(CIUploadDate.getTime)
      // val AsOfDate=new java.sql.Date(CIUploadDate.getTime)
      //== val ClosedDate=if(ProductStatus.equalsIgnoreCase("C") && H_ProductStatus != null && !H_ProductStatus.equalsIgnoreCase("C") ) AsOfDate else null
      //*** Start of  IssueDate Rules ****
      //Pending:
      //1: Error: IssueDate > AsOfDate
      //2: Error: IssueDate > CycleID;
      //IssueDate is mandatory and must be provided for all products
      if (IssueDate != null) {
        val daysDiff = (CIUploadDate.getTime() - IssueDate.getTime()) / (60 * 60 * 1000 * 24)
        //  println("Dates:"+IssueDate+" : "+CIUploadDate+" : diffDays :"+ daysDiff)
        /* @@ review
       //Account should be loaded to Simah within a week from opening :Error: CI was not loaded within a week from opening
       if( daysDiff > 7)
       {
         //println("AccountNumber:"+AccountNumber +" Dates:"+IssueDate+" : "+CIUploadDate+" : diffDays :"+ daysDiff)
         validFlag="ERROR"
         ErrorIds= ErrorIds+"ERR_ISDT_02 |"
         ErroeMsgs=ErroeMsgs+"Error: CI was not loaded within a week from opening |"
       }
                                                       */
        //IssueDate must not be greater than CIUploadDate :Error: IssueDate > CI Upload Date
        if (IssueDate.compareTo(CIUploadDate) > 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_ISDT_04 |"
          ErroeMsgs = ErroeMsgs + "Error: IssueDate must not be greater than CIUploadDate |"
        }
      }
      //*** End of IssueDate Rules ******
      //*** Start of  CloseDate Rules ****
      //ClosedDate is the closure date for the credit instrument. This field is system generated by Simah and it is extracted from the last AsOfDate provided by the member when closing the account
      if ((ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W")) && AsOfDate == null) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_CLDT_01 |"
        ErroeMsgs = ErroeMsgs + "Error:  CloseDate is missing. It should be provided when product status is C or W |"
      }
      if (ProductStatus.equalsIgnoreCase("C") && CloseDate != null) {
        val daysDiff = (CIUpdateDate.getTime() - CloseDate.getTime()) / (60 * 60 * 1000 * 24)
        /* @@ review
       //CI should be closed within a week from closure date
       if( daysDiff > 7)
       {
          // println("AccountNumber:"+AccountNumber + " CIUploadDate:" + CIUploadDate + "ClosedDate: "+ ClosedDate + "  DaysDiff:"+daysDiff)
           validFlag="ERROR"
           ErrorIds=ErrorIds+"ERR_CLDT_02 |"
           ErroeMsgs=ErroeMsgs+"Error:  CI should be closed within a week from closure date |"
       }
                                           */
        //ClosedDate cannot be greater than CIUpdateDate
        if (daysDiff < 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_CLDT_03 |"
          ErroeMsgs = ErroeMsgs + "Error:  CloseDate cannot be greater than CIUpdateDate |"
        }
      }
      //*** End of ClosedDate Data Rules ****
      //*** Start of  NextPaymentDate Rules ****
      //NextPaymentDate should be null when ProductStatus is “C” or “W”
      if (NextPaymentDate != null && ProductStatus.equalsIgnoreCase("W")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_NPDT_03 |"
        ErroeMsgs = ErroeMsgs + "NextPaymentDate should be null when ProductStatus is W |"
      } else if (NextPaymentDate != null && ProductStatus.equalsIgnoreCase("C")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_NPDT_03 |"
        ErroeMsgs = ErroeMsgs + "NextPaymentDate should be null when ProductStatus is C |"
      }
      //*** End of NextPaymentDate Data Rules ****
      //*** Start of  LastPaymentDate Rules ****
      if (LastPaymentDate != null && IssueDate != null) {
        //LastPaymentDate must not be less than IssueDate
        if (LastPaymentDate.compareTo(IssueDate) < 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_LPDT_01 |"
          ErroeMsgs = ErroeMsgs + "Error: LastPaymentDate must not be less than IssueDate |"
        }
      }
      //*** End of LastPaymentDate Data Rules ****
      //*** Start of  InstallmentAmount Rules ****
      if (ProductType != null && !ProductType.trim().isEmpty()) {
        if (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)) {
          if (InstallmentAmount != None && OriginalAmount != None && InstallmentAmount.get > OriginalAmount.get) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "WAR_EMIA_01 |"
            ErroeMsgs = ErroeMsgs + "Warning:  InstallmentAmount may not be correct because: InstallmentAmount > OriginalAmount |"
          }
          //InstallmentAmount must be provided for products falling into Personal Finance,Vehicle and Mortgage Product Group
          if (InstallmentAmount == None) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EMIA_01 |"
            ErroeMsgs = ErroeMsgs + "Error: InstallmentAmount is mandatory for this Product type |"
          } //InstallmentAmount should not be equal to zero
          else if (InstallmentAmount == None) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EMIA_03 |"
            ErroeMsgs = ErroeMsgs + "Error: InstallmentAmount cannot be Zero |"
          } //InstallmentAmount should not be less than zero
          else if (InstallmentAmount.get < 0) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EMIA_02 |"
            ErroeMsgs = ErroeMsgs + "Error: InstallmentAmount cannot be less than Zero |"
          }
        }
      }
      //*** End of  InstallmentAmount Rules ****
      //*** Start of  Tenure Rules ****
      if (ProductType != null && !ProductType.trim().isEmpty()) {
        if (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)) {
          //The time period Tenure and PaymentFrequency indicate should be close to the difference between IssueDate and ExpiryDate. Note: 25% margin is allowed in case a member allows for a grace period for his customers
          //[[PaymentFrequency is not available]] if(Tenure != None && PaymentFrequency != null && IssueDate != null && ExpiryDate != null)
          if (Tenure != None && IssueDate != null && ExpiryDate != null) {
            //val TenureInMonths=Tenure
            val TenureInMonths =
              {
                if (PaymentFrequency.equalsIgnoreCase("Y"))
                  (Tenure.get * 12).toInt
                else if (PaymentFrequency.equalsIgnoreCase("Q"))
                  (Tenure.get * 3).toInt
                else if (PaymentFrequency.equalsIgnoreCase("H"))
                  (Tenure.get * 6).toInt
                else if (PaymentFrequency.equalsIgnoreCase("M"))
                  (Tenure.get).toInt
                else
                  (Tenure.get).toInt
              }
            // var highEnd= TenureInMonths + (TenureInMonths* 0.2).toInt
            //var lowEnd= TenureInMonths - (TenureInMonths* 0.2).toInt
            var exeTime2 = (ExpiryDate.getTime - IssueDate.getTime)
            var diffDays = exeTime2 / (24 * 60 * 60 * 1000)
            var diffMonths = (diffDays / 30.0).round.toInt
            var highEnd = diffMonths + (diffMonths * 0.2).toInt
            var lowEnd = diffMonths - (diffMonths * 0.2).toInt
            //   println("IssueDate :"+IssueDate +" ExpiryDate:"+ExpiryDate+" diffDays:"+diffDays +" diffMonths: " +diffMonths +" Tenure: " +Tenure +" highEnd: " +highEnd+" lowEnd: " +lowEnd)
            //if(TenureInMonths != diffMonths  && TenureInMonths != diffMonths-1 && TenureInMonths != diffMonths-2 && TenureInMonths != diffMonths+1 && TenureInMonths != diffMonths+2  )
            //  if( diffMonths > lowEnd && diffMonths < highEnd )
            //#  if( Tenure.get > lowEnd && Tenure.get < highEnd )
            if (Tenure.get < lowEnd || Tenure.get > highEnd) {
              // DEBUG println("True:###: Account:"+AccountNumber +" IssueDate :" + IssueDate +" ExpiryDate:"+ExpiryDate+" diffDays:"+diffDays +" diffMonths: " +diffMonths +" Tenure: " +Tenure.get +" highEnd: " +highEnd+" lowEnd: " +lowEnd)
              validFlag = "WARNING"
              ErrorIds = ErrorIds + "WAR_TNR_01 |"
              ErroeMsgs = ErroeMsgs + "Warning: Tenure may not be correct because it doesn't match the difference between Issue and Expiry Dates |"
            }
            /* [[PaymentFrequency is not available]]
           if( (PaymentFrequency.equalsIgnoreCase("M")  && Tenure.get >480 )
               || (PaymentFrequency.equalsIgnoreCase("Q")  && Tenure.get >160 )
               || (PaymentFrequency.equalsIgnoreCase("H")  && Tenure.get >80 )
               || (PaymentFrequency.equalsIgnoreCase("Y")  && Tenure.get >40 ))
           {
             validFlag="WARNING"
             ErrorIds= ErrorIds+"WAR_TNR_02 |"
             ErroeMsgs=ErroeMsgs+"Warning:Tenure value is probably not correct. It is too high |"
           }
                                           *
                                           */
          }
          //Tenure is mandatory and must be provided for Personal Finance,Vehicle and Mortgage Product Group
          if (Tenure == None) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_TNR_01 |"
            ErroeMsgs = ErroeMsgs + "Error: Tenure is mandatory for this Product type |"
          } //Tenure must not be equal to zero
          else if (Tenure.get == 0) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_TNR_03 |"
            ErroeMsgs = ErroeMsgs + "Error: Tenure cannot be Zero |"
          } //Tenure must not be less than zero
          else if (Tenure.get < 0) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_TNR_02 |"
            ErroeMsgs = ErroeMsgs + "Error: Tenure cannot be less than Zero |"
          }
        }
      }
      //*** End of  Tenure Rules ****
      //*** Start of  OriginalAmount  Rules ****
      //OriginalAmount is mandatory and must be provided for all products
      if (OriginalAmount == None) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_ORGA_01 |"
        ErroeMsgs = ErroeMsgs + "Error: OriginalAmount is mandatory and must be provided |"
      } //OriginalAmount should not be  zero
      else if (OriginalAmount.get == 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_ORGA_03 |"
        ErroeMsgs = ErroeMsgs + "Error: OriginalAmount cannot be Zero |"
      } //OriginalAmount should not be less than zero
      else if (OriginalAmount.get < 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_ORGA_02 |"
        ErroeMsgs = ErroeMsgs + "Error: OriginalAmount cannot be less than Zero |"
      }
      //OriginalAmount should not be greater than (InstallmentAmount * Tenure) This rule applies for most products falling in the Personal Finance, Mortgage and Vehicle Product groups  However, VLS and VIN products are excluded temporary due to the confusion that is
      //happening because of the balloon payment. After Simah introduce the balloon payment on its report,VLS and VINs are going to be validated
      if (ProductType != null && !ProductType.trim().isEmpty() && (!ProductType.equalsIgnoreCase("VLS") || !ProductType.equalsIgnoreCase("VIN"))) {
        if (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)) {
          // # #iN DQ Report TMTG product type is excluded from this validation
          // # #iN DQ Report this Rule is applied for only PLN , RPLN and MTG Products
          if (ProductTypeList.contains(ProductType) && InstallmentAmount.get != 0 && Tenure != None && OriginalAmount.get != 0) {
            if (OriginalAmount.get > (InstallmentAmount.get * Tenure.get)) {
              validFlag = "ERROR"
              ErrorIds = ErrorIds + "ERR_ORGA_04 |"
              ErroeMsgs = ErroeMsgs + "Error: OriginalAmount > (InstallmentAmount * Tenure) |"
            } else if (OriginalAmount.get == (InstallmentAmount.get * Tenure.get)) {
              validFlag = "ERROR"
              ErrorIds = ErrorIds + "ERR_ORGA_05 |"
              ErroeMsgs = ErroeMsgs + "Error: OriginalAmount = (InstallmentAmount * Tenure) This indicates Profit is included in OriginalAmount |"
            }
          }
        }
      }
      //*** End of  OriginalAmount  Rules ****
      //*** Start of  OutstandingBalance  Rules ****
      //OutstandingAmount must not be greater than zero when ProductStatus is “C”
      if (OutStandingBalance.get > 0 && ProductStatus.equalsIgnoreCase("C")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_OSBL_01 |"
        ErroeMsgs = ErroeMsgs + "Error: OutStandingBalance shoud not be grater than zero for closed products |"
      }
      if (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)) {
        // # #Need to Verify  OutStanding shoud not be greater than (InstallmentAmount * Tenure) where payment status =0
        // # #iN DQ Report TMTG product type is excluded from this validation
        // # #iN DQ Report this Rule is applied for only PLN , RPLN and MTG Products
        if (ProductTypeList.contains(ProductType) && OutStandingBalance != None && InstallmentAmount != None && Tenure != None && PaymentStatus != null && PaymentStatus.equalsIgnoreCase("0")) {
          //val escapeMargin=InstallmentAmount.get * 3 // 3 installments
          //Margin 3 installments
          val value = (InstallmentAmount.get + 3) * Tenure.get
          if (OutStandingBalance.get > value) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_OSBL_07 |"
            ErroeMsgs = ErroeMsgs + "Error:  OutStanding is way greater than (InstallmentAmount * Tenure)|"
          }
        }
        //OutStanding must not be zero when ProductStatus is” A”, “S” or W and  products falling into Personal Finance,Vehicle and Mortgage Product Group
        if (OutStandingBalance != None && OutStandingBalance.get == 0 && (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S") || ProductStatus.equalsIgnoreCase("W"))) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_OSBL_02 |"
          ErroeMsgs = ErroeMsgs + "Error: OutStanding must not be zero when ProductStatus is A,S or W |"
        } //OutStanding must not be less than zero when ProductStatus is” A”, “S” or W and  products falling into Personal Finance,Vehicle and Mortgage Product Group
        else if (OutStandingBalance.get < 0 && (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S") || ProductStatus.equalsIgnoreCase("W"))) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_OSBL_03 |"
          ErroeMsgs = ErroeMsgs + "Error: OutStanding must not be less than zero when ProductStatus is A,S or W  |"
        }
      }
      //*** End of  OutstandingBalance  Rules ****
      //*** Start of  ProductStatus  Rules ****
      //ProductStatus “A” or “S” is probably not correct when one (or more) of the following is encountered:
      //1:PaymentStatus is “C” or “W”
      if ((ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S")) && (PaymentStatus.equalsIgnoreCase("C") || PaymentStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_01 |"
        ErroeMsgs = ErroeMsgs + "Error: ProductStatus can't be  A or S when PaymentStatus is C or W |"
      }
      //ProductStatus “A” or “S” is probably not correct when one (or more) of the following is encountered:
      //2:OutStandingBalance is less than or equal to zero when ProductGroup in PF and AL
      if ((ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S")) && OutStandingBalance.get <= 0 && (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_02 |"
        ErroeMsgs = ErroeMsgs + "Error: ProductStatus can't be  A or S when OutStandingBalance is less than or equal to zero |"
      }
      /*: TO DO check the default status
      //ProductStatus “A” or “S” is probably not correct when one (or more) of the following is encountered:
      //3:DefaultStatus (default information) is provided
      if( (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S")))// :TO DO  && DefaultStatus != null )
      {
        //Note:  VLS and VIN products with Default status of “FS” are excluded from this validation.
        if(! ( (ProductType.equalsIgnoreCase("VLS")||ProductType.equalsIgnoreCase("VIN"))  ) ) //:To DO &&  DefaultStatus.equalsIgnoreCase("FS") ))
        {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PRST_03 |"
          ErroeMsgs = ErroeMsgs + "Error: ProductStatus can't be  A or S when DefaultStatus is not null |"
        }
      }
                         */
      //ProductStatus “C” is probably not correct when one (or more) of the following is encountered:
      //1: PaymentStatus is not “C”
      if (ProductStatus.equalsIgnoreCase("C") && !(PaymentStatus.equalsIgnoreCase("C"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_04 |"
        ErroeMsgs = ErroeMsgs + "Error:  ProductStatus can't be  C when PaymentStatus is not C  |"
      }
      //ProductStatus “C” is probably not correct when one (or more) of the following is encountered:
      //2: OutStandingBalance is greater than zero
      if (ProductStatus.equalsIgnoreCase("C") && OutStandingBalance.get > 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_05 |"
        ErroeMsgs = ErroeMsgs + "Error:  ProductStatus can't be  C when OutStandingBalance is greater than zero  |"
      }
      /* :TO DO
      //ProductStatus “C” is probably not correct when one (or more) of the following is encountered:
      //3:DefaultStatus (default information) is provided
      if( ProductStatus.equalsIgnoreCase("C") )// :TO DO && DefaultStatus != null )
      {
         //Note: The following products with Default status “FS” and “RS” are excluded from this validation: VIN,VLS, SMEI, SMEL, MBL, LND, AQAR, MTG, IMTG, RERA, ADFL and WAT.
         val excludeList=List("VIN","VLS", "SMEI", "SMEL", "MBL", "LND", "AQAR", "MTG", "IMTG", "RERA", "ADFL","WAT")
         if(! ( excludeList.contains(ProductType) &&  (DefaultStatus.equalsIgnoreCase("FS")||DefaultStatus.equalsIgnoreCase("RS")) ))
         {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_PRST_06 |"
            ErroeMsgs = ErroeMsgs + "Error:   ProductStatus can't be  C when DefaultStatus is provided  |"
        }
      }
                         */
      //ProductStatus “W” is probably not correct when one (or more) of the following is encountered:
      //1:PaymentStatus is not “W”
      if (ProductStatus.equalsIgnoreCase("W") && !(PaymentStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_07 |"
        ErroeMsgs = ErroeMsgs + "Error:  ProductStatus can't be  W when PaymentStatus is not W  |"
      }
      //ProductStatus “W” is probably not correct when one (or more) of the following is encountered:
      //2: OutStandingBalance is greater than zero
      if (ProductStatus.equalsIgnoreCase("W") && OutStandingBalance.get <= 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_08 |"
        ErroeMsgs = ErroeMsgs + "Error:  ProductStatus can't be  W when OutStandingBalance is less than or equal to zero  |"
      }
      /* :TO DO
      //ProductStatus “W” is probably not correct when one (or more) of the following is encountered:
      //2: DefaultStatus is Null
      if( ProductStatus.equalsIgnoreCase("W")  && DefaultStatus == null )
      {
         validFlag = "ERROR"
         ErrorIds = ErrorIds + "ERR_PRST_09 |"
         ErroeMsgs = ErroeMsgs + "Error : ProductStatus can't be  W whenDefaultStatus is Null  |"
      }
                         */
      //*** End of  ProductStatus  Rules ****
      //*** Start of PaymentStatus  Rules ****
      //PaymentStatus is probably not correct when it is 0 and ProductStatus is “C” or “W”
      if (PaymentStatus.equalsIgnoreCase("0") && (ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_01 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus 0 (zero)  is not correct when ProductStatus is C or W  |"
      }
      //PaymentStatus is probably not correct when it is 0 and PastDueBalance is greater than zero
      //Note: it would be ok to have cases with very small figures in the PastDueBalance(e.g. few Riyals) and the member reports the Status as 0
      if (PaymentStatus.equalsIgnoreCase("0") && PastDueBalance.get >= 10) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_02 |"
        ErroeMsgs = ErroeMsgs + "Error :  PaymentStatus 0 (zero)  is not correct when PastDueBalance is greater than zero  |"
      }
      val payStatList = List("1", "2", "3", "4", "5", "6")
      //PaymentStatus is probably not correct when it is 1, 2, 3, 4, 5, or 6 and ProductStatus is “C” or “W”
      if (payStatList.contains(PaymentStatus) && (ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_03 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus I,2,3,4,5, or 6  is not correct when ProductStatus is C or W  |"
      }
      //PaymentStatus is probably not correct when it is 1, 2, 3, 4, 5, or 6 and PastDueBalance is equal to zero
      if (payStatList.contains(PaymentStatus) && (PastDueBalance == None || PastDueBalance.get == 0)) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_04 |"
        ErroeMsgs = ErroeMsgs + "Error :  PaymentStatus I,2,3,4,5, or 6  is not correct whenPastDueBalance is equal to zero  |"
      }
      //PaymentStatus is probably not correct when It is “F” or “Q” and ProductType is not related to PRC ProductGroup
      if ((!CCProductGroup.contains(ProductType)) && (PaymentStatus.equalsIgnoreCase("F") || PaymentStatus.equalsIgnoreCase("Q"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_05 |"
        ErroeMsgs = ErroeMsgs + "Error :   PaymentStatus F or Q  is not correct when ProductType is not related to PRC ProductGroup  |"
      }
      /*
      //PaymentStatus is probably not correct when It is “F” and ProductType is not MBL or LND
      if(!( ProductType.equalsIgnoreCase("MLB") || ProductType.equalsIgnoreCase("LND")) &&  PaymentStatus.equalsIgnoreCase("F") )
      {
         validFlag = "ERROR"
         ErrorIds = ErrorIds + "ERR_PYST_06 |"
         ErroeMsgs = ErroeMsgs + "Error : PaymentStatus F is not correct when ProductType is not MBL or LND  |"
      }
                         */
      //PaymentStatus is probably not correct when It is “F” or “Q” and OutStandingBalance is greater than zero
      if ((PaymentStatus.equalsIgnoreCase("F") || PaymentStatus.equalsIgnoreCase("Q")) && OutStandingBalance.get > 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_07 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus F or Q  is not correct when  OutStandingBalance is greater than zero |"
      }
      //PaymentStatus is probably not correct when It is “F” or “Q” and PastDueBalance is greater than zero
      if ((PaymentStatus.equalsIgnoreCase("F") || PaymentStatus.equalsIgnoreCase("Q")) && PastDueBalance.get > 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_08 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus F or Q  is not correct when PastDueBalance is greater zero  |"
      }
      //PaymentStatus is probably not correct when It is “N” or “D” and ProductStatus is “C” or “W”
      if ((PaymentStatus.equalsIgnoreCase("N") || PaymentStatus.equalsIgnoreCase("D")) && (ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_09 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus N or D  is not correct when the ProductStatus is C or W |"
      }
      //PaymentStatus is probably not correct when It is “R” and ProductStatus is not “S”
      if (PaymentStatus.equalsIgnoreCase("R") && ProductStatus.equalsIgnoreCase("S")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_10 |"
        ErroeMsgs = ErroeMsgs + "Error :  PaymentStatus R is not correct when  ProductStatus is not S |"
      }
      //PaymentStatus is probably not correct when It is “R” and the PastDueBalance is not greater than zero
      if (PaymentStatus.equalsIgnoreCase("R") && PastDueBalance.get <= 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_11 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus R is not correct when PastDueBalance is not greater than zero  |"
      }
      //*** End of  PaymentStatus  Rules ****
      //*** Start of  PastDueBalance  Rules ****
      //PastDueBalance must be zero when ProductStatus is C
      if (ProductStatus.equalsIgnoreCase("C") && PastDueBalance != None && PastDueBalance.get != 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PDBL_02 |"
        ErroeMsgs = ErroeMsgs + "Error : PastDueBalance must be zero when ProductStatus is C  |"
      }
      // PastDueBalance must be greater than zero when ProductStatus is W
      if (ProductStatus.equalsIgnoreCase("W") && PastDueBalance != None && PastDueBalance.get <= 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PDBL_03 |"
        ErroeMsgs = ErroeMsgs + "Error : PastDueBalance must be greater than zero when ProductStatus is W |"
      }
      //PastDueBalance should not be less than zero
      if (PastDueBalance != None && PastDueBalance.get < 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PDBL_04 |"
        ErroeMsgs = ErroeMsgs + "Error : PastDueBalance should not be less than zero |"
      }
      //*** Start   of  LastAmountPaid  Rules ****
      if (LastAmountPaid != None && OriginalAmount != None) {
        // LastAmountPaid should not be greater than OriginalAmount (applicable for Vehicle and Personal Finance Groups)
        //Note: For products falling within Vehicle and Personal Finance groups, LastAmountPaid can be greater than OriginalAmount only for balloon contracts.
        //This type of loans has only one payment that is due on maturity. This validation looks at the Tenure value to determine if the product is balloon contracts or not
        if ((PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType)) && LastAmountPaid.get > OriginalAmount.get && Tenure.get > 1) {
          // validFlag = "ERROR"
          // ErrorIds = ErrorIds + "ERR_LTAP_02 |"
          // ErroeMsgs = ErroeMsgs + "Error : LastAmountPaid cannot not be greater than OriginalAmount |"
          validFlag = "WARNING"
          ErrorIds = ErrorIds + "WAR_LTAP_01 |"
          ErroeMsgs = ErroeMsgs + "Warning:  LastAmountPaid is greater than OriginalAmount |"
        }
        //LastAmountPaid cannot not be less than zero
        if (LastAmountPaid.get < 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_LTAP_01 |"
          ErroeMsgs = ErroeMsgs + "Error : LastAmountPaid cannot not be less than zero |"
        }
      }
      //*** End of  LastAmountPaid  Rules ****
      //Return
      //%% Seq((validFlag,ErrorIds,ErroeMsgs))
      //new RegularDataOutput2(DEFAULT_FLAG, NEW_ACCT_FLAG ,         RUN_NO ,           CIF_NUMBER ,                AccountNumber ,            IssueDate ,          ProductType ,    OriginalAmount ,              SALARY_ASSIGNMENT ,                ExpiryDate ,        ProductStatus , InstallmentAmount ,      FREQ_REPAYMENTS ,     PaymentFrequency ,                Tenure ,               SECURITY_TYPE ,              LastCycleID ,       LastPaymentDate ,          LastAmountPaid ,                PaymentStatus ,               OutStandingBalance ,     PastDueBalance ,             AsOfDate ,          NextPaymentDate ,                DefaultStatus ,  ACCOUNT_SADAD_REF_NUMBER ,          NUMBER_OF_APPLICANTS ,        ValidFlag ,                ErrorIDs ,             ErrorMsgs,
      //  var VLSAccountNumber = if(AccountNumber.startsWith("6666")) "6666".concat(AccountNumber) else AccountNumber
      new HistoryDQReport_V_01(
        AccountNumber,
        ProductType,
        validFlag,
        ErrorIds,
        ErroeMsgs)
    } // End of getHistoryDQReport function
  //Start function getRequestFileDQReport
  def getRequestFileDQReport(
    AccountNumber:        String,
    ProductType:          String,
    SalaryAssignmentFlag: String,
    PaymentFrequency:     String,
    SecurityType:         String,
    IssueDate:            java.sql.Date,
    ExpiryDate:           java.sql.Date,
    AsOfDate:             java.sql.Date,
    //CloseDate: java.sql.Date,
    ProductStatus:      String,
    PaymentStatus:      String,
    Tenure:             Option[Integer],
    InstallmentAmount:  Option[Double],
    OriginalAmount:     Option[Double],
    OutStandingBalance: Option[Double],
    PastDueBalance:     Option[Double],
    LastCycleID:        Option[Integer],
    LastAmountPaid:     Option[Double],
    LastPaymentDate:    java.sql.Date,
    NextPaymentDate:    java.sql.Date): HistoryDQReport_V_01 =
    {
      var validFlag = "VALID"
      var ErrorIds = ""
      var ErroeMsgs = ""
      //# # This list is used to validate the rules for OriginalAmount and OutStandingAmount
      val ProductTypeList = List("PLN", "RPLN", "MTG")
      // val IssueDate=new java.sql.Date(CIUploadDate.getTime)
      // val ExpiryDate=new java.sql.Date(CIUploadDate.getTime)
      // val LastPaymentDate=new java.sql.Date(CIUploadDate.getTime)
      // val NextPaymentDate=new java.sql.Date(CIUploadDate.getTime)
      // val AsOfDate=new java.sql.Date(CIUploadDate.getTime)
      val ClosedDate = if (ProductStatus.equalsIgnoreCase("C")) AsOfDate else null
      //*** Start of  IssueDate Rules ****
      //Pending:
      //1: Error: IssueDate > AsOfDate
      //2: Error: IssueDate > CycleID;
      /*
     //IssueDate is mandatory and must be provided for all products
     if(IssueDate != null)
     {
       val daysDiff = ( CIUploadDate.getTime() - IssueDate.getTime()) / (60 * 60 * 1000 *24)
     //  println("Dates:"+IssueDate+" : "+CIUploadDate+" : diffDays :"+ daysDiff)
       /* @@ review
       //Account should be loaded to Simah within a week from opening :Error: CI was not loaded within a week from opening
       if( daysDiff > 7)
       {
         //println("AccountNumber:"+AccountNumber +" Dates:"+IssueDate+" : "+CIUploadDate+" : diffDays :"+ daysDiff)
         validFlag="ERROR"
         ErrorIds= ErrorIds+"ERR_ISDT_02 |"
         ErroeMsgs=ErroeMsgs+"Error: CI was not loaded within a week from opening |"
       }
                         */
       //IssueDate must not be greater than CIUploadDate :Error: IssueDate > CI Upload Date
       if(IssueDate.compareTo(CIUploadDate) > 0)
       {
         validFlag="ERROR"
         ErrorIds= ErrorIds+"ERR_ISDT_04 |"
         ErroeMsgs=ErroeMsgs+"Error: IssueDate must not be greater than CIUploadDate |"
       }
     }*/
      //*** End of IssueDate Rules ******
      //*** Start of  CloseDate Rules ****
      /* //ClosedDate is the closure date for the credit instrument. This field is system generated by Simah and it is extracted from the last AsOfDate provided by the member when closing the account
     if ( (ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W")) && AsOfDate == null  )
     {
       validFlag="ERROR"
       ErrorIds=ErrorIds+"ERR_CLDT_01 |"
       ErroeMsgs=ErroeMsgs+"Error:  CloseDate is missing. It should be provided when product status is C or W |"
     }
     if(ProductStatus.equalsIgnoreCase("C") && CloseDate != null)
     {
       val daysDiff = ( CIUpdateDate.getTime() - CloseDate.getTime()) / (60 * 60 * 1000 *24)
       /* @@ review
       //CI should be closed within a week from closure date
       if( daysDiff > 7)
       {
          // println("AccountNumber:"+AccountNumber + " CIUploadDate:" + CIUploadDate + "ClosedDate: "+ ClosedDate + "  DaysDiff:"+daysDiff)
           validFlag="ERROR"
           ErrorIds=ErrorIds+"ERR_CLDT_02 |"
           ErroeMsgs=ErroeMsgs+"Error:  CI should be closed within a week from closure date |"
       }
                         */
       //ClosedDate cannot be greater than CIUpdateDate
       if( daysDiff < 0)
       {
           validFlag="ERROR"
           ErrorIds=ErrorIds+"ERR_CLDT_03 |"
           ErroeMsgs=ErroeMsgs+"Error:  CloseDate cannot be greater than CIUpdateDate |"
       }
     }*/
      //*** End of ClosedDate Data Rules ****
      //*** Start of  NextPaymentDate Rules ****
      //NextPaymentDate should be null when ProductStatus is “C” or “W”
      if (NextPaymentDate != null && ProductStatus.equalsIgnoreCase("W")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_NPDT_03 |"
        ErroeMsgs = ErroeMsgs + "NextPaymentDate should be null when ProductStatus is W |"
      } else if (NextPaymentDate != null && ProductStatus.equalsIgnoreCase("C")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_NPDT_03 |"
        ErroeMsgs = ErroeMsgs + "NextPaymentDate should be null when ProductStatus is C |"
      }
      //*** End of NextPaymentDate Data Rules ****
      //*** Start of  LastPaymentDate Rules ****
      if (LastPaymentDate != null && IssueDate != null) {
        //LastPaymentDate must not be less than IssueDate
        if (LastPaymentDate.compareTo(IssueDate) < 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_LPDT_01 |"
          ErroeMsgs = ErroeMsgs + "Error: LastPaymentDate must not be less than IssueDate |"
        }
      }
      //*** End of LastPaymentDate Data Rules ****
      //*** Start of  InstallmentAmount Rules ****
      if (ProductType != null && !ProductType.trim().isEmpty()) {
        if (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)) {
          if (InstallmentAmount != None && OriginalAmount != None && InstallmentAmount.get > OriginalAmount.get) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "WAR_EMIA_01 |"
            ErroeMsgs = ErroeMsgs + "Warning:  InstallmentAmount may not be correct because: InstallmentAmount > OriginalAmount |"
          }
          //InstallmentAmount must be provided for products falling into Personal Finance,Vehicle and Mortgage Product Group
          if (InstallmentAmount == None) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EMIA_01 |"
            ErroeMsgs = ErroeMsgs + "Error: InstallmentAmount is mandatory for this Product type |"
          } //InstallmentAmount should not be equal to zero
          else if (InstallmentAmount == None) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EMIA_03 |"
            ErroeMsgs = ErroeMsgs + "Error: InstallmentAmount cannot be Zero |"
          } //InstallmentAmount should not be less than zero
          else if (InstallmentAmount.get < 0) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EMIA_02 |"
            ErroeMsgs = ErroeMsgs + "Error: InstallmentAmount cannot be less than Zero |"
          }
        }
      }
      //*** End of  InstallmentAmount Rules ****
      //*** Start of  Tenure Rules ****
      if (ProductType != null && !ProductType.trim().isEmpty()) {
        if (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)) {
          //The time period Tenure and PaymentFrequency indicate should be close to the difference between IssueDate and ExpiryDate. Note: 25% margin is allowed in case a member allows for a grace period for his customers
          //[[PaymentFrequency is not available]] if(Tenure != None && PaymentFrequency != null && IssueDate != null && ExpiryDate != null)
          if (Tenure != None && IssueDate != null && ExpiryDate != null) {
            //val TenureInMonths=Tenure
            val TenureInMonths =
              {
                if (PaymentFrequency.equalsIgnoreCase("Y"))
                  (Tenure.get * 12).toInt
                else if (PaymentFrequency.equalsIgnoreCase("Q"))
                  (Tenure.get * 3).toInt
                else if (PaymentFrequency.equalsIgnoreCase("H"))
                  (Tenure.get * 6).toInt
                else if (PaymentFrequency.equalsIgnoreCase("M"))
                  (Tenure.get).toInt
                else
                  (Tenure.get).toInt
              }
            // var highEnd= TenureInMonths + (TenureInMonths* 0.2).toInt
            //var lowEnd= TenureInMonths - (TenureInMonths* 0.2).toInt
            var exeTime2 = (ExpiryDate.getTime - IssueDate.getTime)
            var diffDays = exeTime2 / (24 * 60 * 60 * 1000)
            var diffMonths = (diffDays / 30.0).round.toInt
            var highEnd = diffMonths + (diffMonths * 0.2).toInt
            var lowEnd = diffMonths - (diffMonths * 0.2).toInt
            //   println("IssueDate :"+IssueDate +" ExpiryDate:"+ExpiryDate+" diffDays:"+diffDays +" diffMonths: " +diffMonths +" Tenure: " +Tenure +" highEnd: " +highEnd+" lowEnd: " +lowEnd)
            //if(TenureInMonths != diffMonths  && TenureInMonths != diffMonths-1 && TenureInMonths != diffMonths-2 && TenureInMonths != diffMonths+1 && TenureInMonths != diffMonths+2  )
            //  if( diffMonths > lowEnd && diffMonths < highEnd )
            //#  if( Tenure.get > lowEnd && Tenure.get < highEnd )
            if (Tenure.get < lowEnd || Tenure.get > highEnd) {
              // DEBUG println("True:###: Account:"+AccountNumber +" IssueDate :" + IssueDate +" ExpiryDate:"+ExpiryDate+" diffDays:"+diffDays +" diffMonths: " +diffMonths +" Tenure: " +Tenure.get +" highEnd: " +highEnd+" lowEnd: " +lowEnd)
              validFlag = "WARNING"
              ErrorIds = ErrorIds + "WAR_TNR_01 |"
              ErroeMsgs = ErroeMsgs + "Warning: Tenure may not be correct because it doesn't match the difference between Issue and Expiry Dates |"
            }
            /* [[PaymentFrequency is not available]]
           if( (PaymentFrequency.equalsIgnoreCase("M")  && Tenure.get >480 )
               || (PaymentFrequency.equalsIgnoreCase("Q")  && Tenure.get >160 )
               || (PaymentFrequency.equalsIgnoreCase("H")  && Tenure.get >80 )
               || (PaymentFrequency.equalsIgnoreCase("Y")  && Tenure.get >40 ))
           {
             validFlag="WARNING"
             ErrorIds= ErrorIds+"WAR_TNR_02 |"
             ErroeMsgs=ErroeMsgs+"Warning:Tenure value is probably not correct. It is too high |"
           }
                               *
                               */
          }
          //Tenure is mandatory and must be provided for Personal Finance,Vehicle and Mortgage Product Group
          if (Tenure == None) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_TNR_01 |"
            ErroeMsgs = ErroeMsgs + "Error: Tenure is mandatory for this Product type |"
          } //Tenure must not be equal to zero
          else if (Tenure.get == 0) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_TNR_03 |"
            ErroeMsgs = ErroeMsgs + "Error: Tenure cannot be Zero |"
          } //Tenure must not be less than zero
          else if (Tenure.get < 0) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_TNR_02 |"
            ErroeMsgs = ErroeMsgs + "Error: Tenure cannot be less than Zero |"
          }
        }
      }
      //*** End of  Tenure Rules ****
      //*** Start of  OriginalAmount  Rules ****
      //OriginalAmount is mandatory and must be provided for all products
      if (OriginalAmount == None) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_ORGA_01 |"
        ErroeMsgs = ErroeMsgs + "Error: OriginalAmount is mandatory and must be provided |"
      } //OriginalAmount should not be  zero
      else if (OriginalAmount.get == 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_ORGA_03 |"
        ErroeMsgs = ErroeMsgs + "Error: OriginalAmount cannot be Zero |"
      } //OriginalAmount should not be less than zero
      else if (OriginalAmount.get < 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_ORGA_02 |"
        ErroeMsgs = ErroeMsgs + "Error: OriginalAmount cannot be less than Zero |"
      }
      //OriginalAmount should not be greater than (InstallmentAmount * Tenure) This rule applies for most products falling in the Personal Finance, Mortgage and Vehicle Product groups  However, VLS and VIN products are excluded temporary due to the confusion that is
      //happening because of the balloon payment. After Simah introduce the balloon payment on its report,VLS and VINs are going to be validated
      if (ProductType != null && !ProductType.trim().isEmpty() && (!ProductType.equalsIgnoreCase("VLS") || !ProductType.equalsIgnoreCase("VIN"))) {
        if (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)) {
          // # #iN DQ Report TMTG product type is excluded from this validation
          // # #iN DQ Report this Rule is applied for only PLN , RPLN and MTG Products
          if (ProductTypeList.contains(ProductType) && InstallmentAmount != None && InstallmentAmount.get != 0 && Tenure != None && OriginalAmount != None && OriginalAmount.get != 0) {
            if (OriginalAmount.get > (InstallmentAmount.get * Tenure.get)) {
              validFlag = "ERROR"
              ErrorIds = ErrorIds + "ERR_ORGA_04 |"
              ErroeMsgs = ErroeMsgs + "Error: OriginalAmount > (InstallmentAmount * Tenure) |"
            } else if (OriginalAmount.get == (InstallmentAmount.get * Tenure.get)) {
              validFlag = "ERROR"
              ErrorIds = ErrorIds + "ERR_ORGA_05 |"
              ErroeMsgs = ErroeMsgs + "Error: OriginalAmount = (InstallmentAmount * Tenure) This indicates Profit is included in OriginalAmount |"
            }
          }
        }
      }
      //*** End of  OriginalAmount  Rules ****
      //*** Start of  OutstandingBalance  Rules ****
      //OutstandingAmount must not be greater than zero when ProductStatus is “C”
      if (OutStandingBalance != None && OutStandingBalance.get > 0 && ProductStatus.equalsIgnoreCase("C")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_OSBL_01 |"
        ErroeMsgs = ErroeMsgs + "Error: OutStandingBalance shoud not be grater than zero for closed products |"
      }
      if (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)) {
        // # #Need to Verify  OutStanding shoud not be greater than (InstallmentAmount * Tenure) where payment status =0
        // # #iN DQ Report TMTG product type is excluded from this validation
        // # #iN DQ Report this Rule is applied for only PLN , RPLN and MTG Products
        if (ProductTypeList.contains(ProductType) && OutStandingBalance != None && InstallmentAmount != None && Tenure != None && PaymentStatus != null && PaymentStatus.equalsIgnoreCase("0")) {
          //val escapeMargin=InstallmentAmount.get * 3 // 3 installments
          //Margin 3 installments
          val value = (InstallmentAmount.get + 3) * Tenure.get
          if (OutStandingBalance.get > value) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_OSBL_07 |"
            ErroeMsgs = ErroeMsgs + "Error:  OutStanding is way greater than (InstallmentAmount * Tenure)|"
          }
        }
        //OutStanding must not be zero when ProductStatus is” A”, “S” or W and  products falling into Personal Finance,Vehicle and Mortgage Product Group
        if (OutStandingBalance != None && OutStandingBalance.get == 0 && (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S") || ProductStatus.equalsIgnoreCase("W"))) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_OSBL_02 |"
          ErroeMsgs = ErroeMsgs + "Error: OutStanding must not be zero when ProductStatus is A,S or W |"
        } //OutStanding must not be less than zero when ProductStatus is” A”, “S” or W and  products falling into Personal Finance,Vehicle and Mortgage Product Group
        else if (OutStandingBalance.get < 0 && (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S") || ProductStatus.equalsIgnoreCase("W"))) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_OSBL_03 |"
          ErroeMsgs = ErroeMsgs + "Error: OutStanding must not be less than zero when ProductStatus is A,S or W  |"
        }
      }
      //*** End of  OutstandingBalance  Rules ****
      //*** Start of  ProductStatus  Rules ****
      //ProductStatus “A” or “S” is probably not correct when one (or more) of the following is encountered:
      //1:PaymentStatus is “C” or “W”
      if ((ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S")) && (PaymentStatus.equalsIgnoreCase("C") || PaymentStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_01 |"
        ErroeMsgs = ErroeMsgs + "Error: ProductStatus can't be  A or S when PaymentStatus is C or W |"
      }
      //ProductStatus “A” or “S” is probably not correct when one (or more) of the following is encountered:
      //2:OutStandingBalance is less than or equal to zero when ProductGroup in PF and AL
      if ((ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S")) && OutStandingBalance.get <= 0 && (PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_02 |"
        ErroeMsgs = ErroeMsgs + "Error: ProductStatus can't be  A or S when OutStandingBalance is less than or equal to zero |"
      }
      /*: TO DO check the default status
      //ProductStatus “A” or “S” is probably not correct when one (or more) of the following is encountered:
      //3:DefaultStatus (default information) is provided
      if( (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S")))// :TO DO  && DefaultStatus != null )
      {
        //Note:  VLS and VIN products with Default status of “FS” are excluded from this validation.
        if(! ( (ProductType.equalsIgnoreCase("VLS")||ProductType.equalsIgnoreCase("VIN"))  ) ) //:To DO &&  DefaultStatus.equalsIgnoreCase("FS") ))
        {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PRST_03 |"
          ErroeMsgs = ErroeMsgs + "Error: ProductStatus can't be  A or S when DefaultStatus is not null |"
        }
      }
             */
      //ProductStatus “C” is probably not correct when one (or more) of the following is encountered:
      //1: PaymentStatus is not “C”
      if (ProductStatus.equalsIgnoreCase("C") && !(PaymentStatus.equalsIgnoreCase("C"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_04 |"
        ErroeMsgs = ErroeMsgs + "Error:  ProductStatus can't be  C when PaymentStatus is not C  |"
      }
      //ProductStatus “C” is probably not correct when one (or more) of the following is encountered:
      //2: OutStandingBalance is greater than zero
      if (ProductStatus.equalsIgnoreCase("C") && OutStandingBalance.get > 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_05 |"
        ErroeMsgs = ErroeMsgs + "Error:  ProductStatus can't be  C when OutStandingBalance is greater than zero  |"
      }
      /* :TO DO
      //ProductStatus “C” is probably not correct when one (or more) of the following is encountered:
      //3:DefaultStatus (default information) is provided
      if( ProductStatus.equalsIgnoreCase("C") )// :TO DO && DefaultStatus != null )
      {
         //Note: The following products with Default status “FS” and “RS” are excluded from this validation: VIN,VLS, SMEI, SMEL, MBL, LND, AQAR, MTG, IMTG, RERA, ADFL and WAT.
         val excludeList=List("VIN","VLS", "SMEI", "SMEL", "MBL", "LND", "AQAR", "MTG", "IMTG", "RERA", "ADFL","WAT")
         if(! ( excludeList.contains(ProductType) &&  (DefaultStatus.equalsIgnoreCase("FS")||DefaultStatus.equalsIgnoreCase("RS")) ))
         {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_PRST_06 |"
            ErroeMsgs = ErroeMsgs + "Error:   ProductStatus can't be  C when DefaultStatus is provided  |"
        }
      }
             */
      //ProductStatus “W” is probably not correct when one (or more) of the following is encountered:
      //1:PaymentStatus is not “W”
      if (ProductStatus.equalsIgnoreCase("W") && !(PaymentStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_07 |"
        ErroeMsgs = ErroeMsgs + "Error:  ProductStatus can't be  W when PaymentStatus is not W  |"
      }
      //ProductStatus “W” is probably not correct when one (or more) of the following is encountered:
      //2: OutStandingBalance is greater than zero
      if (ProductStatus.equalsIgnoreCase("W") && OutStandingBalance.get <= 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRST_08 |"
        ErroeMsgs = ErroeMsgs + "Error:  ProductStatus can't be  W when OutStandingBalance is less than or equal to zero  |"
      }
      /* :TO DO
      //ProductStatus “W” is probably not correct when one (or more) of the following is encountered:
      //2: DefaultStatus is Null
      if( ProductStatus.equalsIgnoreCase("W")  && DefaultStatus == null )
      {
         validFlag = "ERROR"
         ErrorIds = ErrorIds + "ERR_PRST_09 |"
         ErroeMsgs = ErroeMsgs + "Error : ProductStatus can't be  W whenDefaultStatus is Null  |"
      }
             */
      //*** End of  ProductStatus  Rules ****
      //*** Start of PaymentStatus  Rules ****
      //PaymentStatus is probably not correct when it is 0 and ProductStatus is “C” or “W”
      if (PaymentStatus.equalsIgnoreCase("0") && (ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_01 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus 0 (zero)  is not correct when ProductStatus is C or W  |"
      }
      //PaymentStatus is probably not correct when it is 0 and PastDueBalance is greater than zero
      //Note: it would be ok to have cases with very small figures in the PastDueBalance(e.g. few Riyals) and the member reports the Status as 0
      if (PaymentStatus.equalsIgnoreCase("0") && PastDueBalance != None && PastDueBalance.get >= 10) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_02 |"
        ErroeMsgs = ErroeMsgs + "Error :  PaymentStatus 0 (zero)  is not correct when PastDueBalance is greater than zero  |"
      }
      val payStatList = List("1", "2", "3", "4", "5", "6")
      //PaymentStatus is probably not correct when it is 1, 2, 3, 4, 5, or 6 and ProductStatus is “C” or “W”
      if (payStatList.contains(PaymentStatus) && (ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_03 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus I,2,3,4,5, or 6  is not correct when ProductStatus is C or W  |"
      }
      //PaymentStatus is probably not correct when it is 1, 2, 3, 4, 5, or 6 and PastDueBalance is equal to zero
      if (payStatList.contains(PaymentStatus) && (PastDueBalance == None || PastDueBalance.get == 0)) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_04 |"
        ErroeMsgs = ErroeMsgs + "Error :  PaymentStatus I,2,3,4,5, or 6  is not correct whenPastDueBalance is equal to zero  |"
      }
      //PaymentStatus is probably not correct when It is “F” or “Q” and ProductType is not related to PRC ProductGroup
      if ((!CCProductGroup.contains(ProductType)) && (PaymentStatus.equalsIgnoreCase("F") || PaymentStatus.equalsIgnoreCase("Q"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_05 |"
        ErroeMsgs = ErroeMsgs + "Error :   PaymentStatus F or Q  is not correct when ProductType is not related to PRC ProductGroup  |"
      }
      /*
      //PaymentStatus is probably not correct when It is “F” and ProductType is not MBL or LND
      if(!( ProductType.equalsIgnoreCase("MLB") || ProductType.equalsIgnoreCase("LND")) &&  PaymentStatus.equalsIgnoreCase("F") )
      {
         validFlag = "ERROR"
         ErrorIds = ErrorIds + "ERR_PYST_06 |"
         ErroeMsgs = ErroeMsgs + "Error : PaymentStatus F is not correct when ProductType is not MBL or LND  |"
      }
             */
      //PaymentStatus is probably not correct when It is “F” or “Q” and OutStandingBalance is greater than zero
      if ((PaymentStatus.equalsIgnoreCase("F") || PaymentStatus.equalsIgnoreCase("Q")) && OutStandingBalance != None && OutStandingBalance.get > 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_07 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus F or Q  is not correct when  OutStandingBalance is greater than zero |"
      }
      //PaymentStatus is probably not correct when It is “F” or “Q” and PastDueBalance is greater than zero
      if ((PaymentStatus.equalsIgnoreCase("F") || PaymentStatus.equalsIgnoreCase("Q")) && PastDueBalance != None && PastDueBalance.get > 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_08 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus F or Q  is not correct when PastDueBalance is greater zero  |"
      }
      //PaymentStatus is probably not correct when It is “N” or “D” and ProductStatus is “C” or “W”
      if ((PaymentStatus.equalsIgnoreCase("N") || PaymentStatus.equalsIgnoreCase("D")) && (ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_09 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus N or D  is not correct when the ProductStatus is C or W |"
      }
      //PaymentStatus is probably not correct when It is “R” and ProductStatus is not “S”
      if (PaymentStatus.equalsIgnoreCase("R") && ProductStatus.equalsIgnoreCase("S")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_10 |"
        ErroeMsgs = ErroeMsgs + "Error :  PaymentStatus R is not correct when  ProductStatus is not S |"
      }
      //PaymentStatus is probably not correct when It is “R” and the PastDueBalance is not greater than zero
      if (PaymentStatus.equalsIgnoreCase("R") && PastDueBalance != None && PastDueBalance.get <= 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PYST_11 |"
        ErroeMsgs = ErroeMsgs + "Error : PaymentStatus R is not correct when PastDueBalance is not greater than zero  |"
      }
      //*** End of  PaymentStatus  Rules ****
      //*** Start of  PastDueBalance  Rules ****
      //PastDueBalance must be zero when ProductStatus is C
      if (ProductStatus.equalsIgnoreCase("C") && PastDueBalance != None && PastDueBalance.get != 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PDBL_02 |"
        ErroeMsgs = ErroeMsgs + "Error : PastDueBalance must be zero when ProductStatus is C  |"
      }
      // PastDueBalance must be greater than zero when ProductStatus is W
      if (ProductStatus.equalsIgnoreCase("W") && PastDueBalance != None && PastDueBalance.get <= 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PDBL_03 |"
        ErroeMsgs = ErroeMsgs + "Error : PastDueBalance must be greater than zero when ProductStatus is W |"
      }
      //PastDueBalance should not be less than zero
      if (PastDueBalance != None && PastDueBalance.get < 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PDBL_04 |"
        ErroeMsgs = ErroeMsgs + "Error : PastDueBalance should not be less than zero |"
      }
      //*** Start   of  LastAmountPaid  Rules ****
      if (LastAmountPaid != None && OriginalAmount != None) {
        // LastAmountPaid should not be greater than OriginalAmount (applicable for Vehicle and Personal Finance Groups)
        //Note: For products falling within Vehicle and Personal Finance groups, LastAmountPaid can be greater than OriginalAmount only for balloon contracts.
        //This type of loans has only one payment that is due on maturity. This validation looks at the Tenure value to determine if the product is balloon contracts or not
        if ((PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType)) && LastAmountPaid.get > OriginalAmount.get && Tenure.get > 1) {
          // validFlag = "ERROR"
          // ErrorIds = ErrorIds + "ERR_LTAP_02 |"
          // ErroeMsgs = ErroeMsgs + "Error : LastAmountPaid cannot not be greater than OriginalAmount |"
          validFlag = "WARNING"
          ErrorIds = ErrorIds + "WAR_LTAP_01 |"
          ErroeMsgs = ErroeMsgs + "Warning:  LastAmountPaid is greater than OriginalAmount |"
        }
        //LastAmountPaid cannot not be less than zero
        if (LastAmountPaid.get < 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_LTAP_01 |"
          ErroeMsgs = ErroeMsgs + "Error : LastAmountPaid cannot not be less than zero |"
        }
      }
      //*** End of  LastAmountPaid  Rules ****
      //Return
      //%% Seq((validFlag,ErrorIds,ErroeMsgs))
      //new RegularDataOutput2(DEFAULT_FLAG, NEW_ACCT_FLAG ,         RUN_NO ,           CIF_NUMBER ,                AccountNumber ,            IssueDate ,          ProductType ,    OriginalAmount ,              SALARY_ASSIGNMENT ,                ExpiryDate ,        ProductStatus , InstallmentAmount ,      FREQ_REPAYMENTS ,     PaymentFrequency ,                Tenure ,               SECURITY_TYPE ,              LastCycleID ,       LastPaymentDate ,          LastAmountPaid ,                PaymentStatus ,               OutStandingBalance ,     PastDueBalance ,             AsOfDate ,          NextPaymentDate ,                DefaultStatus ,  ACCOUNT_SADAD_REF_NUMBER ,          NUMBER_OF_APPLICANTS ,        ValidFlag ,                ErrorIDs ,             ErrorMsgs,
      //  var VLSAccountNumber = if(AccountNumber.startsWith("6666")) "6666".concat(AccountNumber) else AccountNumber
      new HistoryDQReport_V_01(
        AccountNumber,
        ProductType,
        validFlag,
        ErrorIds,
        ErroeMsgs)
    } // End of getRequestFileDQReport function
  // Start of function getRejectionRecords
  def getRejectionRecords(
    AccountNumber:        String,
    IssueDate:            java.sql.Date,
    ProductType:          String,
    OriginalAmount:       Option[Double],
    SalaryAssignmentFlag: String,
    ExpiryDate:           java.sql.Date,
    ProductStatus:        String,
    InstallmentAmount:    Option[Double],
    PaymentFrequency:     String,
    Tenure:               Option[Integer],
    SecurityType:         String,
    //NumberOfApplicants:  Option[Integer] ,
    LastCycleID:        Option[Integer],
    LastPaymentDate:    java.sql.Date,
    LastAmountPaid:     Option[Double],
    PaymentStatus:      String,
    OutStandingBalance: Option[Double],
    PastDueBalance:     Option[Double],
    AsOfDate:           java.sql.Date,
    NextPaymentDate:    java.sql.Date,
    IDType:             String,
    IDNumber:           String,
    //NEW_ACCT_FLAG:  Boolean,
    H_IssueDate:            java.sql.Date,
    H_ProductType:          String,
    H_OriginalAmount:       Option[Double],
    H_SalaryAssignmentFlag: String,
    H_ExpiryDate:           java.sql.Date,
    H_ProductStatus:        String,
    H_InstallmentAmount:    Option[Double],
    H_PaymentFrequency:     String,
    H_Tenure:               Option[Integer],
    H_SecurityType:         String,
    H_LastCycleID:          Option[Integer],
    H_LastPaymentDate:      java.sql.Date,
    H_LastAmountPaid:       Option[Double],
    H_PaymentStatus:        String,
    H_OutstandingBalance:   Option[Double],
    H_PastDueBalance:       Option[Double],
    H_AsOfDate:             java.sql.Date,
    H_NextPaymentDate:      java.sql.Date,
    H_IDType:               String,
    H_IDNumber:             String,
    HIST_RUN_NO:            String,
    H_NEW_ACCT_FLAG:        String): RejectRecords_V_01 =
    {
      var validFlag = "VALID"
      var ErrorIds = ""
      var ErroeMsgs = ""
      var NEW_ACCT_FLAG = if (H_LastCycleID == null || H_LastCycleID.isEmpty) true else false
      // For new acconts check manadory fields
      if (NEW_ACCT_FLAG) //|| H_LastCycleID==null || H_LastCycleID.isEmpty)
      {
        //OriginalAmount
        if (OriginalAmount == None || OriginalAmount.get == 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_ORGA_01 |"
          ErroeMsgs = ErroeMsgs + "Error : OriginalAmount is mandatory for all new accounts and it shoud not be zero|"
        }
        //SalaryAssignmentFlag
        if (SalaryAssignmentFlag == null || SalaryAssignmentFlag.isEmpty()) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_SALF_01 |"
          ErroeMsgs = ErroeMsgs + "Error : SalaryAssignmentFlag is mandatory for all new accounts |"
        }
        //PaymentFrequency
        if (PaymentFrequency == null || PaymentFrequency.isEmpty()) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PFRQ_01 |"
          ErroeMsgs = ErroeMsgs + "Error : PaymentFrequency is mandatory for all new accounts |"
        }
        //SecurityType
        if (SecurityType == null || SecurityType.isEmpty()) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_STYP_01 |"
          ErroeMsgs = ErroeMsgs + "Error : SecurityType is mandatory for all new accounts |"
        }
        /* : TO Check , not there in actual rejection file
                                                                  //LastAmountPaid This element must be numeric. For new CI’s it must be zero.
                                                                  if( LastAmountPaid != None && LastAmountPaid.get != 0 )
                                                                  {
                                                                                                 validFlag = "ERROR"
                                                                                                 ErrorIds = ErrorIds + "ERR_APYD_01 |"
                                                                                                 ErroeMsgs = ErroeMsgs + "Error : LastAmountPaid must be zero for all new accounts |"
                                                                  }
                                           * */
        //Tenure is mandatory for the new Credit Instruments, if the provided Product Type is: In the Personal Finance or Product Type = MIS, or Product Type = PE
        //PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)  Product Type = MIS, or Product Type = PE Else it is Optional
        if (PFProductGroup.contains(ProductType) || ProductType.equalsIgnoreCase("MIS") || ProductType.equalsIgnoreCase("PE")) {
          //Tenure is mandatory for above conditions
          if (Tenure == None || Tenure.get == 0) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_TENR_01 |"
            ErroeMsgs = ErroeMsgs + s"Error : Tenure is mandatory for all new accounts with  $ProductType  producttype |"
          }
          //Tenure is mandatory for above conditions
          if (ExpiryDate == None || ExpiryDate == null) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EXPDT_01 |"
            ErroeMsgs = ErroeMsgs + s"Error : ExpiryDate is mandatory for all new accounts with  $ProductType  producttype |"
          }
        }
        //Product Expiry Date must not be provided for the Credit Instruments where Product Type is:  In the Phone products group; or In the Credit Card products group
        if (CCProductGroup.contains(ProductType) || PHProductGroup.contains(ProductType)) {
          if (ExpiryDate != null) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EXPDT_02 |"
            ErroeMsgs = ErroeMsgs + s"Error : ExpiryDate must not be provided for the Credit Instruments where Product Type is :  $ProductType |"
          }
        }
        //IssueDate
        if (IssueDate == None || IssueDate == null) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_ISDT_01 |"
          ErroeMsgs = ErroeMsgs + "Error : IssueDate is mandatory for all new accounts |"
        }
      } // End if new accounts only
      // PastDuebalance If the Payment Status (AACS) is N, Q, 0, F, or C, value must be 0 or less, otherwise it should be more than 0 (which includes W)
      val payStatList = List("N", "Q", "0", "F", "C")
      if (payStatList.contains(PaymentStatus)) {
        if (PastDueBalance.get > 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PDBAL_01 |"
          ErroeMsgs = ErroeMsgs + s"Error : PastDueBalance must  be 0 or less for PaymentStatus:   $PaymentStatus |"
        }
      } else if (PastDueBalance.get < 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PDBAL_02 |"
        ErroeMsgs = ErroeMsgs + s"Error : PastDueBalance should be more than 0  for PaymentStatus:   $PaymentStatus |"
      }
      //NextPaymentDate If account is defaulted or closed then date should be blank
      if ((ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W")) && NextPaymentDate != null) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_NPDT_01 |"
        ErroeMsgs = ErroeMsgs + "Error :  If account is defaulted or closed then NextPaymentDate should be blank|"
      }
      /*
                                                 //NumberOfApplicants Integer 2 >= 1
                                                  if(NumberOfApplicants == None || NumberOfApplicants.get <= 0)
                                                 {
                                                   validFlag = "ERROR"
                                                                 ErrorIds = ErrorIds + "ERR_NAPL_01 |"
                                                                 ErroeMsgs = ErroeMsgs + "Error : NumberOfApplicants should be more than or equal to one for all products |"
                                                 }
                         */
      //OutstandingBalance must be zero if the Credit Instrument Product Status is Closed.
      if (ProductStatus.equalsIgnoreCase("C") && OutStandingBalance.get != 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_OSBAL_01 |"
        ErroeMsgs = ErroeMsgs + "Error :  OutstandingBalance must be zero for closed product status C|"
      }
      //B2B0309 00309 Outstanding balance too low for Credit Instrument to be considered default Reference MasterLookupDoc 3.41             System Control file          (SYSCONM0)
      if (H_ProductStatus != null && !H_ProductStatus.isEmpty()) {
        if (ProductStatus.equalsIgnoreCase("W") && !(H_ProductStatus.equalsIgnoreCase("W")) && OutStandingBalance.get < 500) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_OSBAL_01      |"
          ErroeMsgs = ErroeMsgs + s"Error :  Outstanding balance $OutStandingBalance.get is too low for Credit Instrument to be considered default|"
        }
      }
      //ProductStatus If Code = A or S, the latest Cycle Record Status for the CI must NOT be a C or W
      if (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S")) {
        if (PaymentStatus.equalsIgnoreCase("C") || PaymentStatus.equalsIgnoreCase("W")) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PRDST_01 |"
          ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
        }
      }
      //If Code = C, the latest Cycle Record Status for the CI must be C
      if (ProductStatus.equalsIgnoreCase("C") && !(PaymentStatus.equalsIgnoreCase("C"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_02 |"
        ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
      }
      //If Code = W, the latest Cycle Record Status for the CI must be W
      if (ProductStatus.equalsIgnoreCase("W") && !(PaymentStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_03 |"
        ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
      }
      //If Code = L then the Product Type must be in Product group PRDGRPPCR.
      if (ProductStatus.equalsIgnoreCase("L") && !(CCProductGroup.contains(ProductType))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_04 |"
        ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the Product Type must be in Product group PRDGRPPCR / CCR |"
      }
      //A Credit Instrument Product Sates may be C (Closed) only if the outstanding balance is zero.
      if (ProductStatus.equalsIgnoreCase("C") && OutStandingBalance.get != 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_05 |"
        ErroeMsgs = ErroeMsgs + "Error : A Credit Instrument Product Status can be C (Closed) only if the outstanding balance is zero. |"
      }
      //Product Status ‘X’ (Default Only) cannot be supplied with this service.
      if (ProductStatus.equalsIgnoreCase("X")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_05 |"
        ErroeMsgs = ErroeMsgs + "Error : Product Status ‘X’ (Default Only) cannot be supplied with this service |"
      }
      //######## PaymentStatus Rules
      //If a cycle is received with status ‘W’, but a later cycle exists with an open status, an error condition occurs
      if (H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("W")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_01 |"
        ErroeMsgs = ErroeMsgs + "Error : The CI must not be included in RegularFile as previous status was W (Default) |"
      }
      //Payment Status can be F if the Product Type is:1. in Phone products group; i.e. on Table PRDGRPPH or Credit Card products group; i.e. on Table PRDGRPPCR
      if (!(CCProductGroup.contains(ProductType) || PHProductGroup.contains(ProductType)) && PaymentStatus.equalsIgnoreCase("F")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_02 |"
        ErroeMsgs = ErroeMsgs + s"Error : Payment Status can't be F for this product type: $ProductType|"
      }
      //For new and existing CIs, new or existing cycles - If Credit Instrument Product Status = A or L or S then the latest cycle Payment Status cannot be C or W
      if (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("L") || ProductStatus.equalsIgnoreCase("S")) {
        if (PaymentStatus.equalsIgnoreCase("C") || PaymentStatus.equalsIgnoreCase("W")) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PAYST_03 |"
          ErroeMsgs = ErroeMsgs + "Error : Product Status = A or L or S then the latest cycle Payment Status cannot be C or W |"
        }
      }
      //If the latest cycle status = C loading of new cycle(s) will not be allowed, error message will be returned. Latest cycle status C cannot be changed to any other value. (AD 9978)
      if (H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("C")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_04 |"
        ErroeMsgs = ErroeMsgs + s"Error :  Payment Status cannot be changed to this value $PaymentStatus as previous status was C (Closed) |"
      }
      //Payment Status can be R only for the credit instruments in the product group Risk of Non-payment PRDGRPSU
      if (!(RNPProductGroup.contains(ProductType)) && PaymentStatus.equalsIgnoreCase("R")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_05 |"
        ErroeMsgs = ErroeMsgs + "Error : Payment Status can be R only for the credit instruments in the product group Risk of Non-payment PRDGRPSU|"
      }
      //Payment status R is valid only for the CI where product status is S
      if (PaymentStatus.equalsIgnoreCase("R") && !(ProductStatus.equalsIgnoreCase("S"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_06 |"
        ErroeMsgs = ErroeMsgs + "Error : Payment status R is valid only for the CI where product status is S|"
      }
      //If the payment status R provided, value in the Outstanding Balance (ACUB) must be < 500.00
      if (PaymentStatus.equalsIgnoreCase("R") && (OutStandingBalance == None || OutStandingBalance.get >= 500)) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_07 |"
        ErroeMsgs = ErroeMsgs + "Error : For Payment status R Outstanding Balance  must be < 500.00|"
      }
      //Payment status R may be loaded only of the previous most recent cycle payment status (in the database) is 6
      if (PaymentStatus.equalsIgnoreCase("R") && H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("6")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_08 |"
        ErroeMsgs = ErroeMsgs + "Error : Payment status R may be loaded only if the previous most recent cycle payment status is 6 |"
      }
      // var VLSAccountNumber = if(AccountNumber.startsWith("6666")) "66".concat(AccountNumber) else AccountNumber
      new RejectRecords_V_01(
        AccountNumber,
        ProductType,
        validFlag,
        ErrorIds,
        ErroeMsgs)
    }
  //End of function getRejectionRecords

  def getDefaultRejectionRecords(row: DefaultRequestPlusHistCaseClass): RejectRecords_V_01 =
    {

      var validFlag = "VALID"
      var ErrorIds = ""
      var ErroeMsgs = ""
      //var NEW_ACCT_FLAG=  if(H_LastCycleID == null || H_LastCycleID.isEmpty)  true else false

      if (row.OutStandingBalance.getOrElse(None) == None) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_DFBAL_01 |"
        ErroeMsgs = ErroeMsgs + "Error :  DefaultOutstandingBalance must be provided |"
      }

      if (row.DefaultStatus.equalsIgnoreCase("FS") && row.OutStandingBalance.get != 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_DFBAL_02 |"
        ErroeMsgs = ErroeMsgs + "Error :  DefaultOutstandingBalance must be zero for Fully Settled loans |"
      }

      val defStsList = List("OS", "FS", "RS", "NS", "PP")

      if (row.H_DefaultStatus == null || row.H_DefaultStatus.equalsIgnoreCase("") || row.H_DefaultStatus.isEmpty() || !(defStsList.contains(row.H_DefaultStatus))) {
        val pst = row.H_ProductStatus
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_DFSTS_01 |"
        ErroeMsgs = ErroeMsgs + s"Error :  Default reference is not exists for this Account , cannot maintain writeoff , existing product status is $pst | "
      }

      // if (row.DefaultStatus.equalsIgnoreCase("FS") &&  row.H_DefaultStatus!=null && row.H_DefaultStatus.equalsIgnoreCase("FS")) {
      if (row.DefaultStatus != null && row.H_DefaultStatus != null && row.H_DefaultStatus.equalsIgnoreCase("FS")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_DFSTS_02 |"
        ErroeMsgs = ErroeMsgs + "Error :  Default record is already 'FS' |"
      }
      // var VLSAccountNumber = if(AccountNumber.startsWith("6666")) "66".concat(AccountNumber) else AccountNumber

      new RejectRecords_V_01(
        row.AccountNumber,
        row.ProductType,
        validFlag,
        ErrorIds,
        ErroeMsgs)
    }
  //End of function getDefaultRejectionRecords

  // Start of function getRejectionRecords
  def getRejectionRecords_V6(row: InputHistCaseClass): RejectRecords_V_01 =
    {
      val ProductType = row.ProductType
      val PaymentStatus = row.PaymentStatus
      val ProductStatus = row.ProductStatus
      val H_PaymentStatus = row.H_PaymentStatus
      val H_ProductStatus = row.H_ProductStatus
      val OutStandingBalance = row.OutStandingBalance

      var validFlag = "VALID"
      var ErrorIds = ""
      var ErroeMsgs = ""
      var NEW_ACCT_FLAG = if (row.H_LastCycleID == null || row.H_LastCycleID.isEmpty) true else false
      //var NEW_ACCT_FLAG=  if(row.NEW_ACCT_FLAG. "Y"  true else false
      // For new acconts check manadory fields
      if (NEW_ACCT_FLAG) //|| H_LastCycleID==null || H_LastCycleID.isEmpty)
      {
        //OriginalAmount
        if (row.OriginalAmount == None || row.OriginalAmount.get == 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_ORGA_01 |"
          ErroeMsgs = ErroeMsgs + "Error : OriginalAmount is mandatory for all new accounts and it shoud not be zero|"
        }
        //SalaryAssignmentFlag
        if (row.SalaryAssignmentFlag == null || row.SalaryAssignmentFlag.isEmpty()) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_SALF_01 |"
          ErroeMsgs = ErroeMsgs + "Error : SalaryAssignmentFlag is mandatory for all new accounts |"
        }
        //PaymentFrequency
        if (row.PaymentFrequency == null || row.PaymentFrequency.isEmpty()) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PFRQ_01 |"
          ErroeMsgs = ErroeMsgs + "Error : PaymentFrequency is mandatory for all new accounts |"
        }
        //SecurityType
        if (row.SecurityType == null || row.SecurityType.isEmpty()) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_STYP_01 |"
          ErroeMsgs = ErroeMsgs + "Error : SecurityType is mandatory for all new accounts |"
        }
        /* : TO Check , not there in actual rejection file
                                                                  //LastAmountPaid This element must be numeric. For new CI’s it must be zero.
                                                                  if( LastAmountPaid != None && LastAmountPaid.get != 0 )
                                                                  {
                                                                                                 validFlag = "ERROR"
                                                                                                 ErrorIds = ErrorIds + "ERR_APYD_01 |"
                                                                                                 ErroeMsgs = ErroeMsgs + "Error : LastAmountPaid must be zero for all new accounts |"
                                                                  }
                                           * */
        //Tenure is mandatory for the new Credit Instruments, if the provided Product Type is: In the Personal Finance or Product Type = MIS, or Product Type = PE
        //PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)  Product Type = MIS, or Product Type = PE Else it is Optional
        if (PFProductGroup.contains(row.ProductType) || row.ProductType.equalsIgnoreCase("MIS") || row.ProductType.equalsIgnoreCase("PE")) {
          //Tenure is mandatory for above conditions
          if (row.Tenure == None || row.Tenure.get == 0) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_TENR_01 |"
            ErroeMsgs = ErroeMsgs + s"Error : Tenure is mandatory for all new accounts with  $row.ProductType  producttype |"
          }
          //Tenure is mandatory for above conditions
          if (row.ExpiryDate == None || row.ExpiryDate == null) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EXPDT_01 |"
            ErroeMsgs = ErroeMsgs + s"Error : ExpiryDate is mandatory for all new accounts with  $ProductType  producttype |"
          }
        }
        //Product Expiry Date must not be provided for the Credit Instruments where Product Type is:  In the Phone products group; or In the Credit Card products group
        if (CCProductGroup.contains(ProductType) || PHProductGroup.contains(ProductType)) {
          if (row.ExpiryDate != null) {
            validFlag = "ERROR"
            ErrorIds = ErrorIds + "ERR_EXPDT_02 |"
            ErroeMsgs = ErroeMsgs + s"Error : ExpiryDate must not be provided for the Credit Instruments where Product Type is :  $ProductType |"
          }
        }
        //IssueDate
        if (row.IssueDate == None || row.IssueDate == null) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_ISDT_01 |"
          ErroeMsgs = ErroeMsgs + "Error : IssueDate is mandatory for all new accounts |"
        }
      } // End if new accounts only
      // PastDuebalance If the Payment Status (AACS) is N, Q, 0, F, or C, value must be 0 or less, otherwise it should be more than 0 (which includes W)
      val payStatList = List("N", "Q", "0", "F", "C")
      if (payStatList.contains(PaymentStatus)) {
        if (row.PastDueBalance != None && row.PastDueBalance.get > 0) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PDBAL_01 |"
          ErroeMsgs = ErroeMsgs + s"Error : PastDueBalance must  be 0 or less for PaymentStatus:   $PaymentStatus |"
        }
      } else if (row.PastDueBalance != None && row.PastDueBalance.get < 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PDBAL_02 |"
        ErroeMsgs = ErroeMsgs + s"Error : PastDueBalance should be more than 0  for PaymentStatus:   $PaymentStatus |"
      }
      //NextPaymentDate If account is defaulted or closed then date should be blank
      if ((ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W")) && row.NextPaymentDate != null) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_NPDT_01 |"
        ErroeMsgs = ErroeMsgs + "Error :  If account is defaulted or closed then NextPaymentDate should be blank|"
      }
      /*
                                                 //NumberOfApplicants Integer 2 >= 1
                                                  if(NumberOfApplicants == None || NumberOfApplicants.get <= 0)
                                                 {
                                                   validFlag = "ERROR"
                                                                 ErrorIds = ErrorIds + "ERR_NAPL_01 |"
                                                                 ErroeMsgs = ErroeMsgs + "Error : NumberOfApplicants should be more than or equal to one for all products |"
                                                 }
                         */
      //OutstandingBalance must be zero if the Credit Instrument Product Status is Closed.
      if (ProductStatus.equalsIgnoreCase("C") && OutStandingBalance.get != 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_OSBAL_01 |"
        ErroeMsgs = ErroeMsgs + "Error :  OutstandingBalance must be zero for closed product status C|"
      }
      //B2B0309 00309 Outstanding balance too low for Credit Instrument to be considered default Reference MasterLookupDoc 3.41             System Control file          (SYSCONM0)
      if (H_ProductStatus != null && !H_ProductStatus.isEmpty()) {
        if (ProductStatus.equalsIgnoreCase("W") && !(H_ProductStatus.equalsIgnoreCase("W")) && row.OutStandingBalance.get < 500) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_OSBAL_01      |"
          ErroeMsgs = ErroeMsgs + s"Error :  Outstanding balance $OutStandingBalance.get is too low for Credit Instrument to be considered default|"
        }
      }
      //ProductStatus If Code = A or S, the latest Cycle Record Status for the CI must NOT be a C or W
      if (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S")) {
        if (PaymentStatus.equalsIgnoreCase("C") || PaymentStatus.equalsIgnoreCase("W")) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PRDST_01 |"
          ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
        }
      }
      //If Code = C, the latest Cycle Record Status for the CI must be C
      if (ProductStatus.equalsIgnoreCase("C") && !(PaymentStatus.equalsIgnoreCase("C"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_02 |"
        ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
      }
      //If Code = W, the latest Cycle Record Status for the CI must be W
      if (ProductStatus.equalsIgnoreCase("W") && !(PaymentStatus.equalsIgnoreCase("W"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_03 |"
        ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
      }
      //If Code = L then the Product Type must be in Product group PRDGRPPCR.
      if (ProductStatus.equalsIgnoreCase("L") && !(CCProductGroup.contains(ProductType))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_04 |"
        ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the Product Type must be in Product group PRDGRPPCR / CCR |"
      }
      //A Credit Instrument Product Sates may be C (Closed) only if the outstanding balance is zero.
      if (ProductStatus.equalsIgnoreCase("C") && OutStandingBalance.get != 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_05 |"
        ErroeMsgs = ErroeMsgs + "Error : A Credit Instrument Product Status can be C (Closed) only if the outstanding balance is zero. |"
      }
      //Product Status ‘X’ (Default Only) cannot be supplied with this service.
      if (ProductStatus.equalsIgnoreCase("X")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PRDST_05 |"
        ErroeMsgs = ErroeMsgs + "Error : Product Status ‘X’ (Default Only) cannot be supplied with this service |"
      }
      //######## PaymentStatus Rules
      //If a cycle is received with status ‘W’, but a later cycle exists with an open status, an error condition occurs
      if (H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("W")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_01 |"
        ErroeMsgs = ErroeMsgs + "Error : The CI must not be included in RegularFile as previous status was W (Default) |"
      }

      //Added 20240220 Default will be acceptted only if previous value is 6
      if (H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && PaymentStatus.equalsIgnoreCase("W") && !(H_PaymentStatus.equalsIgnoreCase("6"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "QCL_ERR_PAYST_01 |"
        ErroeMsgs = ErroeMsgs + s"Error : Writtenoff status W can't be uploaded without previous payment status 6(DPD 150 <> 180) [History PaymentStatus is $H_PaymentStatus]|"

      }

      //Payment Status can be F if the Product Type is:1. in Phone products group; i.e. on Table PRDGRPPH or Credit Card products group; i.e. on Table PRDGRPPCR

      if (!(CCProductGroup.contains(ProductType) || PHProductGroup.contains(ProductType)) && PaymentStatus.equalsIgnoreCase("F")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_02 |"
        ErroeMsgs = ErroeMsgs + s"Error : Payment Status can't be F for this product type: $ProductType|"
      }
      //For new and existing CIs, new or existing cycles - If Credit Instrument Product Status = A or L or S then the latest cycle Payment Status cannot be C or W
      if (ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("L") || ProductStatus.equalsIgnoreCase("S")) {
        if (PaymentStatus.equalsIgnoreCase("C") || PaymentStatus.equalsIgnoreCase("W")) {
          validFlag = "ERROR"
          ErrorIds = ErrorIds + "ERR_PAYST_03 |"
          ErroeMsgs = ErroeMsgs + "Error : Product Status = A or L or S then the latest cycle Payment Status cannot be C or W |"
        }
      }
      //If the latest cycle status = C loading of new cycle(s) will not be allowed, error message will be returned. Latest cycle status C cannot be changed to any other value. (AD 9978)
      if (H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("C")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_04 |"
        ErroeMsgs = ErroeMsgs + s"Error :  Payment Status cannot be changed to this value $PaymentStatus as previous status was C (Closed) |"
      }
      //Payment Status can be R only for the credit instruments in the product group Risk of Non-payment PRDGRPSU
      if (!(RNPProductGroup.contains(ProductType)) && PaymentStatus.equalsIgnoreCase("R")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_05 |"
        ErroeMsgs = ErroeMsgs + "Error : Payment Status can be R only for the credit instruments in the product group Risk of Non-payment PRDGRPSU|"
      }
      //Payment status R is valid only for the CI where product status is S
      if (PaymentStatus.equalsIgnoreCase("R") && !(ProductStatus.equalsIgnoreCase("S"))) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_06 |"
        ErroeMsgs = ErroeMsgs + "Error : Payment status R is valid only for the CI where product status is S|"
      }
      //If the payment status R provided, value in the Outstanding Balance (ACUB) must be < 500.00
      if (PaymentStatus.equalsIgnoreCase("R") && (OutStandingBalance == None || OutStandingBalance.get >= 500)) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_07 |"
        ErroeMsgs = ErroeMsgs + "Error : For Payment status R Outstanding Balance  must be < 500.00|"
      }
      //Payment status R may be loaded only of the previous most recent cycle payment status (in the database) is 6
      if (PaymentStatus.equalsIgnoreCase("R") && H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("6")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_PAYST_08 |"
        ErroeMsgs = ErroeMsgs + "Error : Payment status R may be loaded only if the previous most recent cycle payment status is 6 |"
      }
      // var VLSAccountNumber = if(AccountNumber.startsWith("6666")) "66".concat(AccountNumber) else AccountNumber
      new RejectRecords_V_01(
        row.AccountNumber,
        ProductType,
        validFlag,
        ErrorIds,
        ErroeMsgs)
    }
  //End of function getRejectionRecords_V6
}