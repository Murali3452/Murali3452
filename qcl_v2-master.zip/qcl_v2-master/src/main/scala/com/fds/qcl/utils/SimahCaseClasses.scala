package com.fds.qcl.utils

import org.apache.spark.sql.types._

object SimahCaseClasses {
      val responseFileSchema = StructType(Seq(StructField("ACTION", StringType, nullable = true),
                  StructField("HEADER",
                              StructType(Seq(
                                          StructField("ERR_ITEMS", StringType, nullable = true),
                                          StructField("MEMBER_ID", StringType, nullable = true),
                                          StructField("RUN_NO", StringType, nullable = true),
                                          StructField("TOT_ITEMS", StringType, nullable = true),
                                          StructField("USER_ID", StringType, nullable = true))), nullable = true),
                  StructField("MESSAGE",
                              StructType(Seq(
                                          StructField("ITEM", ArrayType(StructType(
                                                      List(
                                                                  StructField("ERROR", StructType(Seq(
                                                                              StructField("DATA", StringType, nullable = true),
                                                                              StructField("FIELD", StringType, nullable = true),
                                                                              StructField("RSP_MSG", StringType, nullable = true))), nullable = true),
                                                                  StructField("NO_ERRORS", StringType),
                                                                  StructField("PPRD", StringType),
                                                                  StructField("APRD", StringType),
                                                                  StructField("PREF", StringType),
                                                                  StructField("AREF", StringType),
                                                                  StructField("_seq", StringType))))))), nullable = true),
                  StructField("SERVICE", StringType, nullable = true),
                  StructField("STATUS", StringType, nullable = true)))
                  
case class RegularResponseSummaryCaseClass
(
      ACTION: String,
      ERROR_ITEMS: Int,
      MEMBER_ID: String,
      RUN_NO: String,
      TOTAL_ITEMS: Int,
      USER_ID:String,
      SERVICE: String,
      STATUS:String
)

case class DefaultRequestXMLMapClass
(
      AccountNumber: String,
      ProductType: String,
      DefaultStatusDate: java.sql.Date,
      OutStandingBalance: Option[Double],
      DefaultStatus: String
)
case class DefaultRequestXMLMapClass_V6
(
      AccountNumber: String,
      ProductType: String,
      DefaultStatusDate: java.sql.Date,
      OutStandingBalance: Option[Double],
      DefaultStatus: String
)
case class DefaultInputHistMapCaseClass
  (
      H_AccountNumber:  String ,
      H_ProductType:  String ,
      H_ProductStatus:  String ,
      H_PaymentStatus:  String ,
      H_DefaultOutStandingAmount:  Option[Double] ,
      H_DefaultOriginalAmount:  Option[Double] ,
      H_DefaultStatus:  String ,
      H_DefaultStatusDate:  java.sql.Date ,
      H_DefaultChangeDate:  java.sql.Date
 )
case class DefaultRequestPlusHistCaseClass
  (
      AccountNumber: String,
      ProductType: String,
      DefaultStatusDate: java.sql.Date,
      OutStandingBalance: Option[Double],
      DefaultStatus: String,
      H_AccountNumber:  String ,
      H_ProductType:  String ,
      H_ProductStatus:  String ,
      H_PaymentStatus:  String ,
      H_DefaultOutStandingAmount:  Option[Double] ,
      H_DefaultOriginalAmount:  Option[Double] ,
      H_DefaultStatus:  String ,
      H_DefaultStatusDate:  java.sql.Date ,
      H_DefaultChangeDate:  java.sql.Date
)
case class InputFileCaseClass
(
            ACCOUNT_NUMBER  :  String ,
            //ISSUE_DATE  :  String ,
            ISSUE_DATE  :  java.sql.Date ,
            PRODUCT_TYPE  :  String ,
            ORIGINAL_AMOUNT:  Option[Double] ,
            SALARY_ASSIGNMENT_FLAG  :  String ,
            //EXPIRY_DATE  :  String ,
            EXPIRY_DATE  :  java.sql.Date ,
            PRODUCT_STATUS  :  String ,
            INSTALLMENT_AMOUNT:  Option[Double] ,
            PAYMENT_FREQUENCY  :  String ,
            TENURE:  Option[Integer] ,
            SECURITY_TYPE  :  String ,
            NUMBER_OF_APPLICANTS:  Option[Integer] ,
            LAST_CYCLEID:  Option[Integer] ,
            //LAST_PAYMENT_DATE  :  String ,
            LAST_PAYMENT_DATE  :  java.sql.Date ,
            LAST_AMOUNT_PAID:  Option[Double] ,
            PAYMENT_STATUS  :  String ,
            OUTSTANDING_AMOUNT:  Option[Double] ,
            PASTDUE_BALANCE  :  Option[Double]  ,
            //AS_OF_DATE  :  String ,
            AS_OF_DATE  :  java.sql.Date ,
            //NEXT_PAYMENT_DATE  :  String ,
            NEXT_PAYMENT_DATE  :  java.sql.Date ,
            APPLICATION_TYPE  :  String ,
            ID_TYPE  :  String ,
            ID_NUMBER  :  String ,
            NEW_ACCT_FLAG  :  String ,
            NEW_CUST_FLAG  :  String
            )
case class InputXMLMapCaseClass
(
            AccountNumber:  String ,
            IssueDate:  java.sql.Date ,
            ProductType:  String ,
            OriginalAmount:  Option[Double] ,
            SalaryAssignmentFlag:  String ,
            ExpiryDate:  java.sql.Date ,
            ProductStatus:  String ,
            InstallmentAmount:  Option[Double] ,
            PaymentFrequency:  String ,
            Tenure:  Option[Integer] ,
            SecurityType:  String ,
            NumberOfApplicants:  Option[Integer] ,
            LastCycleID:  Option[Integer] ,
            LastPaymentDate:  java.sql.Date ,
            LastAmountPaid:  Option[Double] ,
            PaymentStatus:  String ,
            OutstandingAmount:  Option[Double] ,
            PastDueBalance:  Option[Double]  ,
            AsOfDate:  java.sql.Date ,
            NextPaymentDate:  java.sql.Date ,
            ApplicationType:  String ,
            IDType:  String ,
            IDNumber:  String ,
            NEW_ACCT_FLAG:  Boolean
            )
case class InputHistMapCaseClass
(
            H_AccountNumber:  String ,
            H_IssueDate:  java.sql.Date ,
            H_ProductType:  String ,
            H_OriginalAmount:  Option[Double] ,
            H_SalaryAssignmentFlag:  String ,
            H_ExpiryDate:  java.sql.Date ,
            H_ProductStatus:  String ,
            H_InstallmentAmount:  Option[Double] ,
            H_PaymentFrequency:  String ,
            H_Tenure:  Option[Integer] ,
            H_SecurityType:  String ,
            H_NumberOfApplicants:  Option[Integer] ,
            H_LastCycleID:  Option[Integer] ,
            H_LastPaymentDate:  java.sql.Date ,
            H_LastAmountPaid:  Option[Double] ,
            H_PaymentStatus:  String ,
            H_OutstandingAmount:  Option[Double] ,
            H_PastDueBalance:  Option[Double]  ,
            H_AsOfDate:  java.sql.Date ,
            H_NextPaymentDate:  java.sql.Date ,
            H_ApplicationType:  String ,
            H_IDType:  String ,
            H_IDNumber:  String ,
            HIST_RUN_NO:  String ,
            H_NEW_ACCT_FLAG:  String
            )
case class InputHistMapCaseClass2
(
            H_AccountNumber:  String ,
            H_IssueDate:  java.sql.Date ,
            H_ProductType:  String ,
            H_OriginalAmount:  Option[Double] ,
            H_SalaryAssignmentFlag:  String ,
            H_ExpiryDate:  java.sql.Date ,
            H_ProductStatus:  String ,
            H_InstallmentAmount:  Option[Double] ,
            H_PaymentFrequency:  String ,
            H_Tenure:  Option[Integer] ,
            H_SecurityType:  String ,
            //H_NumberOfApplicants:  Option[Integer] ,
            H_LastCycleID:  Option[Integer] ,
            H_LastPaymentDate:  java.sql.Date ,
            H_LastAmountPaid:  Option[Double] ,
            H_PaymentStatus:  String ,
            H_OutstandingAmount:  Option[Double] ,
            H_PastDueBalance:  Option[Double]  ,
            H_AsOfDate:  java.sql.Date ,
            H_NextPaymentDate:  java.sql.Date ,
            // H_ApplicationType:  String ,
            H_IDType:  String ,
            H_IDNumber:  String ,
            HIST_RUN_NO:  String ,
            H_NEW_ACCT_FLAG:  String
            )
case class InputHistCaseClass
(
            AccountNumber:  String ,
            IssueDate:  java.sql.Date ,
            ProductType:  String ,
            OriginalAmount:  Option[Double] ,
            SalaryAssignmentFlag:  String ,
            ExpiryDate:  java.sql.Date ,
            ProductStatus:  String ,
            InstallmentAmount:  Option[Double] ,
            PaymentFrequency:  String ,
            Tenure:  Option[Integer] ,
            SecurityType:  String ,
            //NumberOfApplicants:  Option[Integer] ,
            LastCycleID:  Option[Integer] ,
            LastPaymentDate:  java.sql.Date ,
            LastAmountPaid:  Option[Double] ,
            PaymentStatus:  String ,
            OutStandingBalance:  Option[Double] ,
            PastDueBalance:  Option[Double]  ,
            AsOfDate:  java.sql.Date ,
            NextPaymentDate:  java.sql.Date ,
            //ApplicationType:  String ,
            ApplicantType:  String ,
            IDType:  String ,
            IDNumber:  String ,
            NEW_ACCT_FLAG:  String,
            H_IssueDate:  java.sql.Date ,
            H_ProductType:  String ,
            H_OriginalAmount:  Option[Double] ,
            H_SalaryAssignmentFlag:  String ,
            H_ExpiryDate:  java.sql.Date ,
            H_ProductStatus:  String ,
            H_InstallmentAmount:  Option[Double] ,
            H_PaymentFrequency:  String ,
            H_Tenure:  Option[Integer] ,
            H_SecurityType:  String ,
            //H_NumberOfApplicants:  Option[Integer] ,
            H_LastCycleID:  Option[Integer] ,
            H_LastPaymentDate:  java.sql.Date ,
            H_LastAmountPaid:  Option[Double] ,
            H_PaymentStatus:  String ,
            H_OutstandingAmount:  Option[Double] ,
            H_PastDueBalance:  Option[Double]  ,
            H_AsOfDate:  java.sql.Date ,
            H_NextPaymentDate:  java.sql.Date ,
            H_ApplicationType:  String ,
            H_IDType:  String ,
            H_IDNumber:  String ,
            HIST_RUN_NO:  String ,
            H_NEW_ACCT_FLAG:  String
            )
case class RequestFileStats(  
            KEY1: String,
            KEY2: String,
            FILENAME: String,
            RUNDATE: java.sql.Date,
            RUNTIMESTAMP: java.sql.Timestamp,
            RUNNUMBER: Int,
            FILETYPE: String,
            FILEPRODUCT: String,
            COUNT_INFILE_REC: Int,
            COUNT_OUTFILE_REC: Int,
            COUNT_REJ_SDVL: Int,
            COUNT_REJ_SIMAH: Int,
            COUNT_REJ_TOTAL: Int,
            COUNT_ACCEPTED: Int,
            RESP_STS_SDVL: String,
            RESP_STS_SIMAH: String
            )
case class RequestFileStats2(  
            KEY1: String,
            KEY2: String,
            FILENAME: String,
            RUNDATE: java.sql.Date,
            RUNTIMESTAMP: java.sql.Timestamp,
            RUNNUMBER: Int,
            FILETYPE: String,
            FILEPRODUCT: String,
            COUNT_INFILE_REC: Int,
            COUNT_OUTFILE_REC: Int,
            COUNT_REJ_SDVL: Int,
            COUNT_REJ_SIMAH: Int,
            COUNT_REJ_TOTAL: Int,
            COUNT_REJ_EXTRA: Int,
            COUNT_REJ_MISSING: Int,
            COUNT_ACCTS_NEW: Int,
            COUNT_DQ_REC: Int,
            RESP_STS_SDVL: String,
            RESP_STS_SIMAH: String
            )                                              
case class RequestPlusHistCaseClass
(
            AccountNumber:  String ,
            IssueDate:  java.sql.Date ,
            ProductType:  String ,
            OriginalAmount:  Option[Double] ,
            SalaryAssignmentFlag:  String ,
            ExpiryDate:  java.sql.Date ,
            ProductStatus:  String ,
            InstallmentAmount:  Option[Double] ,
            PaymentFrequency:  String ,
            Tenure:  Option[Integer] ,
            SecurityType:  String ,
            //NumberOfApplicants:  Option[Integer] ,
            LastCycleID:  Option[Integer] ,
            LastPaymentDate:  java.sql.Date ,
            LastAmountPaid:  Option[Double] ,
            PaymentStatus:  String ,
            OutStandingBalance:  Option[Double] ,
            PastDueBalance:  Option[Double]  ,
            AsOfDate:  java.sql.Date ,
            NextPaymentDate:  java.sql.Date ,
            IDType:  String ,
            IDNumber:  String ,
            NEW_ACCT_FLAG:  Boolean,
            H_IssueDate:  java.sql.Date ,
            H_ProductType:  String ,
            H_OriginalAmount:  Option[Double] ,
            H_SalaryAssignmentFlag:  String ,
            H_ExpiryDate:  java.sql.Date ,
            H_ProductStatus:  String ,
            H_InstallmentAmount:  Option[Double] ,
            H_PaymentFrequency:  String ,
            H_Tenure:  Option[Integer] ,
            H_SecurityType:  String ,
            H_LastCycleID:  Option[Integer] ,
            H_LastPaymentDate:  java.sql.Date ,
            H_LastAmountPaid:  Option[Double] ,
            H_PaymentStatus:  String ,
            H_OutstandingAmount:  Option[Double] ,
            H_PastDueBalance:  Option[Double]  ,
            H_AsOfDate:  java.sql.Date ,
            H_NextPaymentDate:  java.sql.Date ,
            H_IDType:  String ,
            H_IDNumber:  String ,
            HIST_RUN_NO:  String ,
            H_NEW_ACCT_FLAG:  String
            )
case class HistBaseCaseClass
(
            AccountNumber: String,
            ProductType: String,
            SalaryAssignment: String,
            PaymentFrequency :String,
            SecurityType: String,
            IssueDate: java.sql.Date,
            ExpiryDate: java.sql.Date,
            AsOfDate: java.sql.Date,
            CloseDate: java.sql.Date,
            ProductStatus: String,
            PaymentStatus: String,
            Tenure: Option[Integer],
            InstallmentAmount: Option[Double],
            OriginalAmount: Option[Double],
            OutStandingBalance: Option[Double],
            LastCycleID: Option[Integer],
            LastAmountPaid: Option[Double],
            LastPaymentDate: java.sql.Date,
            NextPaymentDate: java.sql.Date,
            PastDueBalance: Option[Double],
            DefaultStatus: String,
            DefaultLoadDate: java.sql.Date,
            DefaultOriginalAmount: Option[Double],
            DefaultOutStandingAmount: Option[Double],
            DefaultStatusDate: java.sql.Date,
            DefaultChangeDate: java.sql.Date,
            CIUploadDate: java.sql.Date,
            CIUpdateDate: java.sql.Date,
            CurrentStatus: String,
            ReportedDate: java.sql.Date,
            DPR: Option[Integer],
            DPA: Option[Integer],
            RJC: Option[Integer]
            )
case class RegularRequestXMLMapClass
(
            AccountNumber: String,
            ProductType: String,
            SalaryAssignmentFlag: String,
            PaymentFrequency :String,
            SecurityType: String,
            IssueDate: java.sql.Date,
            ExpiryDate: java.sql.Date,
            AsOfDate: java.sql.Date,
            //CloseDate: java.sql.Date,
            ProductStatus: String,
            PaymentStatus: String,
            Tenure: Option[Integer],
            InstallmentAmount: Option[Double],
            OriginalAmount: Option[Double],
            OutStandingBalance: Option[Double],
            PastDueBalance:  Option[Double]  ,
            LastCycleID: Option[Integer],
            LastAmountPaid: Option[Double],
            LastPaymentDate: java.sql.Date,
            NextPaymentDate: java.sql.Date,
            IDType:  String ,
            IDNumber:  String
            )
case class RegularRequestXMLMapClass_V4
(
            AccountNumber: String,
            ProductType: String,
            SalaryAssignmentFlag: String,
            PaymentFrequency :String,
            SecurityType: String,
            IssueDate: java.sql.Date,
            ExpiryDate: java.sql.Date,
            AsOfDate: java.sql.Date,
            //CloseDate: java.sql.Date,
            ProductStatus: String,
            PaymentStatus: String,
            Tenure: Option[Integer],
            InstallmentAmount: Option[Double],
            OriginalAmount: Option[Double],
            OutStandingBalance: Option[Double],
            PastDueBalance:  Option[Double]  ,
            LastCycleID: Option[Integer],
            LastAmountPaid: Option[Double],
            LastPaymentDate: java.sql.Date,
            NextPaymentDate: java.sql.Date,
            ApplicantType:String,
            IDType:  String ,
            IDNumber:  String
            )
case class HistoryDQReport_V_01
(
            AccountNumber:  String ,
            ProductType:  String ,
            ValidFlag : String,
            ErrorIDs : String,
            ErrorMsgs: String
            )
case class RejectRecords_V_01
(
            AccountNumber:  String ,
            ProductType:  String ,
            ValidFlag : String,
            ErrorIDs : String,
            ErrorMsgs: String
            )
case class RegularDataOutput_V_03
(
            AccountNumber:  String ,
            IssueDate:  java.sql.Date ,
            ProductType:  String ,
            OriginalAmount:  Option[Double] ,
            SalaryAssignmentFlag:  String ,
            ExpiryDate:  java.sql.Date ,
            ProductStatus:  String ,
            InstallmentAmount:  Option[Double] ,
            PaymentFrequency:  String ,
            Tenure:  Option[Integer] ,
            SecurityType:  String ,
            NumberOfApplicants:  Option[Integer] ,
            LastCycleID:  Option[Integer] ,
            LastPaymentDate:  java.sql.Date ,
            LastAmountPaid:  Option[Double] ,
            PaymentStatus:  String ,
            OutstandingAmount:  Option[Double] ,
            PastDueBalance:  Option[Double]  ,
            AsOfDate:  java.sql.Date ,
            NextPaymentDate:  java.sql.Date ,
            ApplicationType:  String ,
            IDType:  String ,
            IDNumber:  String ,
            NEW_ACCT_FLAG:  Boolean ,
            HIST_RUN_NO:  String ,
            ValidFlag : String,
            ErrorIDs : String,
            ErrorMsgs: String
            )
case class InputFileMapCaseClass
(
            AccountNumber:  String ,
            IssueDate:  java.sql.Date ,
            ProductType:  String ,
            OriginalAmount:  Option[Double] ,
            SalaryAssignmentFlag:  String ,
            ExpiryDate:  java.sql.Date ,
            ProductStatus:  String ,
            InstallmentAmount:  Option[Double] ,
            PaymentFrequency:  String ,
            Tenure:  Option[Integer] ,
            SecurityType:  String ,
            NumberOfApplicants:  Option[Integer] ,
            LastCycleID:  Option[Integer] ,
            LastPaymentDate:  java.sql.Date ,
            LastAmountPaid:  Option[Double] ,
            PaymentStatus:  String ,
            OutstandingAmount:  Option[Double] ,
            PastDueBalance:  Option[Double]  ,
            AsOfDate:  java.sql.Date ,
            NextPaymentDate:  java.sql.Date ,
            ApplicationType:  String ,
            IDType:  String ,
            IDNumber:  String ,
            NEW_ACCT_FLAG:  String ,
            NEW_CUST_FLAG:  String
            )
val requestXMLFileREGSchema = StructType(Seq(
            StructField("ABPAY",   StringType, nullable = true),
            StructField("ACON",    StringType, nullable = true),
            StructField("ACYC",   
                        StructType(Seq (
                                    StructField("AACS",    StringType, nullable = true),
                                    StructField("ACUB",    StringType, nullable = true),
                                    StructField("ACYCID",  StringType, nullable = true),
                                    StructField("ALSTAM",  StringType, nullable = true),
                                    StructField("AODB",    StringType, nullable = true),
                                    StructField("AASOF",   StructType(Seq  (
                                                StructField("AASOFD", StringType, nullable = true),
                                                StructField("AASOFM", StringType, nullable = true),
                                                StructField("AASOFY", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("ALSPD",   StructType(Seq ( 
                                                StructField("ALSPDD", StringType, nullable = true),
                                                StructField("ALSPDM", StringType, nullable = true),
                                                StructField("ALSPDY", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("ANXPD",  StructType(Seq (
                                                StructField("ANXPDD", StringType, nullable = true),
                                                StructField("ANXPDM", StringType, nullable = true),
                                                StructField("ANXPDY", StringType, nullable = true),
                                                )), nullable = true)
                                    )), nullable = true),
            StructField("ADAMT",  StringType, nullable = true),
            StructField("ADWNP",  StringType, nullable = true),
            StructField("AEXP",   StructType(Seq ( 
                        StructField("AEXPD", StringType, nullable = true),
                        StructField("AEXPM", StringType, nullable = true),
                        StructField("AEXPY", StringType, nullable = true),
                        )), nullable = true),
            StructField("AFRQ",   StringType, nullable = true),
            StructField("AINST",  StringType, nullable = true),
            StructField("ALMT",   StringType, nullable = true),
            StructField("AMAX",   StringType, nullable = true),
            StructField("AOPN",   StructType(Seq ( 
                        StructField("AOPND", StringType, nullable = true),
                        StructField("AOPNM", StringType, nullable = true),
                        StructField("AOPNY", StringType, nullable = true),
                        )), nullable = true),
            StructField("APRD",   StringType, nullable = true),
            StructField("APST",   StringType, nullable = true),
            StructField("AREF",   StringType, nullable = true),
            StructField("ASAL",   StringType, nullable = true),
            StructField("ASEC",   StringType, nullable = true),
            StructField("ASP",    StringType, nullable = true),
            StructField("ATNR",   StringType, nullable = true),
            StructField("AVINST", StringType, nullable = true),
            StructField("FRSTINSDT",StructType(Seq ( 
                        StructField("FRSTINSDD", StringType, nullable = true),
                        StructField("FRSTINSMM", StringType, nullable = true),
                        StructField("FRSTINSYY", StringType, nullable = true),
                        )), nullable = true),
            StructField("MULTINSAMT", ArrayType(StructType(
                        List(
                                    StructField("STRTINSDT", StructType(Seq(
                                                StructField("STRINSDD", StringType, nullable = true),
                                                StructField("STRINSMM", StringType, nullable = true),
                                                StructField("STRINSYY", StringType, nullable = true))), nullable = true),
                                    StructField("INSAMT", StringType, nullable = true),
                                    )) ), nullable = true),
            StructField("CONSUMER",   
                        StructType(Seq (
                                    StructField("CAPL",    StringType, nullable = true),
                                    StructField("CEML",    StringType, nullable = true),
                                    StructField("CGND",  StringType, nullable = true),
                                    StructField("CMAR",  StringType, nullable = true),
                                    StructField("CINDPAYS",    StringType, nullable = true),
                                    StructField("CNAT",  StringType, nullable = true),
                                    StructField("CDOB",   StructType(Seq  (
                                                StructField("CDBD", StringType, nullable = true),
                                                StructField("CDBM", StringType, nullable = true),
                                                StructField("CDBY", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("CID",   StructType(Seq ( 
                                                StructField("CID1", StringType, nullable = true),
                                                StructField("CID2", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("CADR",StructType(Seq ( 
                                                StructField("CAD1A",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CAD1E", StringType, nullable = true),
                                                StructField("CAD2A",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CAD2E", StringType, nullable = true),
                                                StructField("CAD6", StringType, nullable = true),
                                                StructField("CAD7", StringType, nullable = true),
                                                StructField("CAD9", StringType, nullable = true),
                                                StructField("CADT", StringType, nullable = true),
                                                )), nullable = true),           
                                    StructField("CNAM",StructType(Seq ( 
                                                StructField("CNM1A",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CNM1E", StringType, nullable = true),
                                                StructField("CNMFA",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CNMFE", StringType, nullable = true),
                                                StructField("CNMUA",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CNMUE", StringType, nullable = true),
                                                )), nullable = true),                                                                              
                                    StructField("EMPLOYER",StructType(Seq ( 
                                                StructField("EADR",StructType(Seq ( 
                                                            StructField("EAD6", StringType, nullable = true),
                                                            StructField("EAD7", StringType, nullable = true),
                                                            StructField("EAD9", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("EBUS", StringType, nullable = true),
                                                StructField("EDOE",StructType(Seq ( 
                                                            StructField("EDED", StringType, nullable = true),
                                                            StructField("EDEM", StringType, nullable = true),
                                                            StructField("EDEY", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("EECO", StringType, nullable = true),
                                                StructField("ELEN", StringType, nullable = true),
                                                StructField("ENMA",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("ENME", StringType, nullable = true),
                                                StructField("EOCA",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("EOCE", StringType, nullable = true),
                                                StructField("ESLF", StringType, nullable = true),
                                                StructField("ETMS", StringType, nullable = true),
                                                StructField("ETYP", StringType, nullable = true),
                                                )), nullable = true),                                                                              
                                    StructField("CCNT", ArrayType(StructType(
                                                List(
                                                            StructField("CCN1", StringType, nullable = true),
                                                            StructField("CCN2", StringType, nullable = true),
                                                            StructField("CCN4", StringType, nullable = true),
                                                            )) ), nullable = true))))           
            ))
val requestFileSchema = StructType(Seq(
            StructField("ABPAY",   StringType, nullable = true),
            StructField("ACON",    StringType, nullable = true),
            StructField("ACYC",   
                        StructType(Seq (
                                    StructField("AACS",    StringType, nullable = true),
                                    StructField("ACUB",    StringType, nullable = true),
                                    StructField("ACYCID",  StringType, nullable = true),
                                    StructField("ALSTAM",  StringType, nullable = true),
                                    StructField("AODB",    StringType, nullable = true),
                                    StructField("AASOF",   StructType(Seq  (
                                                StructField("AASOFD", StringType, nullable = true),
                                                StructField("AASOFM", StringType, nullable = true),
                                                StructField("AASOFY", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("ALSPD",   StructType(Seq ( 
                                                StructField("ALSPDD", StringType, nullable = true),
                                                StructField("ALSPDM", StringType, nullable = true),
                                                StructField("ALSPDY", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("ANXPD",  StructType(Seq (
                                                StructField("ANXPDD", StringType, nullable = true),
                                                StructField("ANXPDM", StringType, nullable = true),
                                                StructField("ANXPDY", StringType, nullable = true),
                                                )), nullable = true)
                                    )), nullable = true),
            StructField("ADAMT",  StringType, nullable = true),
            StructField("ADWNP",  StringType, nullable = true),
            StructField("AEXP",   StructType(Seq ( 
                        StructField("AEXPD", StringType, nullable = true),
                        StructField("AEXPM", StringType, nullable = true),
                        StructField("AEXPY", StringType, nullable = true),
                        )), nullable = true),
            StructField("AFRQ",   StringType, nullable = true),
            StructField("AINST",  StringType, nullable = true),
            StructField("ALMT",   StringType, nullable = true),
            StructField("AMAX",   StringType, nullable = true),
            StructField("AOPN",   StructType(Seq ( 
                        StructField("AOPND", StringType, nullable = true),
                        StructField("AOPNM", StringType, nullable = true),
                        StructField("AOPNY", StringType, nullable = true),
                        )), nullable = true),
            StructField("APRD",   StringType, nullable = true),
            StructField("APST",   StringType, nullable = true),
            StructField("AREF",   StringType, nullable = true),
            StructField("ASAL",   StringType, nullable = true),
            StructField("ASEC",   StringType, nullable = true),
            StructField("ASP",    StringType, nullable = true),
            StructField("ATNR",   StringType, nullable = true),
            StructField("AVINST", StringType, nullable = true),
            StructField("FRSTINSDT",StructType(Seq ( 
                        StructField("FRSTINSDD", StringType, nullable = true),
                        StructField("FRSTINSMM", StringType, nullable = true),
                        StructField("FRSTINSYY", StringType, nullable = true),
                        )), nullable = true),
            StructField("MULTINSAMT", ArrayType(StructType(
                        List(
                                    StructField("STRTINSDT", StructType(Seq(
                                                StructField("STRINSDD", StringType, nullable = true),
                                                StructField("STRINSMM", StringType, nullable = true),
                                                StructField("STRINSYY", StringType, nullable = true))), nullable = true),
                                    StructField("INSAMT", StringType, nullable = true),
                                    )) ), nullable = true)
            ))

val requestXMLFileREGSchema2 = StructType(Seq
            (
                        StructField("AREF",   StringType, nullable = true),
                        StructField("AOPN",   StructType(Seq ( 
                                    StructField("AOPND", StringType, nullable = true),
                                    StructField("AOPNM", StringType, nullable = true),
                                    StructField("AOPNY", StringType, nullable = true),
                                    )), nullable = true),
                        StructField("APRD",   StringType, nullable = true),
                        StructField("ALMT",   StringType, nullable = true),
                        StructField("ASAL",   StringType, nullable = true),
                        StructField("AEXP",   StructType(Seq ( 
                                    StructField("AEXPD", StringType, nullable = true),
                                    StructField("AEXPM", StringType, nullable = true),
                                    StructField("AEXPY", StringType, nullable = true),
                                    )), nullable = true),
                        StructField("APST",   StringType, nullable = true),
                        StructField("AINST",  StringType, nullable = true),
                        StructField("AVINST", StringType, nullable = true),
                        StructField("AFRQ",   StringType, nullable = true),
                        StructField("ATNR",   StringType, nullable = true),
                        StructField("ASEC",   StringType, nullable = true),
                        StructField("ADWNP",  StringType, nullable = true),                                                                                                                   
                        StructField("ABPAY",   StringType, nullable = true),
                        StructField("ADAMT",  StringType, nullable = true),
                        StructField("AMAX",   StringType, nullable = true),
                        StructField("ASP",    StringType, nullable = true),
                        StructField("MULTINSAMT", ArrayType(
                                    StructType(
                                                List(
                                                            StructField("STRTINSDT", StructType(Seq(
                                                                        StructField("STRINSDD", StringType, nullable = true),
                                                                        StructField("STRINSMM", StringType, nullable = true),
                                                                        StructField("STRINSYY", StringType, nullable = true))
                                                                        ), nullable = true),
                                                            StructField("INSAMT", StringType, nullable = true),
                                                            )) ), nullable = true),
                        StructField("FRSTINSDT",StructType(Seq (
                                    StructField("FRSTINSDD", StringType, nullable = true),
                                    StructField("FRSTINSMM", StringType, nullable = true),
                                    StructField("FRSTINSYY", StringType, nullable = true),
                                    )), nullable = true),
                        StructField("ACON",  StringType, nullable = true),
                        StructField("ACYC",  StructType(Seq (
                                    StructField("ACYCID",  StringType, nullable = true),
                                    StructField("ALSPD",   StructType(Seq ( 
                                                StructField("ALSPDD", StringType, nullable = true),
                                                StructField("ALSPDM", StringType, nullable = true),
                                                StructField("ALSPDY", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("ALSTAM",  StringType, nullable = true),
                                    StructField("AACS",    StringType, nullable = true),
                                    StructField("ACUB",    StringType, nullable = true),
                                    StructField("AODB",    StringType, nullable = true),
                                    StructField("AASOF",   StructType(Seq  (
                                                StructField("AASOFD", StringType, nullable = true),
                                                StructField("AASOFM", StringType, nullable = true),
                                                StructField("AASOFY", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("ANXPD",  StructType(Seq (
                                                StructField("ANXPDD", StringType, nullable = true),
                                                StructField("ANXPDM", StringType, nullable = true),
                                                StructField("ANXPDY", StringType, nullable = true),
                                                )), nullable = true)
                                    )), nullable = true),
                        StructField("CONSUMER", StructType(Seq (
                                    StructField("CAPL",    StringType, nullable = true),
                                    StructField("CEML",    StringType, nullable = true),
                                    StructField("CGND",    StringType, nullable = true),
                                    StructField("CMAR",    StringType, nullable = true),
                                    StructField("CINDPAYS",StringType, nullable = true),
                                    StructField("CNAT",    StringType, nullable = true),
                                    StructField("CDOB",    StructType(Seq  (
                                                StructField("CDBD", StringType, nullable = true),
                                                StructField("CDBM", StringType, nullable = true),
                                                StructField("CDBY", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("CID",   StructType(Seq ( 
                                                StructField("CID1", StringType, nullable = true),
                                                StructField("CID2", StringType, nullable = true),
                                                )), nullable = true),
                                    StructField("CADR",StructType(Seq ( 
                                                StructField("CAD1A",StructType(Seq (
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CAD1E", StringType, nullable = true),
                                                StructField("CAD2A",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CAD2E", StringType, nullable = true),
                                                StructField("CAD6", StringType, nullable = true),
                                                StructField("CAD7", StringType, nullable = true),
                                                StructField("CAD9", StringType, nullable = true),
                                                StructField("CADT", StringType, nullable = true),
                                                )), nullable = true),           
                                    StructField("CNAM",StructType(Seq ( 
                                                StructField("CNM1A",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CNM1E", StringType, nullable = true),
                                                StructField("CNMFA",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CNMFE", StringType, nullable = true),
                                                StructField("CNMUA",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("CNMUE", StringType, nullable = true),
                                                )), nullable = true),                                                                              
                                    StructField("EMPLOYER",StructType(Seq ( 
                                                StructField("EADR",StructType(Seq ( 
                                                            StructField("EAD6", StringType, nullable = true),
                                                            StructField("EAD7", StringType, nullable = true),
                                                            StructField("EAD9", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("EBUS", StringType, nullable = true),
                                                StructField("EDOE",StructType(Seq ( 
                                                            StructField("EDED", StringType, nullable = true),
                                                            StructField("EDEM", StringType, nullable = true),
                                                            StructField("EDEY", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("EECO", StringType, nullable = true),
                                                StructField("ELEN", StringType, nullable = true),
                                                StructField("ENMA",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("ENME", StringType, nullable = true),
                                                StructField("EOCA",StructType(Seq ( 
                                                            StructField("_VALUE", StringType, nullable = true),
                                                            StructField("_lang", StringType, nullable = true),
                                                            )), nullable = true),
                                                StructField("EOCE", StringType, nullable = true),
                                                StructField("ESLF", StringType, nullable = true),
                                                StructField("ETMS", StringType, nullable = true),
                                                StructField("ETYP", StringType, nullable = true),
                                                )), nullable = true),                                                                              
                                    StructField("CCNT", ArrayType(StructType(
                                                List(
                                                            StructField("CCN1", StringType, nullable = true),
                                                            StructField("CCN2", StringType, nullable = true),
                                                            StructField("CCN4", StringType, nullable = true),
                                                            ))
                                                ), nullable = true)
                                    )
                                    )
                                    )           
                        ))

}