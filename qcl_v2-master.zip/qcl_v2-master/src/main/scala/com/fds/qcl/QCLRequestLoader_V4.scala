package com.fds.qcl
import io.delta.tables._
import io.delta._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter ,File ,FileOutputStream,PrintWriter}
import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
//import utils.QCLHelperFunctions._
import utils.SimahRuleChecker._
import utils.QCLInputParams2._

object QCLRequestLoader_V4 
{
	def  requestProcessor(spark : SparkSession,FILE_NAME:String , RUN_DATE:java.sql.Date, params:utils.QCLInputParams2 ,log:Logger):Unit = {
			val fileName=FILE_NAME//params.INPUT_FILE_XMLREQUEST_NAME
					val currentKey1=fileName.substring(3, 16)
					val currentKey2=fileName.substring(3,6)+fileName.substring(13, 16)
					val currentRunNumber=fileName.substring(6, 13).toInt
					val fileType=fileName.substring(3,6)
					val fileProduct=fileName.substring(13, 16)
					log.info("Request Filename:"+FILE_NAME)
					log.info("currentKey1:"+currentKey1)
					log.info("currentKey2:"+currentKey2)
					log.info("currentRunNumber:"+currentRunNumber)
					val controlTablePath=params.DELTA_TABLE_PATH_BASE+params.DELTA_TABLE_NAME_CONTROL
					val tempTablePath=params.DELTA_TABLE_PATH_WORKING+currentKey1  
					val baseTablePath=params.DELTA_TABLE_PATH_BASE+params.DELTA_TABLE_NAME_BASE
					val fileNamePrepend=RUN_DATE.toString().replace("-","")+"_"+currentKey1
					val tempFolder=params.OUTPUT_FILE_XMLREQUET_PATH +"sparkTmp"
					val manulDataPath=params.INPUT_FILE_MANUALDATA_PATH
					val manualDataFileType=RUN_DATE+fileProduct+fileType
					try	{
						val selectMaxRunSql=s"""select ext.* FROM delta.`$controlTablePath` as ext inner join (select KEY2,max(RUNNUMBER) as MAXRUNNUMBER   FROM delta.`$controlTablePath` group by KEY2) as  maxrun on  ext.RUNNUMBER=maxrun.MAXRUNNUMBER and ext.key2=maxrun.key2""".stripMargin
								import spark.implicits._
								val maxRunDF=spark.sql(selectMaxRunSql).na.fill("").distinct().as[RequestFileStats2].filter('KEY2 === lit(currentKey2))
								if(!maxRunDF.isEmpty && maxRunDF.count() > 0 )
								{
									val latestKeyRecord=maxRunDF.collect()(0)
											val previousKey2=latestKeyRecord.KEY2
											val previousKey1=latestKeyRecord.KEY1
											val previousFilename=latestKeyRecord.FILENAME
											val previousRunNumber=latestKeyRecord.RUNNUMBER
											val previousRunDate=latestKeyRecord.RUNDATE
											log.info("previousKey1:"+previousKey1)
											log.info("previousFilename:"+previousFilename)
											log.info("previousRunNumber:"+previousRunNumber)
											log.info("previousRunDate:"+previousRunDate)
											val Pev_RESP_STS_SDVL=latestKeyRecord.RESP_STS_SDVL
											val Pre_RESP_STS_SIMAH= latestKeyRecord.RESP_STS_SIMAH
											if(Pev_RESP_STS_SDVL == "" || Pev_RESP_STS_SDVL == null)
												log.warn(s"Warning: SDVL Response is not loaded for previous key: $previousKey1")
												else
													log.info("SDVL Response is loaded with status:"+Pev_RESP_STS_SDVL)
													if(Pre_RESP_STS_SIMAH == "" || Pre_RESP_STS_SIMAH  == null)
														log.warn(s"SIMAH Response is not loaded for previous key: $previousKey1")
														else
															log.info("SIMAH Response is loaded with status:"+Pre_RESP_STS_SIMAH)
															//}//end of maxRunDF empty check if  block
															//System.exit(1)
															//Setting the Temporary folder
															if(Pre_RESP_STS_SIMAH == "" || Pre_RESP_STS_SIMAH  == null)
															{
																log.warn(s"Warning : Previous  simah response is not loaded for key :$previousKey1 ")
																log.info(s"Re-execute QCL RequestLoader after loading response for key :$previousKey1 ")
																log.error("Exiting the program  execution")
																log.error(".....QCLRequest Processor Execution Aborted @"+ new java.sql.Timestamp(System.currentTimeMillis()))
																System.exit(1)
															}
															else
															{
																if(fileType.equalsIgnoreCase("REG"))
																{
																	val tempFolder=params.OUTPUT_FILE_XMLREQUET_PATH +"sparkTmp"
																			val sqlString1="""select AccountNumber as H_AccountNumber,
																			|IssueDate as H_IssueDate,
																			|ProductType as H_ProductType,
																			|OriginalAmount as H_OriginalAmount,
																			|SalaryAssignment as H_SalaryAssignmentFlag,
																			|ExpiryDate as H_ExpiryDate,
																			|ProductStatus as H_ProductStatus,
																			|InstallmentAmount as H_InstallmentAmount,
																			|PaymentFrequency as H_PaymentFrequency,
																			|Tenure as H_Tenure,
																			|SecurityType as H_SecurityType,
																			|1 as H_NumberOfApplicants,
																			|LastCycleID as H_LastCycleID,
																			|LastPaymentDate as H_LastPaymentDate,
																			|LastAmountPaid as H_LastAmountPaid,
																			|PaymentStatus as H_PaymentStatus,
																			|OutStandingBalance as H_OutstandingAmount,
																			|PastDueBalance as H_PastDueBalance,
																			|AsOfDate as H_AsOfDate,
																			|NextPaymentDate as H_NextPaymentDate,
																			|null as H_ApplicationType,
																			|null as H_IDType,
																			|null as H_IDNumber,
																			|null as HIST_RUN_NO,
																			|null as H_NEW_ACCT_FLAG""".stripMargin
																			import spark.implicits._

																			val histCaseclassDF =spark.sql(s"$sqlString1  FROM delta.`$baseTablePath` as A").as[InputHistMapCaseClass2]
																					//val histCaseclassDF=testDF2.as[RequestPlusHistCaseClass]
																					//val histCaseclassDF=testDF2.as[InputHistMapCaseClass2]
																					//histCaseclassDF.printSchema()
																					//histCaseclassDF.show()
																					val requestXMLDF = spark.read.format("com.databricks.spark.xml")
																					.option("inferSchema",false)
																					.option("rowTag", params.INPUT_FILE_XMLREQUEST_ROWTAG)//.option("rowTag", "ACCOUNT")
																					.load(params.INPUT_FILE_XMLREQUEST_PATH + FILE_NAME)//.load(curXMLFilePath)
																					//requestXMLDF.printSchema()
																					log.info(requestXMLDF.show().toString())
																					val finalRequestXMLDF=addMissingColumns(requestXMLDF,requestXMLFileREGSchema2)
																				
																				
																					//@@val requestXMLCaseClassDF=getRequestXMLCaseClassDS_V1_2(requestXMLDF)//  TagggedDF.as[InputXMLMapCaseClass]

																					val requestXMLCaseClassDF=getRegularRequestXMLMapClass_V2_0(finalRequestXMLDF)
																					//    val requestXMLCaseClassDF=getRequestXMLCaseClassDS_V1_3(requestXMLDF)//  TagggedDF.as[InputXMLMapCaseClass]
																					//:: TO CHECK
																					// val curHistDS=requestXMLCaseClassDF.join(histCaseclassDF , Seq("AccountNumber") , "left").as[InputHistCaseClass]
																					//::TO DO
																					
																					
																					val curHistDS=requestXMLCaseClassDF.join(histCaseclassDF ,
																							requestXMLCaseClassDF("AccountNumber") === histCaseclassDF("H_AccountNumber") &&
																							requestXMLCaseClassDF("ProductType") === histCaseclassDF("H_ProductType")
																							, "left")
																					.withColumn("NEW_ACCT_FLAG", when('H_AccountNumber.isNotNull,lit(false)).otherwise(lit(true))).as[RequestPlusHistCaseClass]
																							// .withColumn("NewFlag", when('H_ProductType.isNull , true ).otherwise(false) )
																							curHistDS.cache()
																							//System.exit(1)
																							//Funcation call
																							val dataQualityDF= for
																							{
																								row <- requestXMLCaseClassDF
																								//getInvalidRecords
																								val rows=getRequestFileDQReport(
																										row.AccountNumber,
																										row.ProductType,
																										row.SalaryAssignmentFlag,
																										row.PaymentFrequency,
																										row.SecurityType,
																										row.IssueDate,
																										row.ExpiryDate,
																										row.AsOfDate,
																										//row.CloseDate,
																										row.ProductStatus,
																										row.PaymentStatus,
																										row.Tenure,
																										row.InstallmentAmount,
																										row.OriginalAmount,
																										row.OutStandingBalance,
																										row.PastDueBalance,
																										row.LastCycleID,
																										row.LastAmountPaid,
																										row.LastPaymentDate,
																										row.NextPaymentDate,
																										)
																							} yield rows
																							//Function call
																							val errorsDF= for
																							{
																								row <- curHistDS
																								val rows=getRejectionRecords(
																										row.AccountNumber:  String ,
																										row.IssueDate:  java.sql.Date ,
																										row.ProductType:  String ,
																										row.OriginalAmount:  Option[Double] ,
																										row.SalaryAssignmentFlag:  String ,
																										row.ExpiryDate:  java.sql.Date ,
																										row.ProductStatus:  String ,
																										row.InstallmentAmount:  Option[Double] ,
																										row.PaymentFrequency:  String ,
																										row.Tenure:  Option[Integer] ,
																										row.SecurityType:  String ,
																										//row.NumberOfApplicants:  Option[Integer] ,
																										row.LastCycleID:  Option[Integer] ,
																										row.LastPaymentDate:  java.sql.Date ,
																										row.LastAmountPaid:  Option[Double] ,
																										row.PaymentStatus:  String ,
																										row.OutStandingBalance:  Option[Double] ,
																										row.PastDueBalance:  Option[Double]  ,
																										row.AsOfDate:  java.sql.Date ,
																										row.NextPaymentDate:  java.sql.Date ,
																										row.IDType:  String ,
																										row.IDNumber:  String ,
																										// row.NEW_ACCT_FLAG:  Boolean,
																										row.H_IssueDate:  java.sql.Date ,
																										row.H_ProductType:  String ,
																										row.H_OriginalAmount:  Option[Double] ,
																										row.H_SalaryAssignmentFlag:  String ,
																										row.H_ExpiryDate:  java.sql.Date ,
																										row.H_ProductStatus:  String ,
																										row.H_InstallmentAmount:  Option[Double] ,
																										row.H_PaymentFrequency:  String ,
																										row.H_Tenure:  Option[Integer] ,
																										row.H_SecurityType:  String ,
																										row.H_LastCycleID:  Option[Integer] ,
																										row.H_LastPaymentDate:  java.sql.Date ,
																										row.H_LastAmountPaid:  Option[Double] ,
																										row.H_PaymentStatus:  String ,
																										row.H_OutstandingAmount:  Option[Double] ,
																										row.H_PastDueBalance:  Option[Double]  ,
																										row.H_AsOfDate:  java.sql.Date ,
																										row.H_NextPaymentDate:  java.sql.Date ,
																										row.H_IDType:  String ,
																										row.H_IDNumber:  String ,
																										row.HIST_RUN_NO:  String ,
																										row.H_NEW_ACCT_FLAG:  String
																										)
																							} yield rows
																							val reqWithRejDetails=requestXMLCaseClassDF.join(errorsDF,Seq("AccountNumber","ProductType"),"left" )
																							.withColumn("SDV_REJ_FLAG", when('ErrorIDs.isNull || 'ErrorIDs===null || 'ErrorIDs==="" , lit("N")).otherwise(lit("Y")))
																							.withColumn("SIMAH_REJ_FLAG",  lit("N"))
																							.withColumn("SIMAH_REJ_MSG",  lit(""))
																							.withColumnRenamed("ErrorMsgs", "SDV_REJ_MSG")
																							//log.info("Temporary Table schema")
																							//reqWithRejDetails.printSchema()
																							//reqWithRejDetails.show()
																							try
																							{
																								val tempTableSQL=s"""CREATE OR REPLACE TABLE delta.`$tempTablePath` ( AccountNumber STRING,ProductType STRING,OriginalAmount DOUBLE,SalaryAssignmentFlag STRING,ProductStatus STRING,
																										|InstallmentAmount DOUBLE,PaymentFrequency STRING,Tenure INT,SecurityType STRING,LastCycleID INT,LastAmountPaid DOUBLE,PaymentStatus STRING,OutStandingBalance
																										|DOUBLE,PastDueBalance DOUBLE,IDType STRING,IDNumber STRING,IssueDate Date,ExpiryDate Date,AsOfDate Date,LastPaymentDate Date,NextPaymentDate Date,
																										|ValidFlag STRING,ErrorIDs STRING,SDV_REJ_MSG STRING,SDV_REJ_FLAG STRING,SIMAH_REJ_FLAG STRING,SIMAH_REJ_MSG STRING)  USING DELTA""".stripMargin

																										spark.sql(tempTableSQL)

																										log.info(s"Working table :$tempTablePath" + " is created")
																										reqWithRejDetails.write.format("delta").mode("overwrite").save(tempTablePath)
																										log.info(s"Request data inserted in to working table :$tempTablePath")
																										//spark.sql(s"select *  FROM delta.`$tempTablePath` ").show()
																										val tempDF=spark.sql(s"select *  FROM delta.`$tempTablePath`")
																										//log.info("Temp delta table schema")
																										//tempDF.printSchema()
																										//tempDF.show()
																							}
																							catch{
																							case e: Exception =>
																							log.error("Error: Exception caught in working table creation block")
																							log.error(e)
																							System.exit(1)
																							}
																							val rejectRecDF=  errorsDF.filter(col("ValidFlag")=!=("VALID")).toDF().join(requestXMLCaseClassDF , Seq("AccountNumber","ProductType") , "inner")
																									// rejectRecDF.printSchema()
																									//rejectRecDF.show()
																									val sdvRespDF =rejectRecDF.select(col("AccountNumber").alias("AREF") ,col("ProductType").alias("APRD"),col("ErrorMsgs").alias("RSP_MSG") )
																									//log.info("sdvRespDF schema")
																									//sdvRespDF.printSchema()
																									//sdvRespDF.show()
																									val dqRecordsDF=dataQualityDF.filter(col("ValidFlag")=!=("VALID")).join(requestXMLCaseClassDF , Seq("AccountNumber","ProductType") , "inner")
																									// dqRecordsDF.printSchema()
																									// dqRecordsDF.show()
																									val validRequestRecordsDF=requestXMLDF.join(errorsDF.select('AccountNumber.as("AREF")).filter(col("ValidFlag")===("VALID")).toDF() , Seq("AREF") )
																									val NewAcctsDF=curHistDS.
																									select('AccountNumber,'IssueDate,'ProductType,'OriginalAmount,'SalaryAssignmentFlag,
																											'ExpiryDate,'ProductStatus,'InstallmentAmount,'PaymentFrequency,'Tenure,'SecurityType,
																											'LastCycleID,'LastPaymentDate,'LastAmountPaid,'PaymentStatus,'OutstandingBalance,
																											'PastDueBalance,'AsOfDate,'NextPaymentDate,'IDType,'IDNumber,'NEW_ACCT_FLAG).filter('H_AccountNumber.isNull)

																									log.info("Started gathering run stats ")
																									val COUNT_INFILE_REC=requestXMLDF.count().toInt
																									val COUNT_OUTFILE_REC=validRequestRecordsDF.count().toInt
																									val COUNT_REJ_SDVL=rejectRecDF.count().toInt
																									val COUNT_REJ_SIMAH=0
																									val COUNT_REJ_TOTAL=COUNT_REJ_SDVL // Update after loading SIMAH response COUNT_REJ_SDVL+COUNT_REJ_MISSING
																									val COUNT_REJ_EXTRA=0          // Update after loading SIMAH response
																									val COUNT_REJ_MISSING=0       // Update after loading SIMAH response
																									val COUNT_ACCTS_NEW=NewAcctsDF.count().toInt
																									val COUNT_DQ_REC=dqRecordsDF.count().toInt
																									val RESP_STS_SDVL= { if(COUNT_REJ_SDVL>0) "ERROR" else "OK"}
																							val RESP_STS_SIMAH="" // Update after loading SIMAH response COUNT_REJ_SIMAH+COUNT_REJ_SDVL
																									log.info("Completed gathering run stats") 
																									//Block to prepare the header
																									//Uncomment for version 1 files  val headerLines=getHeader(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME)
																									val headerLines=getHeader2(params.INPUT_FILE_XMLREQUEST_PATH + FILE_NAME)
																									val totalItems= "<TOT_ITEMS>" + COUNT_OUTFILE_REC +"</TOT_ITEMS>"
																									val endLines = Seq(totalItems , "</HEADER>" )
																									val finalHeaderString=headerLines ++ endLines

																									//End of block to header preparation
																									dqRecordsDF.cache()
																									rejectRecDF.cache()
																									val outputPath=params.OUTPUT_FILE_REPORTS_PATH
																									try
																							{
																										log.info("Started saving reqWithRejDetails file")
																										val tmpFolderName=fileNamePrepend+"_"+"ProcessedAcctsAll"
																												val newfileName=tmpFolderName+".csv"
																												reqWithRejDetails
																												.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
																												moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
																												log.info("Completed saving the file with name : " + outputPath + newfileName)
																							}
																							catch{
																							case e: Exception =>
																							log.error("Error : Exception caught while saving reqWithRejDetails ")
																							log.error(e)
																							}
																							try
																							{
																								val tmpFolderName=fileNamePrepend+"_"+"NewAcctsReport"
																										val newfileName=tmpFolderName+".csv"
																										log.info("Started saving the New account file")
																										NewAcctsDF
																										.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
																										moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
																										log.info("Completed saving the file with name : " + outputPath + newfileName)
																							}
																							catch{
																							case e: Exception =>
																							log.error("Error : Exception caught while saving NewAcctsDF ")
																							log.error(e)
																							}
																							try
																							{
																								val tmpFolderName=fileNamePrepend+"_"+"DataQualityReport"
																										val newfileName=tmpFolderName+".csv"
																										log.info("Started saving the Data Quality violations file")
																										dqRecordsDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
																										moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
																										log.info("Completed saving the file with name : " + outputPath + newfileName)
																							}
																							catch{
																							case e: Exception =>
																							log.error("Error : Exception caught while saving dqRecordsDF ")
																							log.error(e)
																							}
																							try
																							{
																								val tmpFolderName=fileNamePrepend+"_"+"RejectionReport"
																										val newfileName=tmpFolderName+".csv"
																										log.info("Started saving the Rejection Records file")
																										rejectRecDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
																										moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
																										log.info("Completed saving the file with name : " + outputPath + newfileName)
																							}
																							catch{
																							case e: Exception =>
																							log.error("Error : Exception caught while saving rejectRecDF ")
																							log.error(e)
																							}
																							//  val requestFilePropsDf =getRequestFileDetails(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME,f)
																							//     requestFilePropsDf.write.format("delta").mode("append").save(controlTablePath)
																							//  val df=spark.sql(s"select *  FROM delta.`$controlTablePath` as A")
																							log.info("Info: Count of Records in input XML File       :"+ FILE_NAME+" : "+ COUNT_INFILE_REC )
																							//log.info(" Count of Records in HistoryData File     :"+ params.INPUT_FILE_HISTDATA_NAME   +" : "+ histCaseclassDF.count())
																							//log.info(" Count of Records in Jioned DF     :curHistDS : "+ curHistDS.count())
																							log.info("Info: Count of Valid Records in input XML File       :"+ FILE_NAME+" : "+ COUNT_OUTFILE_REC)
																							log.info("Info: Count of New Accounts in input XML File  :"+ FILE_NAME+" : "+ COUNT_ACCTS_NEW)
																							log.info("Info: Count of Records in DataQuality Violations File     :"+COUNT_DQ_REC )
																							log.info("Info: Count of Records in Rejection Records  File     :"+COUNT_REJ_SDVL )
																							//************* New code for XML update
																							try
																							{
																								log.info("Started function call for generateRegularCuratedXMLFile")
																								//log.info("Info: Start Time  :" + new java.sql.Timestamp(System.currentTimeMillis()))
																								val rejectAccountList=rejectRecDF.select(concat( 'AccountNumber ,'ProductType )).as[String].collect.toList
																								//val rejectAccountList2= errorsDF.select(concat( 'AccountNumber ,'ProductType )).distinct().map(f => f.getString(0)).collectAsList()
																								log.info("rejectAccountListCount : "+rejectAccountList.size)
																								//rejectAccountList.foreach(log.info)
																								//def updateRequestXMLFile(inputPath: String, outputPath: String, excludeList: List[String])
																								generateRegularCuratedXMLFile(params.INPUT_FILE_XMLREQUEST_PATH + FILE_NAME,params.OUTPUT_FILE_XMLREQUET_PATH +FILE_NAME, rejectAccountList)
																								log.info("Completed function call for generateRegularCuratedXMLFile")
																								log.info("Curated XML file saved in: "+params.OUTPUT_FILE_XMLREQUET_PATH +FILE_NAME)
																								//log.info("Info: End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
																							}
																							catch{
																							case e: Exception =>
																							log.error("Exception caught in generateRegularCuratedXMLFile function call")
																							log.error(e)
																							}
																							//************* End of New code for XML update
																							//validRequestRecordsDF.unpersist()
																							// invalidRecDF.unpersist()
																							rejectRecDF.unpersist()
																							try
																							{
																								log.info("Started appending control table with current run stats")
																								val currentTime=new java.sql.Timestamp(System.currentTimeMillis())
																								val runStatsDF=Seq(RequestFileStats2 (currentKey1,currentKey2,fileName,RUN_DATE,currentTime,currentRunNumber,fileType,fileProduct,COUNT_INFILE_REC,COUNT_OUTFILE_REC,COUNT_REJ_SDVL,COUNT_REJ_SIMAH,COUNT_REJ_TOTAL,COUNT_REJ_EXTRA,COUNT_REJ_MISSING,COUNT_ACCTS_NEW,COUNT_DQ_REC,RESP_STS_SDVL,"")).toDF()
																								runStatsDF.write.format("delta").mode("append").save(controlTablePath)
																								log.info("Completed appending control table with current run stats")
																								log.info(s"record inserted in control table with current run stats for key1:$currentKey1")

																								log.info(spark.sql(s"select *  FROM delta.`$controlTablePath` where KEY1 = '$currentKey1'").show().toString())
																							}
																							catch
																							{
																							case e:Exception =>
																							log.error("Exception caught while appending control table with current run stats")
																							log.error(e)
																							}
																} //end if file type =REG
																else if(fileType.equalsIgnoreCase("DEF"))
																{
																	val tempFolder=params.OUTPUT_FILE_XMLREQUET_PATH +"sparkTmp"
																			val sqlString1="""select AccountNumber as H_AccountNumber,
																			|ProductType as H_ProductType,
																			|ProductStatus as H_ProductStatus,
																			|PaymentStatus as H_PaymentStatus,
																			|DefaultOutStandingAmount as H_DefaultOutStandingAmount,
																			|DefaultOriginalAmount as H_DefaultOriginalAmount,
																			|DefaultStatus as H_DefaultStatus,
																			|DefaultStatusDate as H_DefaultStatusDate,
																			|DefaultChangeDate as H_DefaultChangeDate""".stripMargin
																			import spark.implicits._
																			val histCaseclassDF =spark.sql(s"$sqlString1  FROM delta.`$baseTablePath` as A").as[DefaultInputHistMapCaseClass]
																					val defaultRequestXMLDF = spark.read.format("com.databricks.spark.xml")
																					.option("inferSchema",false)
																					.option("rowTag", "BAD_DEBT")//.option("rowTag", "ACCOUNT")
																					.load(params.INPUT_FILE_XMLREQUEST_PATH + FILE_NAME)//.load(curXMLFilePath)
																					//defaultRequestXMLDF.printSchema()
																					//defaultRequestXMLDF.show()
																					//         val finalRequestXMLDF=addMissingColumns(requestXMLDF,requestXMLFileREGSchema)
																					val defaultRequestXMLCaseClassDF=getDefaultRequestXMLMapClass_V2_0(defaultRequestXMLDF)
																					val curHistDS=defaultRequestXMLCaseClassDF.join(histCaseclassDF ,
																							defaultRequestXMLCaseClassDF("AccountNumber") === histCaseclassDF("H_AccountNumber") &&
																							defaultRequestXMLCaseClassDF("ProductType") === histCaseclassDF("H_ProductType")
																							, "left").as[DefaultRequestPlusHistCaseClass]
																									// .withColumn("NEW_ACCT_FLAG", when('H_AccountNumber.isNotNull,lit(false)).otherwise(lit(true))).as[DefaultRequestPlusHistCaseClass]
																									// .withColumn("NewFlag", when('H_ProductType.isNull , true ).otherwise(false) )
																									curHistDS.cache()
																									//Function call
																									val errorsDF= for
																									{
																										row <- curHistDS
																										val rows=getDefaultRejectionRecords(row )
																									} yield rows
																									val reqWithRejDetails=defaultRequestXMLCaseClassDF.join(errorsDF,Seq("AccountNumber","ProductType"),"left" )
																									.withColumn("SDV_REJ_FLAG", when('ErrorIDs.isNull || 'ErrorIDs===null || 'ErrorIDs==="" , lit("N")).otherwise(lit("Y")))
																									.withColumn("SIMAH_REJ_FLAG",  lit("N"))
																									.withColumn("SIMAH_REJ_MSG",  lit(""))
																									.withColumnRenamed("ErrorMsgs", "SDV_REJ_MSG")
																									//log.info("Temporary Table schema")
																									//reqWithRejDetails.printSchema()
																									//reqWithRejDetails.show()
																									try
																									{
																										val tempTableSQL=s"""CREATE OR REPLACE TABLE delta.`$tempTablePath` ( AccountNumber STRING,ProductType STRING,DefaultStatusDate Date,DefaultStatus STRING , OutStandingBalance DOUBLE,ValidFlag STRING,ErrorIDs STRING,SDV_REJ_MSG STRING,SDV_REJ_FLAG STRING,SIMAH_REJ_FLAG STRING,SIMAH_REJ_MSG STRING)  USING DELTA""".stripMargin
																												spark.sql(tempTableSQL)
																												reqWithRejDetails.write.format("delta").mode("overwrite").save(tempTablePath)
																												log.info(s"Data inserted in to working table :$tempTablePath")
																												spark.sql(s"select *  FROM delta.`$tempTablePath` ").show()
																												val tempDF=spark.sql(s"select *  FROM delta.`$tempTablePath`")
																												//log.info("Temp delta table schema")
																												//tempDF.printSchema()
																												//tempDF.show()
																									}
																									catch{
																									case e: Exception =>
																									log.error("Exception caught in working table creation block")
																									log.error(e)
																									log.error("****** Program execution aborted")
																									System.exit(1)
																									}
																									val rejectRecDF=  errorsDF.filter(col("ValidFlag")=!=("VALID")).toDF().join(defaultRequestXMLCaseClassDF , Seq("AccountNumber","ProductType") , "inner")
																											// rejectRecDF.printSchema()
																											//rejectRecDF.show()
																											val sdvRespDF =rejectRecDF.select(col("AccountNumber").alias("PREF") ,col("ProductType").alias("PPRD"),col("ErrorMsgs").alias("RSP_MSG") )
																											//log.info("sdvRespDF schema")
																											//sdvRespDF.printSchema()
																											//sdvRespDF.show()
																											val validRequestRecordsDF=defaultRequestXMLDF.join(errorsDF.select('AccountNumber.as("PREF")).filter(col("ValidFlag")===("VALID")).toDF() , Seq("PREF") )
																											log.info("Started gathering run stats")
																											val COUNT_INFILE_REC=defaultRequestXMLDF.count().toInt
																											val COUNT_OUTFILE_REC=validRequestRecordsDF.count().toInt
																											val COUNT_REJ_SDVL=rejectRecDF.count().toInt
																											val COUNT_REJ_SIMAH=0
																											val COUNT_REJ_TOTAL=COUNT_REJ_SDVL // Update after loading SIMAH response COUNT_REJ_SDVL+COUNT_REJ_MISSING
																											val COUNT_REJ_EXTRA=0          // Update after loading SIMAH response
																											val COUNT_REJ_MISSING=0       // Update after loading SIMAH response
																											val COUNT_ACCTS_NEW=0 //NewAcctsDF.count().toInt
																											val COUNT_DQ_REC=0 //dqRecordsDF.count().toInt
																											val RESP_STS_SDVL= { if(COUNT_REJ_SDVL>0) "ERROR" else "OK"}
																									val RESP_STS_SIMAH="" // Update after loading SIMAH response COUNT_REJ_SIMAH+COUNT_REJ_SDVL
																											log.info("Completed gathering run stats") 
																											//Block to prepare the header
																											//Uncomment for version 1 files  val headerLines=getHeader(INPUT_FILE_XMLREQUEST_PATH + INPUT_FILE_XMLREQUEST_NAME)
																											val headerLines=getHeader2(params.INPUT_FILE_XMLREQUEST_PATH + FILE_NAME)
																											val totalItems= "<TOT_ITEMS>" + COUNT_OUTFILE_REC +"</TOT_ITEMS>"
																											val endLines = Seq(totalItems , "</HEADER>" )
																											val finalHeaderString=headerLines ++ endLines
																											//End of block to header preparation
																											rejectRecDF.cache()
																											val outputPath=params.OUTPUT_FILE_REPORTS_PATH
																											try
																									{
																												log.info("Started saving the reqWithRejDetails file")
																												val tmpFolderName=fileNamePrepend+"_"+"ProcessedAcctsAll"
																														val newfileName=tmpFolderName+".csv"
																														reqWithRejDetails.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
																														moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
																														log.info("Completed the file with name : " + outputPath + newfileName)
																									}
																									catch{
																									case e: Exception =>
																									log.error("Error : Exception caught while saving reqWithRejDetails ")
																									log.error(e)
																									}
																									try
																									{
																										val tmpFolderName=fileNamePrepend+"_"+"RejectionReport"
																												val newfileName=tmpFolderName+".csv"
																												log.info("Started saving the Rejection Records file")
																												rejectRecDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
																												moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
																												log.info("Info : End : Saved the file with name : " + outputPath + newfileName)
																									}
																									catch{
																									case e: Exception =>
																									log.error("Error : Exception caught while saving rejectRecDF ")
																									log.error(e)
																									}
																									//  val requestFilePropsDf =getRequestFileDetails(INPUT_FILE_XMLREQUEST_PATH + INPUT_FILE_XMLREQUEST_NAME,RUN_DATE)
																									//     requestFilePropsDf.write.format("delta").mode("append").save(controlTablePath)
																									//  val df=spark.sql(s"select *  FROM delta.`$controlTablePath` as A")
																									log.info("Count of Records in input XML File       :"+ FILE_NAME+" : "+ COUNT_INFILE_REC )
																									//log.info(" Count of Records in HistoryData File     :"+ INPUT_FILE_HISTDATA_NAME   +" : "+ histCaseclassDF.count())
																									//log.info(" Count of Records in Jioned DF     :curHistDS : "+ curHistDS.count())
																									log.info("Count of Valid Records in input XML File       :"+ FILE_NAME+" : "+ COUNT_OUTFILE_REC)
																									log.info("Count of New Accounts in input XML File  :"+ FILE_NAME+" : "+ COUNT_ACCTS_NEW)
																									log.info("Count of Records in DataQuality Violations File     :"+ " : "+COUNT_DQ_REC )
																									log.info("Count of Records in Rejection Records  File     :"+ COUNT_REJ_SDVL )

																									try
																									{
																										log.info("Started function call for generateDefaultCuratedXMLFile")
																										val rejectAccountList=rejectRecDF.select(concat( 'AccountNumber ,'ProductType )).as[String].collect.toList
																										log.info("rejectAccountListCount : "+rejectAccountList.size)
																										//rejectAccountList.foreach(log.info)
																										generateDefaultCuratedXMLFile(params.INPUT_FILE_XMLREQUEST_PATH + FILE_NAME,params.OUTPUT_FILE_XMLREQUET_PATH +FILE_NAME, rejectAccountList)
																										log.info("Completed function call for generateDefaultCuratedXMLFile")
																										log.info("Curated XML file saved in: "+params.OUTPUT_FILE_XMLREQUET_PATH +FILE_NAME)
																									}
																									catch{
																									case e: Exception =>
																									log.error("Exception caught in generateDefaultCuratedXMLFile function call")
																									log.error(e)
																									}
																									curHistDS.unpersist()
																									rejectRecDF.unpersist()
																									try
																									{
																										log.info("Info:Start appending control table with current run stats")
																										val currentTime=new java.sql.Timestamp(System.currentTimeMillis())
																										val runStatsDF=Seq(RequestFileStats2 (currentKey1,currentKey2,fileName,RUN_DATE,currentTime,currentRunNumber,fileType,fileProduct,COUNT_INFILE_REC,COUNT_OUTFILE_REC,COUNT_REJ_SDVL,COUNT_REJ_SIMAH,COUNT_REJ_TOTAL,COUNT_REJ_EXTRA,COUNT_REJ_MISSING,COUNT_ACCTS_NEW,COUNT_DQ_REC,RESP_STS_SDVL,"")).toDF()
																										runStatsDF.write.format("delta").mode("append").save(controlTablePath)
																										log.info("Info:End appending control table with current run stats")
																										log.info(s" record inserted in control table with current run stats for key1:$currentKey1")
																										log.info(spark.sql(s"select *  FROM delta.`$controlTablePath` where KEY1 = '$currentKey1'").show().toString())
																									}
																									catch
																									{
																									case e:Exception =>
																									log.error("Error: Exception caught while appending control table with current run stats")
																									log.error(e)
																									}
																} //end if file type = DEF
																else
																{
																	log.warn(s"Invalid file type: $fileType    ")
																	log.error("Aborting the Program , Plase Check provided file type , file type can be either REG(REGULAR) or DEF (DEFAULT)")
																	System.exit(1)
																}
															}//end else block for previous key status update
								}//end of maxRunDF empty check if  block
								else
								{
									log.warn(s"Warning : unable to fetch the previous run details for file type: $fileType and product_type:$fileProduct ")
									log.error("Error : Aborting the Program ")
									log.info(".....QCLRequestProcessor Execution Aborted @"+ new java.sql.Timestamp(System.currentTimeMillis()))
									System.exit(1)
								}
					} // end of main try block
			catch
			{
			case e:Exception =>
			 	log.error("Error : Exception caught in QCLRequestProcessor main try block" ,e)
		}

	}
}