package com.fds.qcl

import io.delta.tables._
import io.delta._
import com.crealytics.spark.excel._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import java.time.format.DateTimeFormatter
import java.time._

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
//import utils.QCLHelperFunctions._
import utils.SimahRuleChecker._
import utils.QCLInputParams._



object manualUpdateExcelTest {
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)
    val conf = new SparkConf().setAppName("LogFileParser")
    .setMaster("local[*]")
    .set("spark.testing.memory", "2147480000") //local
    val spark = SparkSession
      .builder()
      .appName("SparkSQL")
      .master("local[*]")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .config("spark.sql.legacy.timeParserPolicy","LEGACY")// LEGACY //CORRECTED
      .config(conf)
      .getOrCreate()
      
   val fa = new FileAppender
   
        fa.setName("FileLogger")
        //fa.setFile("mylog.log")
        fa.setFile("C:/Bigdata/QCL_TESTRUN/logs/testlog.log")
        fa.setLayout(new PatternLayout("%d %-5p [%c{1}] %m%n"))
        fa.setThreshold(Level.DEBUG)
        fa.setAppend(true)
        fa.activateOptions
        //add appender to any Logger (here is root)
        Logger.getRootLogger.addAppender(fa)
// usage
val logger = Logger.getLogger("QCL")
             logger.info("I am a log message")  
    val manual_update_schema = StructType(Seq(
      StructField("AccountNumber", StringType, nullable = true),
      StructField("IssueDate", DateType, nullable = true),
      StructField("ProductType", StringType, nullable = true),
      StructField("OriginalAmount", DoubleType, nullable = true),
      StructField("SalaryAssignmentFlag", StringType, nullable = true),
      StructField("ExpiryDate", DateType, nullable = true),
      StructField("ProductStatus", StringType, nullable = true),
      StructField("InstallmentAmount", DoubleType, nullable = true),
      StructField("PaymentFrequency", StringType, nullable = true),
      StructField("Tenure", IntegerType, nullable = true),
      StructField("SecurityType", StringType, nullable = true),
      StructField("SubProductType", StringType, nullable = true),
      StructField("LastCycleID", IntegerType, nullable = true),
      StructField("LastPaymentDate", DateType, nullable = true),
      StructField("LastAmountPaid", DoubleType, nullable = true),
      StructField("PaymentStatus", StringType, nullable = true),
      StructField("OutStandingBalance", DoubleType, nullable = true),
      StructField("PastDueBalance", DoubleType, nullable = true),
      StructField("AsOfDate", DateType, nullable = true),
      StructField("NextPaymentDate", DateType, nullable = true),
      StructField("IDType", StringType, nullable = true),
      StructField("IDNumber", StringType, nullable = true),
      StructField("UpdateUserId", StringType, nullable = true),
      StructField("UpdateUserEmail", StringType, nullable = true),
      StructField("UpdateReason", StringType, nullable = true)))
    //manualUpdateFilePath
    val manualUpdateFilePath = "C:/Bigdata/QCL_TESTRUN/input/manualupdate/20191118_REG0013170PLN_MU.xlsx"
    val manualUpdateFilePath_op = "C:/Bigdata/QCL_TESTRUN/input/manualupdate/20191118_REG0013170PLN_MU_write.xlsx"
    val manualUpdateXMLFile = "C:/Bigdata/QCL_TESTRUN/input/manualupdate/20191118_REG0013170PLN_ManualUpdate.xml"
    val manualUpdateXMLFiletxt = "C:/Bigdata/QCL_TESTRUN/input/manualupdate/20191118_REG0013170PLN_ManualUpdate.txt"
    val manualUpdateTempTablePath = "C:/Bigdata/QCL_TESTRUN/deltalake/manualupdates/"
    val tempName = new File(manualUpdateFilePath).getName
    val manualUpdateFileName = tempName.substring(0, tempName.lastIndexOf("."))
    println(manualUpdateFileName)
    val manualUpdateKey2 = manualUpdateFileName.substring(9, 15)
    println(manualUpdateKey2)
    val tempDate = manualUpdateFileName.substring(0, 8)
    // println(tempDate)
    val date1 = new java.text.SimpleDateFormat("yyyyMMdd").parse(tempDate)
    val manualUpdateRunDate = new java.sql.Date(date1.getTime())
    println(manualUpdateRunDate)
    val manualUpdateTempTable = manualUpdateTempTablePath + manualUpdateFileName
    // spark.sql(s"select  lpad( date_part('D',ACC.IssueDate) ,2, '0') as d , lpad( date_part('MON',ACC.IssueDate) ,2, '0') as m ,date_part('YEAR',ACC.IssueDate) as y FROM delta.`$manualUpdateTempTable` as ACC").show()
     //deleteFolder3(manualUpdateTempTable)
    //println(s"Temporary table $manualUpdateTempTable deleted / dropped")
   
    /*val manualUpdateFileDF = spark.sqlContext.read.format("csv").option("header", "true").option("inferSchema", "false").option("dateFormat","MM/dd/yyyy")
                   .schema(manual_update_schema) .option("delimiter", "          ")
                   .load(manualUpdateFilePath)
                   
                   */
    /*
     * val df = spark.read.excel(
                header = true,  // Required
                dataAddress = "'My Sheet'!B3:C35", // Optional, default: "A1"
                treatEmptyValuesAsNulls = false,  // Optional, default: true
                setErrorCellsToFallbackValues = false, // Optional, default: false, where errors will be converted to null. If true, any ERROR cell values (e.g. #N/A) will be converted to the zero values of the column's data type.
                usePlainNumberFormat = false,  // Optional, default: false. If true, format the cells without rounding and scientific notations
                inferSchema = false,  // Optional, default: false
                addColorColumns = true,  // Optional, default: false
                timestampFormat = "MM-dd-yyyy HH:mm:ss",  // Optional, default: yyyy-mm-dd hh:mm:ss[.fffffffff]
                maxRowsInMemory = 20,  // Optional, default None. If set, uses a streaming reader which can help with big files (will fail if used with xls format files)
                maxByteArraySize = 2147483647,  // Optional, default None. See https://poi.apache.org/apidocs/5.0/org/apache/poi/util/IOUtils.html#setByteArrayMaxOverride-int-
                tempFileThreshold = 10000000, // Optional, default None. Number of bytes at which a zip entry is regarded as too large for holding in memory and the data is put in a temp file instead
                excerptSize = 10,  // Optional, default: 10. If set and if schema inferred, number of rows to infer schema from
                workbookPassword = "pass"  // Optional, default None. Requires unlimited strength JCE for older JVMs
            ).schema(myCustomSchema) // Optional, default: Either inferred schema, or all columns are Strings
             .load("Worktime.xlsx")
        */
    
    val manualUpdateFileDF = spark.read.excel(
                    header = true,  // Required
                   // dataAddress = "'My Sheet'!B3:C35", // Optional, default: "A1"
                   // treatEmptyValuesAsNulls = false,  // Optional, default: true
                    //setErrorCellsToFallbackValues = false, // Optional, default: false, where errors will be converted to null. If true, any ERROR cell values (e.g. #N/A) will be converted to the zero values of the column's data type.
                    //usePlainNumberFormat = false,  // Optional, default: false. If true, format the cells without rounding and scientific notations
                    // DateFormat = "mm-dd-yyyy",
                    //timestampFormat = "MM/dd/yyyy"
                    //inferSchema = true,
                    ).schema(manual_update_schema) // Optional, default: Either inferred schema, or all columns are Strings
             .load(manualUpdateFilePath)
    manualUpdateFileDF.printSchema()
    manualUpdateFileDF.show()
    
    manualUpdateFileDF.write
        .format("com.crealytics.spark.excel") // Or .format("excel") for V2 implementation
        //.option("dataAddress", "'My Sheet'!B3:C35")
        .option("header", "true")
        .option("dateFormat", "mm/dd/yyyy") // Optional, default: yy-m-d h:mm
        //.option("timestampFormat", "mm-dd-yyyy hh:mm:ss") // Optional, default: yyyy-mm-dd hh:mm:ss.000
        .mode("overwrite") // Optional, default: overwrite.
        .save(manualUpdateFilePath_op)
  
    //System.exit(0)
    
    deleteFolder3(manualUpdateTempTable)
    
    
    
    val tempTableSQL = s"""CREATE OR REPLACE TABLE delta.`$manualUpdateTempTable` (
        AccountNumber STRING ,
        |IssueDate Date,
        |ProductType STRING,
        |OriginalAmount DOUBLE,
        |SalaryAssignmentFlag STRING ,
        |ExpiryDate Date,
        |ProductStatus STRING,
        |InstallmentAmount DOUBLE,
        |PaymentFrequency STRING,
        |Tenure INT,
        |SecurityType STRING,
        |SubProductType STRING,
        |LastCycleID INT,
        |LastPaymentDate Date,
        |LastAmountPaid DOUBLE,
        |PaymentStatus STRING,
        |OutStandingBalance DOUBLE,
        |PastDueBalance DOUBLE,
        |AsOfDate Date,
        |NextPaymentDate Date,
        |IDType STRING,
        |IDNumber STRING,
        |UpdateUserId STRING,
        |UpdateUserEmail STRING,
        |UpdateReason STRING)  USING DELTA""".stripMargin
    // manualDF.repartition(1) .write.format("csv").mode("overwrite").option("header", "true").save("E:/Murali/bigdata_folder/DataProfiling/Simah/TestRun2_1_delta/output/MANUALUPDATE/test")
    spark.sql(tempTableSQL)
    //reqWithRejDetails.write.format("delta").saveAsTable("E:/Murali/bigdata_folder/DataProfiling/Simah/LAKEHOUSE/TEMP/REG0015720PLN")
    manualUpdateFileDF.write.format("delta").mode("overwrite").save(manualUpdateTempTable)
    println(s"inserted data to temp table :$manualUpdateTempTable")
    //spark.sql(s"select *  FROM delta.`$manualUpdateTempTable` ").show()
    val tempDF = spark.sql(s"select *  FROM delta.`$manualUpdateTempTable`")
    //SELECT      '<AREF>' || ACC.AccountNumber || '</AREF>' AS AccountNumber,
    println("Temp delta table schema")
    tempDF.printSchema()
    tempDF.show()
    import spark.implicits._
    val manualUpdateList=tempDF.select(concat( 'AccountNumber ,'ProductType )).as[String].collect.toList
    
    //manualUpdateList.foreach(println)
    
    println("manualUpdateListCount : "+manualUpdateList.size)
    
     val sqlStr="""select '<ACCOUNT>' as account_start_tag,
       '<AREF>' || ACC.AccountNumber || '</AREF>' AS AccountNumber ,
      |CASE WHEN ACC.IssueDate is not null then '<AOPN>' || '<AOPND>' || lpad( date_part('D',ACC.IssueDate) ,2, '0') || '</AOPND>' || '<AOPNM>' || lpad( date_part('MON',ACC.IssueDate) ,2, '0') || '</AOPNM>' || '<AOPNY>' || date_part('YEAR',ACC.IssueDate)  || '</AOPNY>' || '</AOPN>' else null END AS IssueDate,
      |'<APRD>' || ACC.ProductType || '</APRD>' AS ProductType,
      |'<ALMT>' || ACC.OriginalAmount || '</ALMT>'  AS OriginalAmount,
      |'<ASAL>' || ACC.SalaryAssignmentFlag || '</ASAL>'AS SalaryAssignmentFlag,
      |CASE WHEN ACC.ExpiryDate is not null then '<AEXP>' || '<AEXPD>' || lpad( date_part('D',ACC.ExpiryDate) ,2, '0') || '</AEXPD>' || '<AEXPM>' || lpad( date_part('MON',ACC.ExpiryDate) ,2, '0') || '</AEXPM>' || '<AEXPY>' || date_part('YEAR',ACC.ExpiryDate)  || '</AEXPY>' || '</AEXP>' else null END AS ExpiryDate,
      |'<APST>' || ACC.ProductStatus || '</APST>' AS ProductStatus,
      |'<AINST>' || ACC.InstallmentAmount || '</AINST>' AS InstallmentAmount,
      |'<AFRQ>' || ACC.PaymentFrequency || '</AFRQ>' AS PaymentFrequency,
      |'<ATNR>' || ACC.Tenure || '</ATNR>' AS Tenure,
      |'<ASEC>' || ACC.SecurityType || '</ASEC>' AS SecurityType,
      |CASE WHEN ACC.SubProductType IS NOT NULL THEN '<ASP>' || ACC.SubProductType  || '</ASP>' ELSE NULL END AS SubProductType,
      |'<ACYC>' as cycle_start_tag,
      |'<ACYCID>' || ACC.LastCycleID || '</ACYCID>'  AS LastCycleID,
      |CASE WHEN ACC.LastPaymentDate is not null then '<ALSPD>' || '<ALSPDD>' || lpad( date_part('D',ACC.LastPaymentDate) ,2, '0') || '</ALSPDD>' || '<ALSPDM>' || lpad( date_part('MON',ACC.LastPaymentDate) ,2, '0') || '</ALSPDM>' || '<ALSPDY>' || date_part('YEAR',ACC.LastPaymentDate)  || '</ALSPDY>' || '</ALSPD>' else null END AS LastPaymentDate,
      |'<ALSTAM>' || ACC.LastAmountPaid || '</ALSTAM>' AS LastAmountPaid,
      |'<AACS>' || ACC.PaymentStatus || '</AACS>' AS PaymentStatus,
      |'<ACUB>' || ACC.OutStandingBalance || '</ACUB>' AS OutStandingBalance,
      |'<AODB>' || ACC.PastDueBalance || '</AODB>' AS PastDueBalance,
      |CASE WHEN ACC.AsOfDate is not null then '<AASOF>' || '<AASOFD>' || lpad( date_part('D',ACC.AsOfDate) ,2, '0') || '</AASOFD>' || '<AASOFM>' || lpad( date_part('MON',ACC.AsOfDate) ,2, '0') || '</AASOFM>' || '<AASOFY>' || date_part('YEAR',ACC.AsOfDate)  || '</AASOFY>' || '</AASOF>' else null END AS AsOfDate,
      |CASE WHEN ACC.NextPaymentDate is not null then '<ANXPD>' || '<ANXPDD>' || lpad( date_part('D',ACC.NextPaymentDate) ,2, '0') || '</ANXPDD>' || '<ANXPDM>' || lpad( date_part('MON',ACC.NextPaymentDate) ,2, '0') || '</ANXPDM>' || '<ANXPDY>' || date_part('YEAR',ACC.NextPaymentDate)  || '</ANXPDY>' || '</ANXPD>' else null END  AS NextPaymentDate ,
      |'</ACYC>'  as cycle_end_tag,
      |'<CONSUMER>' AS consumer_start_tag ,
      |'<CID>' AS ID_start_tag,
      |'<CID1>' || ACC.IDType || '</CID1>' AS IDType,
      |'<CID2>' || ACC.IDNumber || '</CID2>' AS IDNumber,
      |'</CID>' AS ID_end_tag,
      |'</CONSUMER>' AS consumer_end_tag,
      | '</ACCOUNT>'  as account_end_tag  """.stripMargin
      
      
      
    val xmlDataDF=spark.sql(s"$sqlStr  FROM delta.`$manualUpdateTempTable` as ACC")
    xmlDataDF.printSchema()
    xmlDataDF.show()
    val allColumns=xmlDataDF.columns.map(m=>col(m))
    
    import com.databricks.spark.xml._
    //tempDF.write.option("rootTag", "ACCOUNTS").option("rowTag", "ACCOUNT").xml(manualUpdateXMLFiletxt)
    
    
    
    xmlDataDF.na.fill("NA")
    .coalesce(1)
    .rdd.map(_.toString()
        .replace("[","").replace("]", "")
        .replace("NA,", "")
          .replace(",","\n"))
          .saveAsTextFile(manualUpdateXMLFiletxt)

    val outputPath = "C:/Bigdata/QCL_TESTRUN/input/manualupdate/output"	
   // val tmpFolderName="mu"
			//val newfileName=tmpFolderName+".csv"
    //moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
    //xmlDataDF.write.mode("overwrite").format("text").save(manualUpdateXMLFiletxt)
    
    import spark.implicits._
    //val xmlStringList=xmlDataDF.select(allColumns:_*).show()// .as[String].collect.toList
    val xmlStringArray=xmlDataDF.select(allColumns:_*).collect() //.toList.foreach(f => f.getList(0)) //.map { row => row}
   // val x=xmlDataDF.select(allColumns:_*).collectAsList()
    val abc = xmlDataDF.select(allColumns:_*).collect()//.flatMap(f => f.getAs[Seq[Seq[String]]](0))
    //abc.foreach(println)
      // 
        for (i <- 0 until abc.length)
       {
          val row=abc(i)
          for(j <- 0 until row.length)
          {
            //println(row(j))
          }
       }
         //xmlStringArray.get(i)
       // }
      //}
   // xmlStringArray.foreach(println)
     //val xmlStringList2=xmlDataDF.collect().map(row => row.getString(0) )
     val bufferWrite = new PrintWriter(new FileOutputStream(new File(manualUpdateXMLFile), true))
   // var row=Array([String])
    for(i <- 0 until xmlStringArray.length)
    {
      val row =xmlStringArray(i)
      for(j <- 0 until row.length )
      {
        val tag=row(j)
        if(tag != null)
        bufferWrite.write(tag + "\n")
      }
      //
    }
    bufferWrite.close()
    spark.close()
    spark.stop()
  }
}