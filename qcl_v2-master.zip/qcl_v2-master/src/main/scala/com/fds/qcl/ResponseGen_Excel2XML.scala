
package com.fds.qcl

import io.delta.tables._
import io.delta._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import org.apache.commons.io.FileUtils
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import java.time.format.DateTimeFormatter
import java.time._

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
//import utils.InputParams2._
import utils.ConfigParams._
import com.crealytics.spark.excel._
object ResponseGen_Excel2XML {
  

  def main(args: Array[String]) {

    Logger.getLogger("org").setLevel(Level.ERROR)

    val spark = SparkSession.builder().appName("SparkSQL").master("local[*]")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    println(".....ResponseGen_Excel2XML Execution Started @" + new java.sql.Timestamp(System.currentTimeMillis()))

    if (args == null || args.length == 0 || args.length == 1 || args.length > 3) {
      println("Usage : Insufficiant Number of arguments , kindly provide required parameters and try again...")
      println("Usage : This program requires two mandatory and 3rd optional input parameters :: Param 1 : home path and Param 2: file name 3:total records in request file[optional , if not provided defaulting to zero]")
      println("Usage : Sample parameters : C:/QCL/TESTDATAFILES/ 111REG0000222PLN_xxxxxxxx_REGULAR_AC_A.xlsx 586")
      println("Error : Aborting the Program ")
      System.exit(1)
    }
    val response_excelfile_schema = StructType(Seq(
      StructField("AccountNumber", StringType, nullable = true),
      StructField("ProductType", StringType, nullable = true),
      StructField("ResponseMessage", StringType, nullable = true)))

    //val HOME_PATH = "C:/Bigdata/QCL_TESTRUN/testdatafiles/"
    val HOME_PATH = args(0)
    //val FILE_NAME = HOME_PATH + "input/request/" + "888REG0000101PLN.xlsx"
    val FILE_NAME = HOME_PATH + "input/response/" + args(1)
    val outFilePath = HOME_PATH + "output/response/" //params.OUTPUT_FILE_XMLREQUET_PATH
    val fileName = getFileName(FILE_NAME)
    //println("fileName:"+fileName)
    val fileNameWOext = fileName.slice(0, fileName.lastIndexOf("."))
    val xmlFileName = fileNameWOext + ".xml"
    val responseXMLfilePath = outFilePath + xmlFileName
    val runNumber = fileName.substring(6, 13) //.toInt
    val fileType = fileName.substring(3, 6)
    val fileProduct = fileName.substring(13, 16)
    val memberId = fileName.substring(0, 3)

    //println("xmlFileName:"+xmlFileName)
    //println("requestTable:"+requestTable)
    //println("responseXMLfilePath:"+responseXMLfilePath)
    println(s".....Processing the file : $FILE_NAME ")
    println("fileType:" + fileType)
    println("fileProduct:" + fileProduct)
    println("memberId:" + memberId)
    println("runNumber:" + runNumber)

    try {
      val newFile = new File(responseXMLfilePath)
      if (newFile.exists()) {
        //Delete request XML file in target , if exists
        newFile.delete()
        println("*****File already exists , deleting the file :" + responseXMLfilePath)
      }
    } catch { case e: Exception => e.printStackTrace() }
    try {
      import spark.implicits._
      val excelDF = spark.read.excel(
        header = true,
        treatEmptyValuesAsNulls = false
      //.option("inferSchema", "true")
      //.option("addColorColumns", "False")
      ).schema(response_excelfile_schema)
        .load(FILE_NAME)

      println("Excel file schema ........")
      excelDF.printSchema()
      excelDF.show(false)

  
      val COUNT_OUTFILE_REC = if(args.length == 3)  args(2).toInt else 0
      import spark.implicits._
      try {
        val windowSpec = Window.partitionBy(lit(1)).orderBy("PREF")
        val sdvRespDF = excelDF.select(col("AccountNumber").alias("PREF"), col("ProductType").alias("PPRD"), col("ResponseMessage").alias("RSP_MSG"))
          .withColumn("SEQ", row_number.over(windowSpec))
          .select('SEQ, 'PREF, 'PPRD, 'RSP_MSG)

        val respErrorsList = sdvRespDF.collect()
        val rejectCount = respErrorsList.size

        val bufferWrite = new PrintWriter(new FileOutputStream(new File(responseXMLfilePath), true))

        val msgStartTag = "<MESSAGE>"
        val msgEndTag = "</MESSAGE>"

        val respTag_1 = "<RESPONSE xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"CI_Response_New.xsd\">"
        val serviceTag_2 = "<SERVICE>REGULAR_AC</SERVICE>"
        val actionTag_3 = "<ACTION>A</ACTION>"

        val statusFlag = if (rejectCount == 0) "OK" else "ERROR"

        val statusTag_4 = s"<STATUS>$statusFlag</STATUS>"

        //:TODO parameterize member and user id tag values from config
        val headerStartTag_5 = "<HEADER>" + "\n" + "<MEMBER_ID>"+memberId+"</MEMBER_ID>" + "\n" + "<USER_ID>FTSXXXX</USER_ID>"

        val runNumberTag_6 = "<RUN_NO>" + runNumber.toString() + "</RUN_NO>"
        val tottalItemsTag_7 = "<TOT_ITEMS>" + COUNT_OUTFILE_REC.toString() + "</TOT_ITEMS>"
        val errorItemsTag_8 = "<ERR_ITEMS>" + rejectCount.toString() + "</ERR_ITEMS>"

        val headerEndTag_9 = "</HEADER>"

        val respEndTag = "</RESPONSE>"

        /*<HEADER>
          <MEMBER_ID>888</MEMBER_ID>
          <USER_ID>FTSNCBB</USER_ID>
          <RUN_NO>16408</RUN_NO>
          <TOT_ITEMS>127592</TOT_ITEMS>
          <ERR_ITEMS>74</ERR_ITEMS>
          </HEADER>
          <MESSAGE>*/
        bufferWrite.write(respTag_1 + "\n")
        bufferWrite.write(serviceTag_2 + "\n")
        bufferWrite.write(actionTag_3 + "\n")
        bufferWrite.write(statusTag_4 + "\n")
        bufferWrite.write(headerStartTag_5 + "\n")
        bufferWrite.write(runNumberTag_6 + "\n")
        bufferWrite.write(tottalItemsTag_7 + "\n")
        bufferWrite.write(errorItemsTag_8 + "\n")
        bufferWrite.write(headerEndTag_9 + "\n")

        if (rejectCount > 0) {
          bufferWrite.write(msgStartTag + "\n")
          for (i <- 0 until respErrorsList.length) {
            val row = respErrorsList(i)
            // for(j <- 0 until row.length )
            //{
            val seq = row.get(0)
            val act = row.getString(1)
            val prd = row.getString(2)
            val msg = row.getString(3)

            val seqTag = "<ITEM seq=\"" + seq + "\">"
            val actTag = "<AREF>" + act + "</AREF>"
            val prdTag = "<APRD>" + prd + "</APRD>"
            val msgTag = "<ERROR>" + "\n" + "<RSP_MSG>" + msg + "</RSP_MSG>" + "\n" + "</ERROR>"
            val endTag = "<NO_ERRORS>1</NO_ERRORS>" + "\n" + "</ITEM>"

            bufferWrite.write(seqTag + "\n")
            bufferWrite.write(actTag + "\n")
            bufferWrite.write(prdTag + "\n")
            bufferWrite.write(msgTag + "\n")
            bufferWrite.write(endTag + "\n")
          }
          bufferWrite.write(msgEndTag + "\n")
          bufferWrite.write(respEndTag)
          bufferWrite.close()
        }
        println(s"XML file saved in :  $responseXMLfilePath")
      } catch {
        case e: Exception => e.printStackTrace()
      }

    } catch { case e: Exception => e.printStackTrace() }
    println(".....ResponseGen_Excel2XML Execution Completed @" + new java.sql.Timestamp(System.currentTimeMillis()))
  }
}