package com.fds.qcl.utils

import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import org.apache.spark.sql._
import org.apache.spark.sql.types._
 
case class SchemaMapClass
(
		Enabled:  Boolean ,
		DataType:  String ,
		Precision : String,
		Scale : String,
		DateFormat: String,
		DefaultValue:String
		)
case class QCLHistConfigParams(propMap: Map[String,String])
{
    
    val spark = SparkSession.builder().getOrCreate()
   
    val INPUT_SOURCE              : String = propMap.getOrElse("INPUT.SOURCE", "NA")
   
    
    val INPUT_DATAFILEFORMAT      : String = if( propMap.getOrElse("INPUT.DATAFILE.FORMAT","").isEmpty()) "CSV" else propMap.get("INPUT.DATAFILE.FORMAT").get
    val INPUT_DATAFILEPARSINGMODE : String = if( propMap.getOrElse("INPUT.DATAFILE.PARSINGMODE","").isEmpty()) "PERMISSIVE" else propMap.get("INPUT.DATAFILE.PARSINGMODE").get
    val INPUT_DATAFILECHARCTERSET : String = if( propMap.getOrElse("INPUT.DATAFILE.CHARCTERSET","").isEmpty()) "UTF-8" else propMap.get("INPUT.DATAFILE.CHARCTERSET").get
    val INPUT_DATAFILEDELIMETER   : String = if( propMap.getOrElse("INPUT.DATAFILE.DELIMETER","").isEmpty()) "," else propMap.get("INPUT.DATAFILE.DELIMETER").get
    val INPUT_DATAFILE_LINESEPARATOR:Boolean= propMap.getOrElse("INPUT.DATAFILE.LINESEPARATOR", "true").toBoolean
    val INPUT_DATAFILE_RECORDLENGTH :Int= if( propMap.getOrElse("INPUT.DATAFILE.RECORDLENGTH","").isEmpty()) 0 else propMap.get("INPUT.DATAFILE.RECORDLENGTH").get.toInt
    val INPUT_DATAFILE_HEADER       :    Boolean = propMap.getOrElse("INPUT.DATAFILE.HEADER", "true").toBoolean
    val INPUT_DATAFILELOCATION    : String = propMap.getOrElse("INPUT.DATAFILE.LOCATION", "NA")
    val INPUT_DATAFILEPATH        : String = propMap.getOrElse("INPUT.DATAFILE.PATH", "NA")
    val INPUT_DATAFILENAME        : String = propMap.getOrElse("INPUT.DATAFILE.NAME", "NA")
   
    val INPUT_SCHEMAFILELOCATION  : String = propMap.getOrElse("INPUT.SCHEMAFILE.LOCATION", "NA")
    val INPUT_SCHEMAFILEPATH      : String = propMap.getOrElse("INPUT.SCHEMAFILE.PATH", "NA")
    val INPUT_SCHEMAFILENAME      : String = propMap.getOrElse("INPUT.SCHEMAFILE.NAME","NA") 
    
    val LOAD_MODE  : String = propMap.getOrElse("LOAD.MODE", "overwrite")
    val LOAD_MAPPINGFILE_PATH  : String = propMap.getOrElse("LOAD.MAPPINGFILE.PATH", "NA")
    val LOAD_MAPPINGFILE_NAME      : String = propMap.getOrElse("LOAD.MAPPINGFILE.NAME", "NA")
    val LOAD_MAPPINGFILE_DELIMETER      : String = propMap.getOrElse("LOAD.MAPPINGFILE.DELIMETER",",") 
 
 
   val schemaFile=
     try
    {
       //spark.sparkContext.textFile(input_schemafilepath+input_schemafilename).map(x=>x.split('|')).collect()
       spark.sparkContext.textFile( INPUT_SCHEMAFILEPATH+INPUT_SCHEMAFILENAME).map(x=>x.split(',')).collect()
    }
     catch{
      case e:Exception  => println("************ Exception Caught in reading the SchemaFile :"+ INPUT_SCHEMAFILEPATH+INPUT_SCHEMAFILENAME)
      e.printStackTrace()
      Array[Array[String]]()
    }
 
  val schemaTupleMapParam =
    if (INPUT_DATAFILEFORMAT .equalsIgnoreCase("CSV") && !schemaFile.isEmpty)
      schemaFile.filter(rec => rec(1).equalsIgnoreCase("YES")).map(f => ((f(0) -> (f(2), f(3), f(4), f(5), f(6), f(7), f(8), f(9), f(10), f(11), f(12), f(13))))).toMap
    else if (INPUT_DATAFILEFORMAT .equalsIgnoreCase("FIXEDWIDTH") && !schemaFile.isEmpty)
      schemaFile.filter(rec => rec(3).equalsIgnoreCase("YES")).map(f => ((f(0) -> (f(4), f(5), f(6), f(7), f(8), f(9), f(10), f(11), f(12), f(13), f(14), f(15))))).toMap
    else
      Map[String, (String, String, String, String, String, String, String, String, String, String, String, String)]()
 
  val fixedWidthArrayParam =
    if (INPUT_DATAFILEFORMAT .equalsIgnoreCase("FIXEDWIDTH") && !schemaFile.isEmpty)
      schemaFile.filter(rec => rec(3).equalsIgnoreCase("YES")).map(f => Array(f(0), f(1), f(2))).toArray
    else
      Array[Array[String]]()
     
     val LOAD_MAPPING_LIST=
     try
    {
       //spark.sparkContext.textFile(input_schemafilepath+input_schemafilename).map(x=>x.split('|')).collect()
       spark.sparkContext.textFile( LOAD_MAPPINGFILE_PATH+LOAD_MAPPINGFILE_NAME).map(x=>x.split(LOAD_MAPPINGFILE_DELIMETER)).collect().toList
    }
     catch{
      case e:Exception  => println("************ Exception Caught in reading the SchemaFile :"+ INPUT_SCHEMAFILEPATH+INPUT_SCHEMAFILENAME)
      e.printStackTrace()
      List[Array[String]]()
    }
}
case class QCLHistConfigParams_V2(propMap: Map[String,String])
{
    
    val spark = SparkSession.builder().getOrCreate()
   
    val INPUT_SOURCE              : String = propMap.getOrElse("INPUT.SOURCE", "NA")
   
    
    val INPUT_DATAFILEFORMAT      : String = if( propMap.getOrElse("INPUT.DATAFILE.FORMAT","").isEmpty()) "CSV" else propMap.get("INPUT.DATAFILE.FORMAT").get
    val INPUT_DATAFILENAME        : String = propMap.getOrElse("INPUT.DATAFILE.NAME", "NA")
   
    val INPUT_SCHEMAFILELOCATION  : String = propMap.getOrElse("INPUT.SCHEMAFILE.LOCATION", "NA")
    val INPUT_SCHEMAFILEPATH      : String = propMap.getOrElse("INPUT.SCHEMAFILE.PATH", "NA")
    val INPUT_SCHEMAFILENAME      : String = propMap.getOrElse("INPUT.SCHEMAFILE.NAME","NA") 
    
    val LOAD_MODE  : String = propMap.getOrElse("LOAD.MODE", "overwrite")
    val LOAD_MAPPINGFILE_PATH  : String = propMap.getOrElse("LOAD.MAPPINGFILE.PATH", "NA")
    val LOAD_MAPPINGFILE_NAME      : String = propMap.getOrElse("LOAD.MAPPINGFILE.NAME", "NA")
    val LOAD_MAPPINGFILE_DELIMETER      : String = propMap.getOrElse("LOAD.MAPPINGFILE.DELIMETER",",") 
 
 
   val schemaFile=
     try
    {
       //spark.sparkContext.textFile(input_schemafilepath+input_schemafilename).map(x=>x.split('|')).collect()
       spark.sparkContext.textFile( INPUT_SCHEMAFILEPATH+INPUT_SCHEMAFILENAME).map(x=>x.split(',')).collect()
    }
     catch{
      case e:Exception  => println("************ Exception Caught in reading the SchemaFile :"+ INPUT_SCHEMAFILEPATH+INPUT_SCHEMAFILENAME)
      e.printStackTrace()
      Array[Array[String]]()
    }
 
     val schemaTupleMapParam2 = schemaFile.map(f => ((f(0) -> new SchemaMapClass(f(2).toBoolean, f(3), f(4), f(5), f(6), f(7))))).toMap
     
     val test=schemaTupleMapParam2.get("Calumn1").get
     
     val col=test.DataType
      
  val schemaTupleMapParam =
    if (INPUT_DATAFILEFORMAT .equalsIgnoreCase("CSV") && !schemaFile.isEmpty)
      schemaFile.map(f => ((f(0) -> (f(2), f(3), f(4), f(5), f(6), f(7), f(8), f(9), f(10), f(11), f(12), f(13))))).toMap
    else if (INPUT_DATAFILEFORMAT .equalsIgnoreCase("FIXEDWIDTH") && !schemaFile.isEmpty)
      schemaFile.filter(rec => rec(3).equalsIgnoreCase("YES")).map(f => ((f(0) -> (f(4), f(5), f(6), f(7), f(8), f(9), f(10), f(11), f(12), f(13), f(14), f(15))))).toMap
    else
      Map[String, (String, String, String, String, String, String, String, String, String, String, String, String)]()
 
  val fixedWidthArrayParam =
    if (INPUT_DATAFILEFORMAT .equalsIgnoreCase("FIXEDWIDTH") && !schemaFile.isEmpty)
      schemaFile.filter(rec => rec(3).equalsIgnoreCase("YES")).map(f => Array(f(0), f(1), f(2))).toArray
    else
      Array[Array[String]]()
     
     val LOAD_MAPPING_LIST=
     try
    {
       //spark.sparkContext.textFile(input_schemafilepath+input_schemafilename).map(x=>x.split('|')).collect()
       spark.sparkContext.textFile( LOAD_MAPPINGFILE_PATH+LOAD_MAPPINGFILE_NAME).map(x=>x.split(LOAD_MAPPINGFILE_DELIMETER)).collect().toList
    }
     catch{
      case e:Exception  => println("************ Exception Caught in reading the SchemaFile :"+ INPUT_SCHEMAFILEPATH+INPUT_SCHEMAFILENAME)
      e.printStackTrace()
      List[Array[String]]()
    }
}
case class QCLConfigParams(propMap: Map[String,String] , qclHome: String)
{
    
    val configFileLoad = if(propMap.isEmpty) false else true
    
    val DELTA_TABLE_PATH_BASE             :String =if(propMap.getOrElse("DELTA_TABLE_PATH_BASE", "").isEmpty()) s"$qclHome/deltalake/base/" else propMap.get("DELTA_TABLE_PATH_BASE").get
    val DELTA_TABLE_PATH_WORKING          :String =if(propMap.getOrElse("DELTA_TABLE_PATH_WORKING", "").isEmpty()) s"$qclHome/deltalake/working/" else propMap.get("DELTA_TABLE_PATH_WORKING").get
    val DELTA_TABLE_PATH_SNAPSHOT         :String =if(propMap.getOrElse("DELTA_TABLE_PATH_SNAPSHOT", "").isEmpty()) s"$qclHome/deltalake/snapshot/" else propMap.get("DELTA_TABLE_PATH_SNAPSHOT").get
    val DELTA_TABLE_PATH_REPORTING        :String =if(propMap.getOrElse("DELTA_TABLE_PATH_REPORTING", "").isEmpty()) s"$qclHome/deltalake/reporting/" else propMap.get("DELTA_TABLE_PATH_REPORTING").get
    val QCL_PARALLEL_RUN                   :String =if(propMap.getOrElse("QCL_PARALLEL_RUN","").isEmpty())  "N" else propMap.get("QCL_PARALLEL_RUN").get
    
    val DELTA_TABLE_NAME_BASE             :String =if(propMap.getOrElse("DELTA_TABLE_NAME_BASE", "").isEmpty()) "base_hist" else propMap.get("DELTA_TABLE_NAME_BASE").get
    val DELTA_TABLE_NAME_BASERAW          :String =if(propMap.getOrElse("DELTA_TABLE_NAME_BASERAW", "").isEmpty()) "base_hist_raw" else propMap.get("DELTA_TABLE_NAME_BASERAW").get
    val DELTA_TABLE_NAME_CONTROL          :String =if(propMap.getOrElse("DELTA_TABLE_NAME_CONTROL", "").isEmpty()) "exe_control" else propMap.get("DELTA_TABLE_NAME_CONTROL").get
    
    val INPUT_FILE_HISTDATA_CONFIG_PATH   :String =propMap.getOrElse("INPUT_FILE_HISTDATA_CONFIG_PATH", s"$qclHome/config/")
    val INPUT_FILE_HISTDATA_CONFIG_FILENAME:String =propMap.getOrElse("INPUT_FILE_HISTDATA_CONFIG_FILENAME", s"hist_recon.properties")
                                                   
                                                val  INPUT_FILE_HISTDATA_CHARACTERSET :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_CHARACTERSET","").isEmpty())  "UTF-16" else propMap.get("INPUT_FILE_HISTDATA_CHARACTERSET").get
    val  INPUT_FILE_HISTDATA_DELIMETER    :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_DELIMETER","").isEmpty())  "," else propMap.get("INPUT_FILE_HISTDATA_DELIMETER").get
    val  INPUT_FILE_HISTDATA_FORMAT       :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_FORMAT","").isEmpty())  "csv" else propMap.get("INPUT_FILE_HISTDATA_FORMAT").get
    val  INPUT_FILE_HISTDATA_HEADER       :Boolean =propMap.getOrElse("INPUT_FILE_HISTDATA_HEADER","true").toBoolean
    val  INPUT_FILE_HISTDATA_PARSINGMODE  :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_PARSINGMODE","").isEmpty())  "DROPMALFORMED" else propMap.get("INPUT_FILE_HISTDATA_PARSINGMODE").get
    val  INPUT_FILE_HISTDATA_PATH         :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_PATH","").isEmpty())  s"$qclHome/input/history/" else propMap.get("INPUT_FILE_HISTDATA_PATH").get
    val  INPUT_FILE_MANUALDATA_CHARACTERSET:String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_CHARACTERSET","").isEmpty())  "UTF-8" else propMap.get("INPUT_FILE_MANUALDATA_CHARACTERSET").get
    val  INPUT_FILE_HISTDATA_DATEFORMAT    :String =if(propMap.getOrElse("INPUT_FILE_HISTDATA_DATEFORMAT","").isEmpty())  "dd-MM-yyyy" else propMap.get("INPUT_FILE_HISTDATA_DATEFORMAT").get
    val  INPUT_FILE_MANUALDATA_DATEFORMAT  :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_DATEFORMAT","").isEmpty())  "dd-MM-yyyy" else propMap.get("INPUT_FILE_MANUALDATA_DATEFORMAT").get
    val  INPUT_FILE_MANUALDATA_DELIMETER   :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_DELIMETER","").isEmpty())  "," else propMap.get("INPUT_FILE_MANUALDATA_DELIMETER").get
    val  INPUT_FILE_MANUALDATA_FORMAT      :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_FORMAT","").isEmpty())  "csv" else propMap.get("INPUT_FILE_MANUALDATA_FORMAT").get
    val  INPUT_FILE_MANUALDATA_HEADER      :Boolean =propMap.getOrElse("INPUT_FILE_HISTDATA_HEADER","true").toBoolean
    val  INPUT_FILE_MANUALDATA_PARSINGMODE :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_PARSINGMODE","").isEmpty())  "DROPMALFORMED" else propMap.get("INPUT_FILE_MANUALDATA_PARSINGMODE").get
    val  INPUT_FILE_MANUALDATA_PATH        :String =if(propMap.getOrElse("INPUT_FILE_MANUALDATA_PATH","").isEmpty())  s"$qclHome/input/request/manual/" else propMap.get("INPUT_FILE_MANUALDATA_PATH").get
    val  INPUT_FILE_XMLREQUEST_CHARACTERSET:String =if(propMap.getOrElse("INPUT_FILE_XMLREQUEST_CHARACTERSET","").isEmpty())  "UTF-8" else propMap.get("INPUT_FILE_XMLREQUEST_CHARACTERSET").get
    val  INPUT_FILE_XMLREQUEST_PATH        :String =if(propMap.getOrElse("INPUT_FILE_XMLREQUEST_PATH","").isEmpty())  s"$qclHome/input/request/" else propMap.get("INPUT_FILE_XMLREQUEST_PATH").get
    val  INPUT_FILE_XMLREQUEST_ROWTAG      :String =if(propMap.getOrElse("INPUT_FILE_XMLREQUEST_ROWTAG","").isEmpty())  "ACCOUNT"  else propMap.get("INPUT_FILE_XMLREQUEST_ROWTAG").get
    val  INPUT_FILE_XMLRESPONSE_CHARACTERSET:String =if(propMap.getOrElse("INPUT_FILE_XMLRESPONSE_CHARACTERSET","").isEmpty())  "UTF-8" else propMap.get("INPUT_FILE_XMLRESPONSE_CHARACTERSET").get
    val  INPUT_FILE_XMLRESPONSE_PATH        :String =if(propMap.getOrElse("INPUT_FILE_XMLRESPONSE_PATH","").isEmpty())  s"$qclHome/input/response/" else propMap.get("INPUT_FILE_XMLRESPONSE_PATH").get
    val  INPUT_FILE_XMLRESPONSE_ROWTAG      :String =if(propMap.getOrElse("INPUT_FILE_XMLRESPONSE_ROWTAG","").isEmpty())  "RESPONSE" else propMap.get("INPUT_FILE_XMLRESPONSE_ROWTAG").get
    val  OUTPUT_FILE_REPORTS_DELIMETER      :String =if(propMap.getOrElse("OUTPUT_FILE_REPORTS_DELIMETER","").isEmpty())  "," else propMap.get("OUTPUT_FILE_REPORTS_DELIMETER").get
    val  OUTPUT_FILE_REPORTS_FORMAT         :String =if(propMap.getOrElse("OUTPUT_FILE_REPORTS_FORMAT","").isEmpty())  "csv" else propMap.get("OUTPUT_FILE_REPORTS_FORMAT").get
    val  OUTPUT_FILE_REPORTS_PATH           :String =if(propMap.getOrElse("OUTPUT_FILE_REPORTS_PATH","").isEmpty())  s"$qclHome/output/reports/" else propMap.get("OUTPUT_FILE_REPORTS_PATH").get
    val  OUTPUT_FILE_XMLREQUET_PATH         :String =if(propMap.getOrElse("OUTPUT_FILE_XMLREQUET_PATH","").isEmpty())  s"$qclHome/output/request/" else propMap.get("OUTPUT_FILE_XMLREQUET_PATH").get
    val  OUTPUT_FILE_XMLREQUET_ROOTTAG      :String =if(propMap.getOrElse("OUTPUT_FILE_XMLREQUET_ROOTTAG","").isEmpty())  "MESSAGE" else propMap.get("OUTPUT_FILE_XMLREQUET_ROOTTAG").get
    val  OUTPUT_FILE_XMLREQUET_ROWTAG       :String =if(propMap.getOrElse("OUTPUT_FILE_XMLREQUET_ROWTAG"," ").isEmpty())  "ACCOUNT" else propMap.get("OUTPUT_FILE_XMLREQUET_ROWTAG").get
    val  OUTPUT_FILE_XMLRESPONSE_PATH       :String =if(propMap.getOrElse("OUTPUT_FILE_XMLRESPONSE_PATH","").isEmpty())  s"$qclHome/output/response/" else propMap.get("OUTPUT_FILE_XMLRESPONSE_PATH").get
    val  OUTPUT_FILE_XMLRESPONSE_ROOTTAG    :String =if(propMap.getOrElse("OUTPUT_FILE_XMLRESPONSE_ROOTTAG","").isEmpty())  "MESSAGE" else propMap.get("OUTPUT_FILE_XMLRESPONSE_ROOTTAG").get
    val  OUTPUT_FILE_XMLRESPONSE_ROWTAG     :String =if(propMap.getOrElse("OUTPUT_FILE_XMLRESPONSE_ROWTAG","").isEmpty())  "ACCOUNT" else propMap.get("OUTPUT_FILE_XMLRESPONSE_ROWTAG").get
    val  OUTPUT_FILE_LOGS_PATH               :String =if(propMap.getOrElse("OUTPUT_FILE_LOGS_PATH","").isEmpty())  s"$qclHome/logs/" else propMap.get("OUTPUT_FILE_LOGS_PATH").get
     
                               
}
object ConfigParams {
    def setQCLConfigParams( qclHome :String):QCLConfigParams=
                    {
     val propMap=
                                     try
     {
        Source.fromFile(s"$qclHome/config/qcl_config.properties").getLines().filterNot(line => line.startsWith("#")).filter(line => line.contains("="))
        .map { line => // println(line)
        val tokens = line.split("=")
        (tokens(0).trim() -> (if (tokens.length >= 2) tokens(1).trim() else ""))
        }.toMap
     }
     catch{
     case e:Exception  =>
     println("************ Exception Caught in reading the Configuration File:"+s"$qclHome/config/qcl_config.properties")
     e.printStackTrace()
     Map[String,String]()
     }
     //val schemaFile=spark.sparkContext.textFile(input_schemafile).map(x=>x.split('|')).collect()
                                                                new QCLConfigParams(propMap ,qclHome)
                                }
               
  def setQCLHistConfigParams( histConfigFile :String):QCLHistConfigParams=
  {
    val propMap=
    try
    {
      Source.fromFile(histConfigFile).getLines().filterNot(line => line.startsWith("#")).filter(line => line.contains("="))
        .map { line => // println(line)
          val tokens = line.split("=")
          (tokens(0).trim() -> (if (tokens.length >= 2) tokens(1).trim() else ""))
        }.toMap
    }
    catch{
      case e:Exception  => println("************ Exception Caught in reading the Properties file:"+histConfigFile)
      e.printStackTrace()
      Map[String,String]()
    }
    //val schemaFile=spark.sparkContext.textFile(input_schemafile).map(x=>x.split('|')).collect()
   new QCLHistConfigParams(propMap)
  }
def printQCLConfigParams(params :QCLConfigParams):Unit =
                {
                  //val length=params.
                 
      //val schema = ScalaReflection.schemaFor[QCLInputparams].dataType.asInstanceOf[StructType]
      //schema.printTreeString
                    //println ("DELTA_TABLE_NAME_BASE : "+params.DELTA_TABLE_NAME_BASE)
      //println ("DELTA_TABLE_NAME_BASERAW : "+params.DELTA_TABLE_NAME_BASERAW)
      //println ("DELTA_TABLE_NAME_CONTROL : "+params.DELTA_TABLE_NAME_CONTROL)
      println ("DELTA_TABLE_PATH_BASE : "+params.DELTA_TABLE_PATH_BASE)
      //println ("DELTA_TABLE_PATH_REPORTING : "+params.DELTA_TABLE_PATH_REPORTING)
      //println ("DELTA_TABLE_PATH_SNAPSHOT : "+params.DELTA_TABLE_PATH_SNAPSHOT)
      println ("DELTA_TABLE_PATH_WORKING : "+params.DELTA_TABLE_PATH_WORKING)
      //println ("INPUT_FILE_HISTDATA_CHARACTERSET : "+params.INPUT_FILE_HISTDATA_CHARACTERSET)
      //println ("INPUT_FILE_HISTDATA_DELIMETER : "+params.INPUT_FILE_HISTDATA_DELIMETER)
      //println ("INPUT_FILE_HISTDATA_FORMAT : "+params.INPUT_FILE_HISTDATA_FORMAT)
      //println ("INPUT_FILE_HISTDATA_HEADER : "+params.INPUT_FILE_HISTDATA_HEADER)
      //println ("INPUT_FILE_HISTDATA_PARSINGMODE : "+params.INPUT_FILE_HISTDATA_PARSINGMODE)
      println ("INPUT_FILE_HISTDATA_PATH : "+params.INPUT_FILE_HISTDATA_PATH)
      //println ("INPUT_FILE_MANUALDATA_CHARACTERSET : "+params.INPUT_FILE_MANUALDATA_CHARACTERSET)
      //println ("INPUT_FILE_HISTDATA_DATEFORMAT : "+params.INPUT_FILE_HISTDATA_DATEFORMAT)
      //println ("INPUT_FILE_MANUALDATA_DATEFORMAT : "+params.INPUT_FILE_MANUALDATA_DATEFORMAT)
      //println ("INPUT_FILE_MANUALDATA_DELIMETER : "+params.INPUT_FILE_MANUALDATA_DELIMETER)
      //println ("INPUT_FILE_MANUALDATA_FORMAT : "+params.INPUT_FILE_MANUALDATA_FORMAT)
      //println ("INPUT_FILE_MANUALDATA_HEADER : "+params.INPUT_FILE_MANUALDATA_HEADER)
      //println ("INPUT_FILE_MANUALDATA_PARSINGMODE : "+params.INPUT_FILE_MANUALDATA_PARSINGMODE)
      //println ("INPUT_FILE_MANUALDATA_PATH : "+params.INPUT_FILE_MANUALDATA_PATH)
      //println ("INPUT_FILE_XMLREQUEST_CHARACTERSET : "+params.INPUT_FILE_XMLREQUEST_CHARACTERSET)
      println ("INPUT_FILE_XMLREQUEST_PATH : "+params.INPUT_FILE_XMLREQUEST_PATH)
      //println ("INPUT_FILE_XMLREQUEST_ROWTAG : "+params.INPUT_FILE_XMLREQUEST_ROWTAG)
      //println ("INPUT_FILE_XMLRESPONSE_CHARACTERSET : "+params.INPUT_FILE_XMLRESPONSE_CHARACTERSET)
      println ("INPUT_FILE_XMLRESPONSE_PATH : "+params.INPUT_FILE_XMLRESPONSE_PATH)
      //println ("INPUT_FILE_XMLRESPONSE_ROWTAG : "+params.INPUT_FILE_XMLRESPONSE_ROWTAG)
      //println ("OUTPUT_FILE_REPORTS_DELIMETER : "+params.OUTPUT_FILE_REPORTS_DELIMETER)
      //println ("OUTPUT_FILE_REPORTS_FORMAT : "+params.OUTPUT_FILE_REPORTS_FORMAT)
      println ("OUTPUT_FILE_REPORTS_PATH : "+params.OUTPUT_FILE_REPORTS_PATH)
      //println ("OUTPUT_FILE_XMLREQUET_PATH : "+params.OUTPUT_FILE_XMLREQUET_PATH)
      //println ("OUTPUT_FILE_XMLREQUET_ROOTTAG : "+params.OUTPUT_FILE_XMLREQUET_ROOTTAG)
      //println ("OUTPUT_FILE_XMLREQUET_ROWTAG : "+params.OUTPUT_FILE_XMLREQUET_ROWTAG)
      println ("OUTPUT_FILE_XMLRESPONSE_PATH : "+params.OUTPUT_FILE_XMLRESPONSE_PATH)
      //println ("OUTPUT_FILE_XMLRESPONSE_ROOTTAG : "+params.OUTPUT_FILE_XMLRESPONSE_ROOTTAG)
      //println ("OUTPUT_FILE_XMLRESPONSE_ROWTAG : "+params.OUTPUT_FILE_XMLRESPONSE_ROWTAG)
                }
  def printQCLHistConfigParams(params :QCLHistConfigParams):Unit =
                {
                  //val length=params.
    println("input_schemafilename      :"+params.INPUT_SCHEMAFILENAME      )
    println("input_datafilepath        :"+params.INPUT_DATAFILEPATH        )
    println("input_datafileformat      :"+params.INPUT_DATAFILEFORMAT      )
    println("input_datafileparsingmode :"+params.INPUT_DATAFILEPARSINGMODE )
    println("input_datafilecharcterset :"+params.INPUT_DATAFILECHARCTERSET )
    println("input_datafilename        :"+params.INPUT_DATAFILENAME        )
    println("input_datafiledelimeter   :"+params.INPUT_DATAFILEDELIMETER   )
    println("input_Source              :"+params.INPUT_SOURCE              )
    println("input_datafilelocation    :"+params.INPUT_DATAFILELOCATION    )
    println("input_schemafilelocation  :"+params.INPUT_SCHEMAFILELOCATION  )
    println("input_schemafilepath      :"+params.INPUT_SCHEMAFILEPATH      )
                }
 
}