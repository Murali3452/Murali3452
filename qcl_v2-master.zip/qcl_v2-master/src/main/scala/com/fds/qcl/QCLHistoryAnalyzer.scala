package com.fds.qcl

import org.apache.spark.sql.SparkSession
import io.delta.tables._
import io.delta._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.commons.io.FileUtils
import java.io.File
import org.apache.log4j._
import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
import utils.SimahRuleChecker._

object QCLHistoryAnalyzer {

  //historyAnalyzer(spark, params, log, RUN_DATE,FILE_NAME)
  //def historyAnalyzer(spark : SparkSession,FILE_NAME:String , params:utils.InputParams2, log:Logger): Unit = {
  def historyAnalyzer(spark: SparkSession, params: utils.QCLConfigParams, log: Logger, RUN_DATE: java.sql.Date, FILE_NAME: String): Unit = {
    Logger.getLogger("org").setLevel(Level.ERROR)
    val BaseTablePath = params.DELTA_TABLE_PATH_BASE //"C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/"
    val BaseHistTableName = params.DELTA_TABLE_NAME_BASE // "base_hist"
    val BaseTable = BaseTablePath + BaseHistTableName

    try {
      import spark.implicits._
      val currentTime = new java.sql.Timestamp(System.currentTimeMillis())
      val hist_base_DF = spark.sql(s"SELECT * FROM delta.`$BaseTable`")
      //hist_base_DF.show()
      //          log.info(hist_base_DF.show() )
      //Test
      hist_base_DF.groupBy('CurrentStatus, 'ProductStatus, 'DefaultStatus).agg(count('AccountNumber).as("TotalAccts")).show()
      hist_base_DF.write.format("delta").mode("overwrite").save(BaseTablePath + BaseHistTableName)
      // val HistBaseDS=hist_base_DF.as[HistBaseCaseClass]
      val HistBaseDS = spark.sql(s"SELECT * FROM delta.`$BaseTablePath$BaseHistTableName`").as[HistBaseCaseClass]
      //    log.info(s"Total records loaded in base history table $BaseHistTableName : "+ HistBaseDS.count())
      //    HistBaseDS.printSchema()
      //println("TestFlow: function call def:getHistoryDQReport")
      //Funcation call

      val PFProductGroup = List("ADFL", "CDL", "DPLN", "DSTFM", "EDUF", "MGLD", "PLN", "RPLN", "RSFM", "SFB", "SME", "STFM", "TPLN") //ProductGroupPersonalLoan PLN PRDGRPPLN
      val CCProductGroup = List("CDC", "CHC", "CRC", "LCRC", "POD", "TOD") //Product Group PCR Credit Cards CRC                PRDGRPPCR
      val ALProductGroup = List("RSMEI", "RSMEL", "RVIN", "RVLS", "SMEI", "SMEL", "VEHE", "VESP", "VIN", "VLS", "VRA") //Product Group Vehicle               VLB        PRDGRPVEH
      val MTGProductGroup = List("AMTG", "AQAR", "EMTG", "IMTG", "INPR", "MMTG", "MSKN", "MTG", "OMTG", "RERA", "RMSKN", "RMTG", "SMTG", "TMTG") //ProductGroupMortgage           MTG      PRDGRPMTG

      import spark.implicits._

      val aggDF = spark.sql(s"SELECT * FROM delta.`$BaseTablePath$BaseHistTableName`").toDF()
        .withColumn("Rundate", lit(RUN_DATE).cast(DateType))
        //.withColumn("OS_BALANCE", when( 'DefaultStatus.isNotNull ,'DefaultOutStandingAmount ).otherwise('OutStandingBalance))
        .withColumn("OS_BALANCE", when('ProductStatus === "W", 'DefaultOutStandingAmount).otherwise('OutStandingBalance))
        //.withColumn("PAST_DUE", when( 'DefaultStatus.isNull ,'PastDueBalance ).otherwise(lit(0)))
        .withColumn("PAST_DUE", when('CurrentStatus === "ACTIVE" || 'CurrentStatus === "SUSPENDED", 'PastDueBalance).otherwise(lit(0)))
        .withColumn("DEFAULT_ORIGINAL_AMOUNT", when('CurrentStatus === "SETTLED" || 'CurrentStatus === "WRITTENOFF", 'DefaultOriginalAmount).otherwise(lit(0)))
        .withColumn("ProductGroup", when(('ProductType).isin(PFProductGroup: _*), lit("PF"))
          .when('ProductType.isin(MTGProductGroup: _*), lit("RF"))
          .when('ProductType.isin(ALProductGroup: _*), lit("AL"))
          .when('ProductType.isin(CCProductGroup: _*), lit("CC"))
          .otherwise('ProductType))
        .groupBy("Rundate", "ProductGroup", "ProductType", "CurrentStatus")
        .agg(
          count("AccountNumber").as("Total_accts_count"),
          sum("OS_BALANCE").cast(DecimalType(25, 0)).alias("Total_OS_amount"),
          sum("OriginalAmount").cast(DecimalType(25, 0)).alias("Total_loan_amount"),
          //sum("DefaultOriginalAmount").cast(DecimalType(25,0)).alias("Total_Defaulted_amount"),
          sum("DEFAULT_ORIGINAL_AMOUNT").cast(DecimalType(25, 0)).alias("Total_Defaulted_amount"),
          //sum("PastDueBalance").cast(DecimalType(25,0)).alias("Total_PastDue_amount")
          sum("PAST_DUE").cast(DecimalType(25, 0)).alias("Total_PastDue_amount"))
      /*
                                     val aggDF=spark.sql(s"SELECT * FROM delta.`$BaseTablePath$BaseHistTableName`").toDF()
                         .withColumn("Rundate", lit(RUN_DATE).cast(DateType))
                         .withColumn("ProductGroup", when('ProductType.isin(PFProductGroup),"PF")
                                                     .when('ProductType.isin(MTGProductGroup),"RF")
                                                     .when('ProductType.isin(ALProductGroup),"AL")
                                                     .when('ProductType.isin(CCProductGroup),"CC")
                                                     .otherwise('ProductType))
                        //.withColumn("OS_BALANCE", when( 'DefaultStatus.isNotNull ,'DefaultOutStandingAmount ).otherwise('OutStandingBalance))
                        //.groupBy("ProductType","CurrentStatus","PaymentStatus")
                        .groupBy("Rundate","ProductType","CurrentStatus")
                        .agg(
                            count("AccountNumber").as("Total_accts_count"),
                            sum("OutStandingBalance").cast(DecimalType(25,0)).alias("Total_OS_amount"),
                            sum("OriginalAmount").cast(DecimalType(25,0)).alias("Total_loan_amount"),
                            sum("DefaultOriginalAmount").cast(DecimalType(25,0)).alias("Total_Defaulted_amount"),
                            sum("PastDueBalance").cast(DecimalType(25,0)).alias("Total_PastDue_amount")
                            )
                                          */
      try {
        log.info("Usage : Start : Saving the Portfolio_Summary_Report ")
        val outputPath = params.OUTPUT_FILE_REPORTS_PATH + "Portfolio_Summary_Report" + RUN_DATE + ".xlsx"
        aggDF.write.format("com.crealytics.spark.excel")
          //.option("sheetName", "Sheet_1")
          //.option("dataAddress","Sheet_1")
          //.option("useHeader", "true")
          .option("header", "true")
          //.option("treatEmptyValuesAsNulls", "false")
          .option("dateFormat", "MM/DD/yyyy")
          //  .option("addColorColumns", "False")
          .mode("overwrite")
          .save(outputPath)
        log.info("Usage : End : Saving the Portfolio_Summary_Report ")
      } catch {
        case e: Exception =>
          log.error("Error : Exception caught while saving portfolio Summary report ")
          log.error(e)
      }

      val HistDQDS = for {
        row <- HistBaseDS
        //getInvalidRecords
        val rows = getHistoryDQReport(
          row.AccountNumber,
          row.ProductType,
          row.SalaryAssignment,
          row.SecurityType,
          row.PaymentFrequency,
          row.IssueDate,
          row.ExpiryDate,
          row.AsOfDate,
          row.CloseDate,
          row.ProductStatus,
          row.PaymentStatus,
          row.Tenure,
          row.InstallmentAmount,
          row.OriginalAmount,
          row.OutStandingBalance,
          row.LastCycleID,
          row.LastAmountPaid,
          row.LastPaymentDate,
          row.NextPaymentDate,
          row.PastDueBalance,
          row.DefaultStatus,
          row.DefaultLoadDate,
          row.DefaultOriginalAmount,
          row.DefaultOutStandingAmount,
          row.DefaultStatusDate,
          row.DefaultChangeDate,
          row.CIUploadDate,
          row.CIUpdateDate,
          row.CurrentStatus,
          row.ReportedDate,
          row.DPR,
          row.DPA,
          row.RJC)
      } yield rows
      val HistDQDF = HistDQDS.filter(col("ValidFlag") =!= ("VALID")).toDF()
      //println("TestFlow: return from function , got HistDQDS and filterd output to HistDQDF")
      //HistDQDF.printSchema()
      //log.info(HistDQDF.show())
      try {
        val histDQSummaryDF = HistDQDF.groupBy('ErrorIDs).agg(count('AccountNumber).as("TotalAccts"))
        val tmpFolderName = BaseTablePath + "HistDQReport_Summary"
        val outputPath = params.OUTPUT_FILE_REPORTS_PATH
        val newfileName = "HistDQReport_Summary_" + RUN_DATE + ".csv"
        log.info("Usage : Start : Saving the History Data Quality Summary report")
        histDQSummaryDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(tmpFolderName)
        moveFiles(tmpFolderName, outputPath, newfileName)
        log.info("Usage : End : Saved the file with name : " + outputPath + newfileName)
      } catch {
        case e: Exception =>
          log.error("Error : Exception caught while saving SummaryHistDQReport ")
          log.error(e)
      }

      try {
        val HistDQReport = HistDQDF.join(hist_base_DF, Seq("AccountNumber", "ProductType"), "inner")
        val tmpFolderName = BaseTablePath + "HistDQReport_Detail"
        val outputPath = params.OUTPUT_FILE_REPORTS_PATH
        val newfileName = "HistDQReport_Detail_" + RUN_DATE + ".csv"
        log.info("Usage : Start : Saving the History Data Quality Detail report")
        HistDQReport.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(tmpFolderName)
        moveFiles(tmpFolderName, outputPath, newfileName)
        log.info("Usage : End : Saved the file with name : " + outputPath + newfileName)
      } catch {
        case e: Exception =>
          log.error("Error : Exception caught while saving DetailHistDQReport ")
          log.error(e)
      }
    } catch {
      case e: Exception =>
        log.error("Error : Exception caught in base history table load block")
        log.error(e)
    }

  }
}