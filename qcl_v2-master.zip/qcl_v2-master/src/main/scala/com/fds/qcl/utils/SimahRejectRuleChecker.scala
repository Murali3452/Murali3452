package com.fds.qcl.utils

import SimahCaseClasses._

import java.text.DecimalFormat
import java.sql.Timestamp
import java.sql.Date
import org.apache.spark.sql.functions._
import org.apache.spark._
import org.apache.spark.SparkContext._
import scala.util.Try
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import java.util.regex.Pattern
import scala.util.matching.Regex
import scala.io.Source
import scala.collection.mutable.LinkedHashSet
import scala.collection.mutable.ArrayBuffer
import java.time.Period
import org.apache.spark.sql.expressions.UserDefinedFunction



object SimahRejectRuleChecker
{
	//val conf = new SparkConf().setAppName("SimahRuleChecker").setMaster("local[*]").set("spark.testing.memory", "2147480000").set("spark.kryoserializer.buffer.max", "512") //local
	//		val spark = SparkSession.builder.appName("SimahRuleChecker_App").config(conf).getOrCreate() //local
			val PFProductGroup=List("ADFL","CDL","DPLN","DSTFM","EDUF","MGLD","PLN","RPLN","RSFM","SFB","SME","STFM","TPLN") //ProductGroupPersonalLoan PLN PRDGRPPLN
			val CCProductGroup=List("CDC","CHC","CRC","LCRC","POD","TOD") //Product Group PCR Credit Cards CRC                PRDGRPPCR
			val ALProductGroup=List("RSMEI","RSMEL","RVIN","RVLS","SMEI","SMEL","VEHE","VESP","VIN","VLS","VRA") //Product Group Vehicle               VLB        PRDGRPVEH
			val MTGProductGroup=List("AMTG","AQAR","EMTG","IMTG","INPR","MMTG","MSKN","MTG","OMTG","RERA","RMSKN","RMTG","SMTG","TMTG") //ProductGroupMortgage           MTG      PRDGRPMTG
			val PHProductGroup=List        ("ELCB","LND","MBL","NET","RCSR","WAT") //Product Group PH                              PRDGRPPH
			val RNPProductGroup=List     ("MBL","PLN","WAT") // Product Group Risk of Non-payment    PRDGRPSU
			
			
	
	// Start of function getRejectionRecords
	def getRejectionRecords(
			AccountNumber:  String ,
			IssueDate:  java.sql.Date ,
			ProductType:  String ,
			OriginalAmount:  Option[Double] ,
			SalaryAssignmentFlag:  String ,
			ExpiryDate:  java.sql.Date ,
			ProductStatus:  String ,
			InstallmentAmount:  Option[Double] ,
			PaymentFrequency:  String ,
			Tenure:  Option[Integer] ,
			SecurityType:  String ,
			//NumberOfApplicants:  Option[Integer] ,
			LastCycleID:  Option[Integer] ,
			LastPaymentDate:  java.sql.Date ,
			LastAmountPaid:  Option[Double] ,
			PaymentStatus:  String ,
			OutStandingBalance:  Option[Double] ,
			PastDueBalance:  Option[Double]  ,
			AsOfDate:  java.sql.Date ,
			NextPaymentDate:  java.sql.Date ,
			IDType:  String ,
			IDNumber:  String ,
			//NEW_ACCT_FLAG:  Boolean,
			H_IssueDate:  java.sql.Date ,
			H_ProductType:  String ,
			H_OriginalAmount:  Option[Double] ,
			H_SalaryAssignmentFlag:  String ,
			H_ExpiryDate:  java.sql.Date ,
			H_ProductStatus:  String ,
			H_InstallmentAmount:  Option[Double] ,
			H_PaymentFrequency:  String ,
			H_Tenure:  Option[Integer] ,
			H_SecurityType:  String ,
			H_LastCycleID:  Option[Integer] ,
			H_LastPaymentDate:  java.sql.Date ,
			H_LastAmountPaid:  Option[Double] ,
			H_PaymentStatus:  String ,
			H_OutstandingBalance:  Option[Double] ,
			H_PastDueBalance:  Option[Double]  ,
			H_AsOfDate:  java.sql.Date ,
			H_NextPaymentDate:  java.sql.Date ,
			H_IDType:  String ,
			H_IDNumber:  String ,
			HIST_RUN_NO:  String ,
			H_NEW_ACCT_FLAG:  String
			): RejectRecords_V_01 =
		{
				var validFlag = "VALID"
						var ErrorIds = ""
						var ErroeMsgs = ""
						var NEW_ACCT_FLAG=  if(H_LastCycleID == null || H_LastCycleID.isEmpty)  true else false
						// For new acconts check manadory fields
						if (NEW_ACCT_FLAG )//|| H_LastCycleID==null || H_LastCycleID.isEmpty)
						{
							//OriginalAmount
							if(OriginalAmount == None || OriginalAmount.get == 0 )
							{
								validFlag = "ERROR"
										ErrorIds = ErrorIds + "ERR_ORGA_01 |"
										ErroeMsgs = ErroeMsgs + "Error : OriginalAmount is mandatory for all new accounts and it shoud not be zero|"
							}
							//SalaryAssignmentFlag
							if(SalaryAssignmentFlag == null || SalaryAssignmentFlag.isEmpty() )
							{
								validFlag = "ERROR"
										ErrorIds = ErrorIds + "ERR_SALF_01 |"
										ErroeMsgs = ErroeMsgs + "Error : SalaryAssignmentFlag is mandatory for all new accounts |"
							}
							//PaymentFrequency
							if(PaymentFrequency == null || PaymentFrequency.isEmpty()  )
							{
								validFlag = "ERROR"
										ErrorIds = ErrorIds + "ERR_PFRQ_01 |"
										ErroeMsgs = ErroeMsgs + "Error : PaymentFrequency is mandatory for all new accounts |"
							}
							//SecurityType
							if(SecurityType == null || SecurityType.isEmpty())
							{
								validFlag = "ERROR"
										ErrorIds = ErrorIds + "ERR_STYP_01 |"
										ErroeMsgs = ErroeMsgs + "Error : SecurityType is mandatory for all new accounts |"
							}
							/* : TO Check , not there in actual rejection file
                                                                  //LastAmountPaid This element must be numeric. For new CI’s it must be zero.
                                                                  if( LastAmountPaid != None && LastAmountPaid.get != 0 )
                                                                  {
                                                                                                 validFlag = "ERROR"
                                                                                                 ErrorIds = ErrorIds + "ERR_APYD_01 |"
                                                                                                 ErroeMsgs = ErroeMsgs + "Error : LastAmountPaid must be zero for all new accounts |"
                                                                  }
							 * */
							//Tenure is mandatory for the new Credit Instruments, if the provided Product Type is: In the Personal Finance or Product Type = MIS, or Product Type = PE
							//PFProductGroup.contains(ProductType) || ALProductGroup.contains(ProductType) || MTGProductGroup.contains(ProductType)  Product Type = MIS, or Product Type = PE Else it is Optional
							if(PFProductGroup.contains(ProductType) || ProductType.equalsIgnoreCase("MIS") || ProductType.equalsIgnoreCase("PE") )
							{
								//Tenure is mandatory for above conditions
								if(Tenure == None || Tenure.get==0 )
								{
									validFlag = "ERROR"
											ErrorIds = ErrorIds + "ERR_TENR_01 |"
											ErroeMsgs = ErroeMsgs + s"Error : Tenure is mandatory for all new accounts with  $ProductType  producttype |"
								}
								//Tenure is mandatory for above conditions
								if(ExpiryDate == None || ExpiryDate == null )
								{
									validFlag = "ERROR"
											ErrorIds = ErrorIds + "ERR_EXPDT_01 |"
											ErroeMsgs = ErroeMsgs + s"Error : ExpiryDate is mandatory for all new accounts with  $ProductType  producttype |"
								}
							}
							//Product Expiry Date must not be provided for the Credit Instruments where Product Type is:  In the Phone products group; or In the Credit Card products group
							if(CCProductGroup.contains(ProductType) || PHProductGroup.contains(ProductType) )
							{
								if(ExpiryDate != null )
								{
									validFlag = "ERROR"
											ErrorIds = ErrorIds + "ERR_EXPDT_02 |"
											ErroeMsgs = ErroeMsgs + s"Error : ExpiryDate must not be provided for the Credit Instruments where Product Type is :  $ProductType |"
								}
							}
							//IssueDate
							if(IssueDate == None || IssueDate == null )
							{
								validFlag = "ERROR"
										ErrorIds = ErrorIds + "ERR_ISDT_01 |"
										ErroeMsgs = ErroeMsgs + "Error : IssueDate is mandatory for all new accounts |"
							}
						} // End if new accounts only
				// PastDuebalance If the Payment Status (AACS) is N, Q, 0, F, or C, value must be 0 or less, otherwise it should be more than 0 (which includes W)
				val payStatList=List( "N", "Q", "0", "F", "C")
						if(payStatList.contains(PaymentStatus))
						{
							if(PastDueBalance.get  >  0)
							{
								validFlag = "ERROR"
										ErrorIds = ErrorIds + "ERR_PDBAL_01 |"
										ErroeMsgs = ErroeMsgs + s"Error : PastDueBalance must  be 0 or less for PaymentStatus:   $PaymentStatus |"
							}
						}
						else if(PastDueBalance.get < 0)
						{
							validFlag = "ERROR"
									ErrorIds = ErrorIds + "ERR_PDBAL_02 |"
									ErroeMsgs = ErroeMsgs + s"Error : PastDueBalance should be more than 0  for PaymentStatus:   $PaymentStatus |"
						}
				//NextPaymentDate If account is defaulted or closed then date should be blank
				if((ProductStatus.equalsIgnoreCase("C") || ProductStatus.equalsIgnoreCase("W")) && NextPaymentDate != null)
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_NPDT_01 |"
							ErroeMsgs = ErroeMsgs + "Error :  If account is defaulted or closed then NextPaymentDate should be blank|"
				}
				/*
                                                 //NumberOfApplicants Integer 2 >= 1
                                                  if(NumberOfApplicants == None || NumberOfApplicants.get <= 0)
                                                 {
                                                   validFlag = "ERROR"
                                                                 ErrorIds = ErrorIds + "ERR_NAPL_01 |"
                                                                 ErroeMsgs = ErroeMsgs + "Error : NumberOfApplicants should be more than or equal to one for all products |"
                                                 }
				 */
				//OutstandingBalance must be zero if the Credit Instrument Product Status is Closed.
				if(ProductStatus.equalsIgnoreCase("C") &&  OutStandingBalance.get != 0)
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_OSBAL_01 |"
							ErroeMsgs = ErroeMsgs + "Error :  OutstandingBalance must be zero for closed product status C|"
				}
				//B2B0309 00309 Outstanding balance too low for Credit Instrument to be considered default Reference MasterLookupDoc 3.41             System Control file          (SYSCONM0)
				if(H_ProductStatus != null && ! H_ProductStatus.isEmpty())
				{
					if(ProductStatus.equalsIgnoreCase("W") &&   ! (H_ProductStatus.equalsIgnoreCase("W")) &&  OutStandingBalance.get < 500)
					{
						validFlag = "ERROR"
								ErrorIds = ErrorIds + "ERR_OSBAL_01      |"
								ErroeMsgs = ErroeMsgs + s"Error :  Outstanding balance $OutStandingBalance.get is too low for Credit Instrument to be considered default|"
					}
				}
				//ProductStatus If Code = A or S, the latest Cycle Record Status for the CI must NOT be a C or W
				if(ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("S"))
				{
					if(PaymentStatus.equalsIgnoreCase("C") || PaymentStatus.equalsIgnoreCase("W"))
					{
						validFlag = "ERROR"
								ErrorIds = ErrorIds + "ERR_PRDST_01 |"
								ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
					}
				}
				//If Code = C, the latest Cycle Record Status for the CI must be C
				if(ProductStatus.equalsIgnoreCase("C") && !(PaymentStatus.equalsIgnoreCase("C")))
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PRDST_02 |"
							ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
				}
				//If Code = W, the latest Cycle Record Status for the CI must be W
				if(ProductStatus.equalsIgnoreCase("W") && !(PaymentStatus.equalsIgnoreCase("W")))
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PRDST_03 |"
							ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the PaymentStatus can't be $PaymentStatus |"
				}
				//If Code = L then the Product Type must be in Product group PRDGRPPCR.
				if(ProductStatus.equalsIgnoreCase("L") && !(CCProductGroup.contains(ProductType)))
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PRDST_04 |"
							ErroeMsgs = ErroeMsgs + s"Error : For ProductStatus $ProductStatus  the Product Type must be in Product group PRDGRPPCR / CCR |"
				}
				//A Credit Instrument Product Sates may be C (Closed) only if the outstanding balance is zero.
				if(ProductStatus.equalsIgnoreCase("C") &&  OutStandingBalance.get != 0)
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PRDST_05 |"
							ErroeMsgs = ErroeMsgs + "Error : A Credit Instrument Product Status can be C (Closed) only if the outstanding balance is zero. |"
				}
				//Product Status ‘X’ (Default Only) cannot be supplied with this service.
				if(ProductStatus.equalsIgnoreCase("X") )
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PRDST_05 |"
							ErroeMsgs = ErroeMsgs + "Error : Product Status ‘X’ (Default Only) cannot be supplied with this service |"
				}
				//######## PaymentStatus Rules
				//If a cycle is received with status ‘W’, but a later cycle exists with an open status, an error condition occurs
				if(H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("W") )
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PAYST_01 |"
							ErroeMsgs = ErroeMsgs + "Error : The CI must not be included in RegularFile as previous status was W (Default) |"
				}
				//Payment Status can be F if the Product Type is:1. in Phone products group; i.e. on Table PRDGRPPH or Credit Card products group; i.e. on Table PRDGRPPCR
				if( !( CCProductGroup.contains(ProductType) || PHProductGroup.contains(ProductType) ) && PaymentStatus.equalsIgnoreCase("F") )
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PAYST_02 |"
							ErroeMsgs = ErroeMsgs + s"Error : Payment Status can't be F for this product type: $ProductType|"
				}
				//For new and existing CIs, new or existing cycles - If Credit Instrument Product Status = A or L or S then the latest cycle Payment Status cannot be C or W
				if(ProductStatus.equalsIgnoreCase("A") || ProductStatus.equalsIgnoreCase("L") ||  ProductStatus.equalsIgnoreCase("S"))
				{
					if(PaymentStatus.equalsIgnoreCase("C") || PaymentStatus.equalsIgnoreCase("W"))
					{
						validFlag = "ERROR"
								ErrorIds = ErrorIds + "ERR_PAYST_03 |"
								ErroeMsgs = ErroeMsgs + "Error : Product Status = A or L or S then the latest cycle Payment Status cannot be C or W |"
					}
				}
				//If the latest cycle status = C loading of new cycle(s) will not be allowed, error message will be returned. Latest cycle status C cannot be changed to any other value. (AD 9978)
				if(H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("C") )
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PAYST_04 |"
							ErroeMsgs = ErroeMsgs + s"Error :  Payment Status cannot be changed to this value $PaymentStatus as previous status was C (Closed) |"
				}
				//Payment Status can be R only for the credit instruments in the product group Risk of Non-payment PRDGRPSU
				if( !( RNPProductGroup.contains(ProductType) ) && PaymentStatus.equalsIgnoreCase("R") )
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PAYST_05 |"
							ErroeMsgs = ErroeMsgs + "Error : Payment Status can be R only for the credit instruments in the product group Risk of Non-payment PRDGRPSU|"
				}
				//Payment status R is valid only for the CI where product status is S
				if(   PaymentStatus.equalsIgnoreCase("R") &&  ! (ProductStatus.equalsIgnoreCase("S")))
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PAYST_06 |"
							ErroeMsgs = ErroeMsgs + "Error : Payment status R is valid only for the CI where product status is S|"
				}
				//If the payment status R provided, value in the Outstanding Balance (ACUB) must be < 500.00
				if(  PaymentStatus.equalsIgnoreCase("R") &&  (OutStandingBalance == None || OutStandingBalance.get >= 500) )
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PAYST_07 |"
							ErroeMsgs = ErroeMsgs + "Error : For Payment status R Outstanding Balance  must be < 500.00|"
				}
				//Payment status R may be loaded only of the previous most recent cycle payment status (in the database) is 6
				if(PaymentStatus.equalsIgnoreCase("R") &&    H_PaymentStatus != null && !(H_PaymentStatus.isEmpty()) && H_PaymentStatus.equalsIgnoreCase("6") )
				{
					validFlag = "ERROR"
							ErrorIds = ErrorIds + "ERR_PAYST_08 |"
							ErroeMsgs = ErroeMsgs + "Error : Payment status R may be loaded only if the previous most recent cycle payment status is 6 |"
				}
				// var VLSAccountNumber = if(AccountNumber.startsWith("6666")) "66".concat(AccountNumber) else AccountNumber
				new RejectRecords_V_01(
						AccountNumber,
						ProductType,
						validFlag,
						ErrorIds,
						ErroeMsgs)
		} 
	//End of function getRejectionRecords
	
	  def getDefaultRejectionRecords(row: DefaultRequestPlusHistCaseClass): RejectRecords_V_01 =
    {
    
      
      var validFlag = "VALID"
      var ErrorIds = ""
      var ErroeMsgs = ""
      //var NEW_ACCT_FLAG=  if(H_LastCycleID == null || H_LastCycleID.isEmpty)  true else false
 
      if (row.OutStandingBalance.getOrElse(None) == None) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_DFBAL_01 |"
        ErroeMsgs = ErroeMsgs + "Error :  DefaultOutstandingBalance must be provided |"
      }
 
      if (row.DefaultStatus.equalsIgnoreCase("FS") && row.OutStandingBalance.get != 0) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_DFBAL_02 |"
        ErroeMsgs = ErroeMsgs + "Error :  DefaultOutstandingBalance must be zero for Fully Settled loans |"
      }
     
      val defStsList=List("OS","FS","RS","NS","PP")
     
      if ( row.H_DefaultStatus==null ||row.H_DefaultStatus.equalsIgnoreCase("") ||   row.H_DefaultStatus.isEmpty() ||  !(defStsList.contains(row.H_DefaultStatus)) )
      {
        val pst=row.H_ProductStatus
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_DFSTS_01 |"
        ErroeMsgs = ErroeMsgs + s"Error :  Default reference is not exists for this Account , cannot maintain writeoff , existing product status is $pst | "
      }
     
      if (row.DefaultStatus.equalsIgnoreCase("FS") &&  row.H_DefaultStatus!=null && row.H_DefaultStatus.equalsIgnoreCase("FS")) {
        validFlag = "ERROR"
        ErrorIds = ErrorIds + "ERR_DFSTS_02 |"
        ErroeMsgs = ErroeMsgs + "Error :  Default record is already 'FS' |"
      }
      // var VLSAccountNumber = if(AccountNumber.startsWith("6666")) "66".concat(AccountNumber) else AccountNumber
 
      new RejectRecords_V_01(
        row.AccountNumber,
        row.ProductType,
        validFlag,
        ErrorIds,
        ErroeMsgs)
    } 
   //End of function getDefaultRejectionRecords
}