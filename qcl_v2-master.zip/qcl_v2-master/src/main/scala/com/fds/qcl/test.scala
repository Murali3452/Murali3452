package com.fds.qcl

import org.apache.spark.sql.SparkSession
import io.delta.tables._
import io.delta._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.commons.io.FileUtils
import java.io.File
import org.apache.log4j._

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions._
import utils.SimahRuleChecker._
////#import utils.CBDataValidatorParams_V1_1._
import utils.QCLInputParams._
object test {
  def main(args: Array[String]): Unit = {
			Logger.getLogger("org").setLevel(Level.ERROR)
			// Create Spark Conf
			val spark = SparkSession
			.builder()
			.appName("DeltaLakeDataValidator")
			.master("local[*]")
			.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
			.config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
			//#.config("spark.sql.warehouse.dir", "C:\\Bigdata\\warehouse\\deltatable_sqlpaths2")
			//  .config("spark.sql.warehouse.dir", "E:\\Murali\\bigdata_folder\\DataProfiling\\deltalake\\warehouse\\deltatable_sqlpaths2")
			.getOrCreate()
			
			
			
				val BaseTablePath= "C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/"
			val BaseHistTableName="base_hist"
			val BaseHistRawTableName="base_hist_raw"
			val control_table="C:/Bigdata/QCL_TESTRUN/deltalake/base/exe_control"
			
			val base_table="C:/Bigdata/QCL_TESTRUN/deltalake/base/base_hist"
			
			spark.sql(s"DELETE FROM delta.`$control_table` where key1='REG0013170PLN'")
			
			//System.exit(0)
			
			val deltaTable = DeltaTable.forPath(spark, base_table)
			deltaTable.history().show(500,false)
			
			val delta_table_path = "C:/Bigdata/QCL_TESTRUN/deltalake/base/base_hist"
			val delta_table_path2 = "C:/Bigdata/QCL_TESTRUN/deltalake/base/base_hist2"
      //val df = spark.read.format("delta").option("versionAsOf", 1).load(delta_table_path)
      //df.write.format("delta").mode("overwrite").save(delta_table_path2)
      
      val df2 = spark.read.format("delta").load(delta_table_path2)
      df2.write.format("delta").mode("overwrite").save(delta_table_path)
      
      
      deltaTable.history().show(500,false)
      //df.show()
      //spark.sql(s"SELECT * FROM delta.`$delta_table_path2`").show()
			//deltaTable.
			//spark.sql(s"SELECT * FROM delta.`$BaseTablePath$BaseHistTableName`").show()
			spark.sql(s"DELETE FROM delta.`$control_table` where key1='REG0013170PLN'")
			
  }
  
}