package com.fds.qcl

import org.apache.spark.sql.SparkSession
import io.delta.tables._
import io.delta._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.commons.io.FileUtils
import java.io.File
import org.apache.log4j._

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
import utils.SimahRuleChecker._
import utils.ConfigParams._




object QCLInitializer
{

def setQCLInitializer(spark : SparkSession,params:utils.QCLConfigParams,log:Logger, RUN_DATE:java.sql.Date,FILE_NAME:String  ): Unit = {

//Logger.getLogger("org").setLevel(Level.ERROR)
val BaseTablePath= params.DELTA_TABLE_PATH_BASE //"C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/"
val BaseHistTableName=params.DELTA_TABLE_NAME_BASE // "base_hist"

log.info("#############QCLInitializer started #####################")
//Start of run control table creation block
val controlTableName=params.DELTA_TABLE_NAME_CONTROL //"exe_control_table"
val controlTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$controlTableName` (
					|KEY1 STRING,
					|KEY2 STRING,
					|FILENAME STRING,
					|RUNDATE DATE,
					|RUNTIMESTAMP TIMESTAMP,
					|RUNNUMBER INT,
					|FILETYPE STRING,
					|FILEPRODUCT STRING,
					|COUNT_INFILE_REC INT,
					|COUNT_OUTFILE_REC INT,
					|COUNT_REJ_SDVL INT,
					|COUNT_REJ_SIMAH INT,
					|COUNT_REJ_TOTAL INT,
					|COUNT_REJ_EXTRA INT,
					|COUNT_REJ_MISSING INT,
					|COUNT_ACCTS_NEW INT,
					|COUNT_DQ_REC INT,
					|RESP_STS_SDVL STRING,
					|RESP_STS_SIMAH STRING
					)  USING DELTA""".stripMargin
					//
	val insertSql=s"""INSERT INTO delta.`$BaseTablePath$controlTableName` VALUES
	('DEF0000021PLN','DEFPLN','',null,null,21,'DEF','PLN', 0,0,0,0,0,0,0,0,0,'OK','OK') ,
	|('DEF0000022CRC','DEFCRC','',null,null,22,'DEF','CRC', 0,0,0,0,0,0,0,0,0,'OK','OK') ,
	|('DEF0000023VLS','DEFVLS','',null,null,23,'DEF','VLS', 0,0,0,0,0,0,0,0,0,'OK','OK') ,
	|('REG0000011PLN','REGPLN','',null,null,11,'REG','PLN', 0,0,0,0,0,0,0,0,0,'OK','OK'),
	|('REG0000012CRC','REGCRC','',null,null,12,'REG','CRC', 0,0,0,0,0,0,0,0,0,'OK','OK'),
	|('REG0000013VLS','REGVLS','',null,null,13,'REG','VLS', 0,0,0,0,0,0,0,0,0,'OK','OK')""".stripMargin
	//Insert records in to control table
	// spark.sql(insertSql)                    
try 
{
	val tablePath = new File(BaseTablePath)
	if (tablePath.exists())
	{
  try
  {
	println("Creating  execution control table in path: "+ s"$BaseTablePath"  )
	log.info("Creating  execution control table in path: "+ s"$BaseTablePath")
	spark.sql(controlTableCreateSql)
	println(s"Execution control table : $controlTableName  created")
	log.info(s"Execution control table : $controlTableName  created")
	spark.sql(insertSql)
	println(s"Inserted initial records in execution control table  : $controlTableName")
	log.info(s"Inserted initial records in execution control table  : $controlTableName")
  }
  catch{
	case e:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
	println("Table: "+ s"$BaseTablePath$controlTableName" + " is already Exists , Skipping control table creation step ...")
	log.warn("Table: "+ s"$BaseTablePath$controlTableName" + " is already Exists , Skipping control table creation step ...")
	   case e: Exception =>
		 println("Exception caught while creating Execution control table")
		 log.error("Exception caught while creating Execution control table")
		 e.printStackTrace()
}
}
else
{
				println("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
				println("Usage: Re-execute the program by changing  control table path value in configuration file ..")
				log.error("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
				log.info("Re-execute the program by changing  control table path value in configuration file ..")
				//System.exit(1)
}
}
catch {

// println("Usage: Re-execute the program by changing  control table name value in parameter file ..")
//System.exit(1)
case e: Exception =>
println("Error : Exception caught in control table creation block")
log.error("Exception caught in control table creation block")
log.error(e)
}
//End of run control table creation block
val baseTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$BaseHistTableName` (
								|AccountNumber STRING,
								|ProductType STRING,
								|SalaryAssignment STRING,
								|SecurityType STRING,
								|PaymentFrequency STRING,
								|IssueDate Date,
								|ExpiryDate Date,
								|AsOfDate Date,
								|CloseDate Date,
								|ProductStatus STRING,
								|PaymentStatus STRING,
								|Tenure INT,
								|InstallmentAmount DOUBLE,
								|OriginalAmount DOUBLE,
								|OutStandingBalance DOUBLE,
								|LastCycleID INT,
								|LastAmountPaid DOUBLE,
								|LastPaymentDate Date,
								|NextPaymentDate Date,
								|PastDueBalance DOUBLE,
								|DefaultStatus STRING,
								|DefaultLoadDate Date,
								|DefaultOriginalAmount DOUBLE,
								|DefaultOutStandingAmount DOUBLE,
								|DefaultStatusDate Date,
								|DefaultChangeDate Date,
								|CIUploadDate Date,
								|CIUpdateDate Date,
								|CurrentStatus STRING,
								|ReportedDate Date,
								|AcceptedDate Date,
								|DPR INT,
								|DPA INT,
								|RJC INT
								)  USING DELTA""".stripMargin//.replaceAll("\n", "")


				try {
												val tablePath = new File(BaseTablePath)
																				if (tablePath.exists())
																				{
																								log.info("creating  base table in path: "+ s"$BaseTablePath" )
																								spark.sql(baseTableCreateSql)
																								log.info(s"Base table : $BaseHistTableName  is created")
																				}
																				else
																				{
																								log.error("Path: "+ s"$BaseTablePath" + " is Not Exists exiting the program ...")
																								log.info("Usage: Re-execute the program by changing  base table path value in parameter file ..")
																								System.exit(1)
																				}
								}
catch {
case ex:org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
log.warn("Usage:Table: "+ s"$BaseTablePath$BaseHistTableName" + " is already Exists , skipping this step......")
log.error(ex.getLocalizedMessage)
//val str=ex.printStackTrace().toString()
//log.error(str)
//log.info("Usage: Re-execute the program by changing  base table name value in parameter file ..")
//System.exit(1)
case e: Exception =>
log.error("Error : Exception caught in base table creation block")
log.error(e.getLocalizedMessage)
//e.printStackTrace()
}
log.info("#############QCLInitializer completed #####################")
//spark.stop()
}
}