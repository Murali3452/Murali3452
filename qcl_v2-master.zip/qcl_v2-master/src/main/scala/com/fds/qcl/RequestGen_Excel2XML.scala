package com.fds.qcl

import io.delta.tables._
import io.delta._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import org.apache.commons.io.FileUtils
import java.io.{ BufferedWriter, FileWriter, File, FileOutputStream, PrintWriter }
import java.time.format.DateTimeFormatter
import java.time._

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
//import utils.InputParams2._
import utils.ConfigParams._
//import com.crealytics.spark.excel._
object RequestGen_Excel2XML {

  def main(args: Array[String]) {

    Logger.getLogger("org").setLevel(Level.ERROR)

    val spark = SparkSession.builder().appName("SparkSQL").master("local[*]")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    println(".....RequestGen_Excel2XML Execution Started @" + new java.sql.Timestamp(System.currentTimeMillis()))

    if (args == null || args.length == 0 || args.length !=2  )
    {
      println("Usage : Insufficiant Number of arguments , kindly provide required parameters and try again...")
      println("Usage : This program requires two input parameters :: Param 1 : home path and Param 2: file name")
       println("Usage : Sample parameters : C:/QCL/TESTDATAFILES/ 111REG0000222PLN.xlsx")
      println("Error : Aborting the Program ")
      System.exit(1)
    }
    val reqest_excelfile_schema = StructType(Seq(
      StructField("AccountNumber", StringType, nullable = true),
      StructField("IssueDate", DateType, nullable = true),
      StructField("ProductType", StringType, nullable = true),
      StructField("OriginalAmount", DoubleType, nullable = true),
      StructField("SalaryAssignmentFlag", StringType, nullable = true),
      StructField("ExpiryDate", DateType, nullable = true),
      StructField("ProductStatus", StringType, nullable = true),
      StructField("InstallmentAmount", DoubleType, nullable = true),
      StructField("PaymentFrequency", StringType, nullable = true),
      StructField("Tenure", IntegerType, nullable = true),
      StructField("SecurityType", StringType, nullable = true),
      StructField("SubProductType", StringType, nullable = true),
      StructField("LastCycleID", IntegerType, nullable = true),
      StructField("LastPaymentDate", DateType, nullable = true),
      StructField("LastAmountPaid", DoubleType, nullable = true),
      StructField("PaymentStatus", StringType, nullable = true),
      StructField("OutStandingBalance", DoubleType, nullable = true),
      StructField("PastDueBalance", DoubleType, nullable = true),
      StructField("AsOfDate", DateType, nullable = true),
      StructField("NextPaymentDate", DateType, nullable = true),
      StructField("IDType", StringType, nullable = true),
      StructField("IDNumber", StringType, nullable = true),
      StructField("ApplicantType", StringType, nullable = true)))
      
    
    //val HOME_PATH = "C:/Bigdata/QCL_TESTRUN/testdatafiles/"
    val HOME_PATH = args(0)
    //val FILE_NAME = HOME_PATH + "input/request/" + "888REG0000101PLN.xlsx"
    val FILE_NAME = HOME_PATH + "input/request/" + args(1)
    val outFilePath = HOME_PATH + "output/request/" //params.OUTPUT_FILE_XMLREQUET_PATH
    val tablePath = HOME_PATH + "staging/" //params.DELTA_TABLE_PATH_WORKING
    val fileName = getFileName(FILE_NAME)
    //println("fileName:"+fileName)
    val fileNameWOext = fileName.slice(0, fileName.lastIndexOf("."))
    val xmlFileName = fileNameWOext + ".xml"
    val requestTable = tablePath + fileNameWOext
    val requestXMLfilePath = outFilePath + xmlFileName
    val runNumber = fileName.substring(6, 13)//.toInt
    val fileType = fileName.substring(3, 6)
    val fileProduct = fileName.substring(13, 16)
    val memberId = fileName.substring(0, 3)

    //println("xmlFileName:"+xmlFileName)
    //println("requestTable:"+requestTable)
    //println("requestXMLfilePath:"+requestXMLfilePath)
    println(s".....Processing the file : $FILE_NAME ")
    println("fileType:" + fileType)
    println("fileProduct:" + fileProduct)
    println("memberId:" + memberId)
    println("runNumber:" + runNumber)

    try {
      val tempDir = new File(requestTable)
      //Delete staging delta table , if exists
      if (tempDir.exists()) {
        println("*****Staging table already exists , dropping the table :" + requestXMLfilePath)
        FileUtils.deleteDirectory(tempDir)
      }

    } catch { case e: Exception => e.printStackTrace() }
    try {
      val newFile = new File(requestXMLfilePath)
      if (newFile.exists()) {
        //Delete request XML file in target , if exists
        newFile.delete()
        println("*****File already exists , deleting the file :" + requestXMLfilePath)
      }
    } catch { case e: Exception => e.printStackTrace() }
    try {
      import spark.implicits._
      /*val excelDF = spark.read.excel(
        header = true,
        treatEmptyValuesAsNulls = false
      //.option("inferSchema", "true")
      //.option("addColorColumns", "False")
      ).schema(reqest_excelfile_schema)
        .load(FILE_NAME)
*/
       val excelDF = spark.read.format("com.crealytics.spark.excel")
                  .option("inferSchema", "false")
                  .option("treatEmptyValuesAsNulls", "false")
                  .option("header", "true")
                  //.option("dateFormat", "MM/DD/yyyy")
                  .schema(reqest_excelfile_schema)
                  .load(FILE_NAME)      
      println("Excel file schema ........")
      excelDF.printSchema()
      excelDF.show(false)

      val TOT_ITEMS=excelDF.count().toString()
      
      println(s"Total records count: $TOT_ITEMS")
      excelDF.write.format("delta").mode("overwrite").save(requestTable)

      import spark.implicits._
      ////val caseClassDF=excelDF2
      //                    .withColumn("requestFlag",lit("Y"))
      //                    .as[RegularRequestXMLMapClass_V4]
      //caseClassDF.write.format("delta").mode("overwrite").save(requestTable)

      println(s"inserted data to staging table :$requestTable")

      val sqlStr = """select '<ACCOUNT>' as account_start_tag,
			'<AREF>' || ACC.AccountNumber || '</AREF>' AS AccountNumber ,
			|CASE WHEN ACC.IssueDate is not null then '<AOPN>' || '<AOPND>' || lpad( date_part('D',ACC.IssueDate) ,2, '0') || '</AOPND>' || '<AOPNM>' || lpad( date_part('MON',ACC.IssueDate) ,2, '0') || '</AOPNM>' || '<AOPNY>' || date_part('YEAR',ACC.IssueDate)  || '</AOPNY>' || '</AOPN>' else null END AS IssueDate,
			|'<APRD>' || ACC.ProductType || '</APRD>' AS ProductType,
			|'<ALMT>' || ACC.OriginalAmount || '</ALMT>'  AS OriginalAmount,
			|'<ASAL>' || ACC.SalaryAssignmentFlag || '</ASAL>'AS SalaryAssignmentFlag,
			|CASE WHEN ACC.ExpiryDate is not null then '<AEXP>' || '<AEXPD>' || lpad( date_part('D',ACC.ExpiryDate) ,2, '0') || '</AEXPD>' || '<AEXPM>' || lpad( date_part('MON',ACC.ExpiryDate) ,2, '0') || '</AEXPM>' || '<AEXPY>' || date_part('YEAR',ACC.ExpiryDate)  || '</AEXPY>' || '</AEXP>' else null END AS ExpiryDate,
			|'<APST>' || ACC.ProductStatus || '</APST>' AS ProductStatus,
			|'<AINST>' || ACC.InstallmentAmount || '</AINST>' AS InstallmentAmount,
			|'<AFRQ>' || ACC.PaymentFrequency || '</AFRQ>' AS PaymentFrequency,
			|'<ATNR>' || ACC.Tenure || '</ATNR>' AS Tenure,
			|'<ASEC>' || ACC.SecurityType || '</ASEC>' AS SecurityType,
			|'<ADWNP>' || '0' || '</ADWNP>' AS DownPayment,
			|'<ABPAY>' || '0' || '</ABPAY>' AS BalloonPayment,
			|'<ADAMT>' || '0' || '</ADAMT>' AS DispensedAmount,
			|'<AMAX>' || '0' || '</AMAX>' AS MaxInstallmentAmount,
			|CASE WHEN ACC.SubProductType IS NOT NULL THEN '<ASP>' || ACC.SubProductType  || '</ASP>' ELSE NULL END AS SubProductType,
			|'<ACON>' || '1' || '</ACON>' AS NumberOfApplicants,
			|'<ACYC>' as cycle_start_tag,
			|'<ACYCID>' || ACC.LastCycleID || '</ACYCID>'  AS LastCycleID,
			|CASE WHEN ACC.LastPaymentDate is not null then '<ALSPD>' || '<ALSPDD>' || lpad( date_part('D',ACC.LastPaymentDate) ,2, '0') || '</ALSPDD>' || '<ALSPDM>' || lpad( date_part('MON',ACC.LastPaymentDate) ,2, '0') || '</ALSPDM>' || '<ALSPDY>' || date_part('YEAR',ACC.LastPaymentDate)  || '</ALSPDY>' || '</ALSPD>' else null END AS LastPaymentDate,
			|'<ALSTAM>' || ACC.LastAmountPaid || '</ALSTAM>' AS LastAmountPaid,
			|'<AACS>' || ACC.PaymentStatus || '</AACS>' AS PaymentStatus,
			|'<ACUB>' || ACC.OutStandingBalance || '</ACUB>' AS OutStandingBalance,
			|'<AODB>' || ACC.PastDueBalance || '</AODB>' AS PastDueBalance,
			|CASE WHEN ACC.AsOfDate is not null then '<AASOF>' || '<AASOFD>' || lpad( date_part('D',ACC.AsOfDate) ,2, '0') || '</AASOFD>' || '<AASOFM>' || lpad( date_part('MON',ACC.AsOfDate) ,2, '0') || '</AASOFM>' || '<AASOFY>' || date_part('YEAR',ACC.AsOfDate)  || '</AASOFY>' || '</AASOF>' else null END AS AsOfDate,
			|CASE WHEN ACC.NextPaymentDate is not null then '<ANXPD>' || '<ANXPDD>' || lpad( date_part('D',ACC.NextPaymentDate) ,2, '0') || '</ANXPDD>' || '<ANXPDM>' || lpad( date_part('MON',ACC.NextPaymentDate) ,2, '0') || '</ANXPDM>' || '<ANXPDY>' || date_part('YEAR',ACC.NextPaymentDate)  || '</ANXPDY>' || '</ANXPD>' else null END  AS NextPaymentDate ,
			|'</ACYC>'  as cycle_end_tag,
			|'<CONSUMER>' AS consumer_start_tag ,
			|'<CID>' AS ID_start_tag,
			|'<CID1>' || ACC.IDType || '</CID1>' AS IDType,
			|'<CID2>' || ACC.IDNumber || '</CID2>' AS IDNumber,
			|'</CID>' AS ID_end_tag,
			|'<CAPL>' || ACC.ApplicantType || '</CAPL>' AS ApplicantType,
			|'</CONSUMER>' AS consumer_end_tag,
			| '</ACCOUNT>'  as account_end_tag  """.stripMargin

      val xmlDataDF = spark.sql(s"$sqlStr  FROM delta.`$requestTable` as ACC")

      //println("XML dataframe schema")
      //xmlDataDF.printSchema()
      println("Dataframe converted to XML format")
      xmlDataDF.show()

      val HEADER_LINE1="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
      val HEADER_LINE2="<REQUEST xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"CI_Upload.xsd\">"
      val HEADER_LINE3="<SERVICE>REGULAR_AC</SERVICE>"
      val HEADER_LINE4="<ACTION>A</ACTION>"
      val HEADER_LINE5="<HEADER>"
      val HEADER_LINE6="<MEMBER_ID>"+memberId+"</MEMBER_ID>"
      val HEADER_LINE7="<USER_ID>FTSXXXX</USER_ID>"
      val HEADER_LINE8="<RUN_NO>"+runNumber+"</RUN_NO>"
      val HEADER_LINE9="<TOT_ITEMS>"+TOT_ITEMS+"</TOT_ITEMS>"
      val HEADER_LINE10="</HEADER>"
      val HEADER_LINE11="<MESSAGE>"
      val END_LINE1="</MESSAGE>"
      val END_LINE2="</REQUEST>"
      
      
      val allColumns = xmlDataDF.columns.map(m => col(m))
      try {
        import spark.implicits._
        val xmlStringArray = xmlDataDF.select(allColumns: _*).collect() //.toList.foreach(f => f.getList(0)) //.map { row => row}
        val bufferWrite = new PrintWriter(new FileOutputStream(new File(requestXMLfilePath), true))
        
        bufferWrite.write(HEADER_LINE1 + "\n")
        bufferWrite.write(HEADER_LINE2 + "\n")
        bufferWrite.write(HEADER_LINE3 + "\n")
        bufferWrite.write(HEADER_LINE4 + "\n")
        bufferWrite.write(HEADER_LINE5 + "\n")
        bufferWrite.write(HEADER_LINE6 + "\n")
        bufferWrite.write(HEADER_LINE7 + "\n")
        bufferWrite.write(HEADER_LINE8 + "\n")
        bufferWrite.write(HEADER_LINE9 + "\n")
        bufferWrite.write(HEADER_LINE10 + "\n")
        bufferWrite.write(HEADER_LINE11+ "\n")
        
        // var row=Array([String])
        for (i <- 0 until xmlStringArray.length) {
          val row = xmlStringArray(i)
          for (j <- 0 until row.length) {
            val tag = row(j)
            if (tag != null)
              bufferWrite.write(tag + "\n")
          }
          //
        }
        bufferWrite.write(END_LINE1 + "\n")
        bufferWrite.write(END_LINE2)
        bufferWrite.close()
        //println(s".......XML file generation completed:"+new java.sql.Timestamp(System.currentTimeMillis()))
        println(s"XML file saved in :  $requestXMLfilePath")
      } catch { case e: Exception => e.printStackTrace() }
    } catch { case e: Exception => e.printStackTrace() }
    println(".....RequestGen_Excel2XML Execution Completed @" + new java.sql.Timestamp(System.currentTimeMillis()))
  }
}