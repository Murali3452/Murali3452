package com.fds.qcl

import io.delta.tables._
import io.delta._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types._ //{ StructType, StructField, StringType, DoubleType };
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.{ SparkConf, SparkContext }
import scala.reflect.io._
import java.io.{ BufferedWriter, FileWriter ,File ,FileOutputStream,PrintWriter}


//import utils.SimahCaseClasses._
////#import utils.SimahCaseClasses_V1_2._
import utils.SimahCaseClasses._
//import utils.CBDataValidatorHelpers_V1_1._
////#import utils.CBDataValidatorHelpers_V2_0._
import utils.QCLHelperFunctions._
//import utils.SimahRuleChecker_V1_0._
//import utils.SimahRuleChecker_V1_2._
////#import utils.SimahRuleChecker_V1_3._
import utils.SimahRuleChecker._
////#import utils.CBDataValidatorParams_V1_1._
import utils.QCLInputParams._

object QCLRequestLoader {

  def main(args: Array[String]) {
     
    Logger.getLogger("org").setLevel(Level.ERROR)
    val conf = new SparkConf().setAppName("QCLRequestLoaderApp").setMaster("local[*]").set("spark.testing.memory", "2147480000") //local
    val spark = SparkSession
		.builder()
		.appName("SparkSQL")
		.master("local[*]")
		.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
		.config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
		.config(conf)
		.getOrCreate()
		//E:\Murali\bigdata_folder\DataProfiling\Simah\LAKEHOUSE\BASE
	val programStartTime = spark.sparkContext.broadcast(new java.sql.Timestamp(System.currentTimeMillis()))
	println(".....SimahDataValidator Execution Started @"+ programStartTime.value)
       //val log = Logger.getLogger("FILE")
	if(args == null || args.length== 0 || args.length== 1 || (!args(0).equalsIgnoreCase("-config")) || args.length != 3 || args(2).length() !=10 )
	{
		println("Usage : Insufficiant Number of arguments , kindly input config parameters and try again")
		println("Usage : Sample command :SimahDataValidator -config \\configfilepath\\configfilename")
		println("Error : Aborting the Program ")
		println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
		System.exit(1)
	}
	else
	{ 
		val params= setParams(args(1))
		if(params.configFileLoad)
			printParams(params)
		else
		{
			println(s"Usage : Unable to load the config file kindly check the provided path is correct :"+args(1))
			println("Error : Aborting the Program ")
			println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
			System.exit(1)
		}
        val runDate=getRunDate(args(2))
        if (runDate == new java.sql.Date(0))
        {
            println(s"Usage : Restart the program by supplying rundate in dd-MM-yyyy format:"+args(2))
            println("Error : Aborting the Program ")
            println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
            System.exit(1)
        }//else println(s"runDate: $runDate")
        
		    //val fileName=params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME
        val fileName=params.INPUT_FILE_XMLREQUEST_NAME
        //val currentKey1=params.INPUT_FILE_XMLREQUEST_NAME.substring(3, 16)
        //val currentKey2=params.INPUT_FILE_XMLREQUEST_NAME.substring(3,6)+params.INPUT_FILE_XMLREQUEST_NAME.substring(13, 16)
        //val currentRunNumber=params.INPUT_FILE_XMLREQUEST_NAME.substring(6, 13).toInt
        val currentKey1=fileName.substring(3, 16)
        val currentKey2=fileName.substring(3,6)+fileName.substring(13, 16)
        val currentRunNumber=fileName.substring(6, 13).toInt
        val fileType=fileName.substring(3,6)
        val fileProduct=fileName.substring(13, 16)
        println("Filename:"+params.INPUT_FILE_XMLREQUEST_NAME)
        println("currentKey1:"+currentKey1)
        println("currentKey2:"+currentKey2)
        println("currentRunNumber:"+currentRunNumber)
        val controlTablePath="C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/exe_control_table"
        val tempTablePath=s"C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/TEMP/$currentKey1"
        println("TempTable Path:"+tempTablePath)
        val fileNamePrepend=runDate.toString().replace("-","")+"_"+currentKey1
        
    /*    try
		{
			val sql=s"DELETE FROM delta.`$controlTablePath` WHERE KEY1='$currentKey1'"
			println("sql:"+sql)
			spark.sql(sql)
			println(s"Deleted control table record for key:$currentKey1")
		}catch
		{case e:Exception => e.printStackTrace() }
        System.exit(1)
                           */
		/*
        try
        { 
			// val sql=s"DELETE FROM delta.`$controlTablePath` KEY1='REG0015732PLN'"
			//val sql=s"UPDATE delta.`$controlTablePath` SET RESP_STS_SIMAH='OK' WHERE KEY1='$currentKey1'"
			//val sql=s"UPDATE delta.`$controlTablePath` SET RESP_STS_SIMAH='ERR' , RESP_STS_SDVL='ERR' WHERE KEY1='REG0015224VLS'"
			println("sql:"+sql)
			spark.sql(sql)
			println(s"Updated control table record for key:$currentKey1")
			//spark.sql(s"SELECT * FROM delta.`$controlTablePath` WHERE KEY2='$currentKey2'").show()
			spark.sql(s"SELECT * FROM delta.`$controlTablePath` ").show()
			System.exit(1)
        }
		catch
			{case e:Exception => e.printStackTrace() }
		System.exit(1)
        */
		val tempFolder=params.OUTPUT_FILE_XMLREQUET_PATH +"sparkTmp"
		
		try
		{
			val selectMaxRunSql=s"""select ext.* FROM delta.`$controlTablePath` as ext
               inner join (select KEY2,max(RUNNUMBER) as MAXRUNNUMBER   FROM delta.`$controlTablePath` group by KEY2) as  maxrun
               |on  ext.RUNNUMBER=maxrun.MAXRUNNUMBER and ext.key2=maxrun.key2""".stripMargin
			//val sqlstr=s"select ext.* FROM delta.`$controlTablePath` as ext inner join (select KEY2,max(RUNNUMBER) as MAXRUNNUMBER   FROM delta.`$controlTablePath` group by KEY2) as  maxrun on  ext.RUNNUMBER=maxrun.MAXRUNNUMBER and ext.key2=maxrun.key2"
			//  val sqlstr2=s"select KEY2,max(RUNNUMBER) as MAXRUNNUMBER   FROM delta.`$controlTablePath` group by KEY2"
			
			spark.sql(s"select *  FROM delta.`$controlTablePath`").show() 
			
			import spark.implicits._
			val maxRunDF=spark.sql(selectMaxRunSql).na.fill("").distinct().as[RequestFileStats2].filter('KEY2 === lit(currentKey2))
			//maxRunDF.printSchema()
			maxRunDF.show()
			if(!maxRunDF.isEmpty && maxRunDF.count() > 0 )
			{
				val latestKeyRecord=maxRunDF.collect()(0)
				val previousKey2=latestKeyRecord.KEY2
				val previousKey1=latestKeyRecord.KEY1
				val previousFilename=latestKeyRecord.FILENAME
				val previousRunNumber=latestKeyRecord.RUNNUMBER
				val previousRunDate=latestKeyRecord.RUNDATE
				println("previousKey1:"+previousKey1)
				println("previousFilename:"+previousFilename)
				println("previousRunNumber:"+previousRunNumber)
				println("previousRunDate:"+previousRunDate)
				val Pev_RESP_STS_SDVL=latestKeyRecord.RESP_STS_SDVL
				val Pre_RESP_STS_SIMAH= latestKeyRecord.RESP_STS_SIMAH
				if(Pev_RESP_STS_SDVL == "" || Pev_RESP_STS_SDVL == null)
					println(s"SDVL Response is not loaded for key $previousKey1")
				else
					println("SDVL Response is loaded:"+Pev_RESP_STS_SDVL)
				if(Pre_RESP_STS_SIMAH == "" || Pre_RESP_STS_SIMAH  == null)
					println(s"SIMAH Response is not loaded for key $previousKey1")
				else
					println("SIMAH Response is loaded:"+Pre_RESP_STS_SIMAH)
				//}//end of maxRunDF empty check if  block
				//System.exit(1)
				//Setting the Temporary folder
				if(Pre_RESP_STS_SIMAH == "" || Pre_RESP_STS_SIMAH  == null)
				{
					println(s"Usage : Previous  simah response is not loaded for key :$previousKey1 ")
                       println("Error : exiting the program , re execute after loading response for above key ")
                       println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
                       System.exit(1)
				}
				else
				{
					val tempFolder=params.OUTPUT_FILE_XMLREQUET_PATH +"sparkTmp"
					val sqlString1="""select AccountNumber as H_AccountNumber,
                                      |IssueDate as H_IssueDate,
                                      |ProductType as H_ProductType,
                                      |OriginalAmount as H_OriginalAmount,
                                      |SalaryAssignment as H_SalaryAssignmentFlag,
                                      |ExpiryDate as H_ExpiryDate,
                                      |ProductStatus as H_ProductStatus,
                                      |InstallmentAmount as H_InstallmentAmount,
                                      |PaymentFrequency as H_PaymentFrequency,
                                      |Tenure as H_Tenure,
                                      |SecurityType as H_SecurityType,
                                      |1 as H_NumberOfApplicants,
                                      |LastCycleID as H_LastCycleID,
                                      |LastPaymentDate as H_LastPaymentDate,
                                      |LastAmountPaid as H_LastAmountPaid,
                                      |PaymentStatus as H_PaymentStatus,
                                      |OutStandingBalance as H_OutstandingAmount,
                                      |PastDueBalance as H_PastDueBalance,
                                      |AsOfDate as H_AsOfDate,
                                      |NextPaymentDate as H_NextPaymentDate,
                                      |null as H_ApplicationType,
                                      |null as H_IDType,
                                      |null as H_IDNumber,
                                      |null as HIST_RUN_NO,
                                      |null as H_NEW_ACCT_FLAG""".stripMargin
								
					import spark.implicits._
					val histCaseclassDF =spark.sql(s"$sqlString1  FROM delta.`C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/base_hist` as A").as[InputHistMapCaseClass2]
					// val histCaseclassDF=testDF2.as[RequestPlusHistCaseClass]
					//  val histCaseclassDF=testDF2.as[InputHistMapCaseClass2]
					//   histCaseclassDF.printSchema()
					//  histCaseclassDF.show()
					
                          val requestXMLDF = spark.read.format("com.databricks.spark.xml")
                                             .option("inferSchema",false)
                                             .option("rowTag", params.INPUT_FILE_XMLREQUEST_ROWTAG)//.option("rowTag", "ACCOUNT")
                                             .load(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME)//.load(curXMLFilePath)
                          // requestXMLDF.printSchema()
                          // requestXMLDF.show()
                          val finalRequestXMLDF=addMissingColumns(requestXMLDF,requestXMLFileREGSchema)
					//@@val requestXMLCaseClassDF=getRequestXMLCaseClassDS_V1_2(requestXMLDF)//  TagggedDF.as[InputXMLMapCaseClass]
					val requestXMLCaseClassDF=getRegularRequestXMLMapClass_V2_0(finalRequestXMLDF)
					//val requestXMLCaseClassDF=getRequestXMLCaseClassDS_V1_3(requestXMLDF)//  TagggedDF.as[InputXMLMapCaseClass]
					//:: TO CHECK
					// val curHistDS=requestXMLCaseClassDF.join(histCaseclassDF , Seq("AccountNumber") , "left").as[InputHistCaseClass]
					val curHistDS=requestXMLCaseClassDF.join(histCaseclassDF ,
								requestXMLCaseClassDF("AccountNumber") === histCaseclassDF("H_AccountNumber") &&
								requestXMLCaseClassDF("ProductType") === histCaseclassDF("H_ProductType")
								, "left")
								.withColumn("NEW_ACCT_FLAG", when('H_AccountNumber.isNotNull,lit(false)).otherwise(lit(true))).as[RequestPlusHistCaseClass]
								// .withColumn("NewFlag", when('H_ProductType.isNull , true ).otherwise(false) )
					curHistDS.cache()
					//System.exit(1)
					
					//Funcation call
					val dataQualityDF= for
					{
						row <- requestXMLCaseClassDF
						//getInvalidRecords
						val rows=getRequestFileDQReport(
                                      row.AccountNumber,
                                      row.ProductType,
                                      row.SalaryAssignmentFlag,
                                      row.PaymentFrequency,
                                      row.SecurityType,
                                      row.IssueDate,
                                      row.ExpiryDate,
                                      row.AsOfDate,
                                      //row.CloseDate,
                                      row.ProductStatus,
                                      row.PaymentStatus,
                                      row.Tenure,
                                      row.InstallmentAmount,
                                      row.OriginalAmount,
                                      row.OutStandingBalance,
                                      row.PastDueBalance,
                                      row.LastCycleID,
                                      row.LastAmountPaid,
                                      row.LastPaymentDate,
                                      row.NextPaymentDate,
                                   )
					} yield rows
					//Function call
					val errorsDF= for
					{
						row <- curHistDS
						val rows=getRejectionRecords(
                                    row.AccountNumber:  String ,
                                    row.IssueDate:  java.sql.Date ,
                                    row.ProductType:  String ,
                                    row.OriginalAmount:  Option[Double] ,
                                    row.SalaryAssignmentFlag:  String ,
                                    row.ExpiryDate:  java.sql.Date ,
                                    row.ProductStatus:  String ,
                                    row.InstallmentAmount:  Option[Double] ,
                                    row.PaymentFrequency:  String ,
                                    row.Tenure:  Option[Integer] ,
                                    row.SecurityType:  String ,
                                    //row.NumberOfApplicants:  Option[Integer] ,
                                    row.LastCycleID:  Option[Integer] ,
                                    row.LastPaymentDate:  java.sql.Date ,
                                    row.LastAmountPaid:  Option[Double] ,
                                    row.PaymentStatus:  String ,
                                    row.OutStandingBalance:  Option[Double] ,
                                    row.PastDueBalance:  Option[Double]  ,
                                    row.AsOfDate:  java.sql.Date ,
                                    row.NextPaymentDate:  java.sql.Date ,
                                    row.IDType:  String ,
                                    row.IDNumber:  String ,
                                   // row.NEW_ACCT_FLAG:  Boolean,
                                    row.H_IssueDate:  java.sql.Date ,
                                    row.H_ProductType:  String ,
                                    row.H_OriginalAmount:  Option[Double] ,
                                    row.H_SalaryAssignmentFlag:  String ,
                                    row.H_ExpiryDate:  java.sql.Date ,
                                    row.H_ProductStatus:  String ,
                                    row.H_InstallmentAmount:  Option[Double] ,
                                    row.H_PaymentFrequency:  String ,
                                    row.H_Tenure:  Option[Integer] ,
                                    row.H_SecurityType:  String ,
                                    row.H_LastCycleID:  Option[Integer] ,
                                    row.H_LastPaymentDate:  java.sql.Date ,
                                    row.H_LastAmountPaid:  Option[Double] ,
                                    row.H_PaymentStatus:  String ,
                                    row.H_OutstandingAmount:  Option[Double] ,
                                    row.H_PastDueBalance:  Option[Double]  ,
                                    row.H_AsOfDate:  java.sql.Date ,
                                    row.H_NextPaymentDate:  java.sql.Date ,
                                    row.H_IDType:  String ,
                                    row.H_IDNumber:  String ,
                                    row.HIST_RUN_NO:  String ,
                                    row.H_NEW_ACCT_FLAG:  String
                                    )
					} yield rows
					val reqWithRejDetails=requestXMLCaseClassDF.join(errorsDF,Seq("AccountNumber","ProductType"),"left" )
												.withColumn("SDV_REJ_FLAG", when('ErrorIDs.isNull || 'ErrorIDs===null || 'ErrorIDs==="" , lit("N")).otherwise(lit("Y")))
												.withColumn("SIMAH_REJ_FLAG",  lit("N"))
												.withColumn("SIMAH_REJ_MSG",  lit(""))
												.withColumnRenamed("ErrorMsgs", "SDV_REJ_MSG")
						 println("Temporary Table schema")
						 reqWithRejDetails.printSchema()
						 reqWithRejDetails.show()
					try
					{
						val tempTableSQL=s"""CREATE OR REPLACE TABLE delta.`$tempTablePath` ( AccountNumber STRING,ProductType STRING,OriginalAmount DOUBLE,SalaryAssignmentFlag STRING,ProductStatus STRING,
						   |InstallmentAmount DOUBLE,PaymentFrequency STRING,Tenure INT,SecurityType STRING,LastCycleID INT,LastAmountPaid DOUBLE,PaymentStatus STRING,OutStandingBalance
						   |DOUBLE,PastDueBalance DOUBLE,IDType STRING,IDNumber STRING,IssueDate Date,ExpiryDate Date,AsOfDate Date,LastPaymentDate Date,NextPaymentDate Date,
						   |ValidFlag STRING,ErrorIDs STRING,SDV_REJ_MSG STRING,SDV_REJ_FLAG STRING,SIMAH_REJ_FLAG STRING,SIMAH_REJ_MSG STRING)  USING DELTA""".stripMargin
						
						spark.sql(tempTableSQL)
						//reqWithRejDetails.write.format("delta").saveAsTable("C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/TEMP/REG0015720PLN")
						reqWithRejDetails.write.format("delta").mode("overwrite").save(tempTablePath)
						println(s"inserted data to temp table :$tempTablePath")
						spark.sql(s"select *  FROM delta.`$tempTablePath` ").show()
						val tempDF=spark.sql(s"select *  FROM delta.`$tempTablePath`")
						println("Temp delta table schema")
						tempDF.printSchema()
						tempDF.show()
					}
					catch{
						case e: Exception =>
						e.printStackTrace()
						println("Exception caught in Temp table creation block")
						System.exit(1)
					}
					
					val rejectRecDF=  errorsDF.filter(col("ValidFlag")=!=("VALID")).toDF().join(requestXMLCaseClassDF , Seq("AccountNumber","ProductType") , "inner")
					// rejectRecDF.printSchema()
					//rejectRecDF.show()
					val sdvRespDF =rejectRecDF.select(col("AccountNumber").alias("AREF") ,col("ProductType").alias("APRD"),col("ErrorMsgs").alias("RSP_MSG") )
					println("sdvRespDF schema")
					sdvRespDF.printSchema()
					sdvRespDF.show()
					val dqRecordsDF=dataQualityDF.filter(col("ValidFlag")=!=("VALID")).join(requestXMLCaseClassDF , Seq("AccountNumber","ProductType") , "inner")
					// dqRecordsDF.printSchema()
					//dqRecordsDF.show()
					val validRequestRecordsDF=requestXMLDF.join(errorsDF.select('AccountNumber.as("AREF")).filter(col("ValidFlag")===("VALID")).toDF() , Seq("AREF") )
					val NewAcctsDF=curHistDS.
					select('AccountNumber,'IssueDate,'ProductType,'OriginalAmount,'SalaryAssignmentFlag,
					'ExpiryDate,'ProductStatus,'InstallmentAmount,'PaymentFrequency,'Tenure,'SecurityType,
					'LastCycleID,'LastPaymentDate,'LastAmountPaid,'PaymentStatus,'OutstandingBalance,
					'PastDueBalance,'AsOfDate,'NextPaymentDate,'IDType,'IDNumber,'NEW_ACCT_FLAG).filter('H_AccountNumber.isNull)
					println("Start gatharing the run stats")
					val COUNT_INFILE_REC=requestXMLDF.count().toInt
					val COUNT_OUTFILE_REC=validRequestRecordsDF.count().toInt
					val COUNT_REJ_SDVL=rejectRecDF.count().toInt
					val COUNT_REJ_SIMAH=0
					val COUNT_REJ_TOTAL=COUNT_REJ_SDVL // Update after loading SIMAH response COUNT_REJ_SDVL+COUNT_REJ_MISSING
					val COUNT_REJ_EXTRA=0          // Update after loading SIMAH response
					val COUNT_REJ_MISSING=0       // Update after loading SIMAH response
					val COUNT_ACCTS_NEW=NewAcctsDF.count().toInt
					val COUNT_DQ_REC=dqRecordsDF.count().toInt
					val RESP_STS_SDVL= { if(COUNT_REJ_SDVL>0) "ERROR" else "OK"}
					val RESP_STS_SIMAH="" // Update after loading SIMAH response COUNT_REJ_SIMAH+COUNT_REJ_SDVL
					println("End gatharing the run stats") 
					//Block to prepare the header
					//Uncomment for version 1 files  val headerLines=getHeader(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME)
					val headerLines=getHeader2(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME)
					val totalItems= "<TOT_ITEMS>" + COUNT_OUTFILE_REC +"</TOT_ITEMS>"
					val endLines = Seq(totalItems , "</HEADER>" )
					val finalHeaderString=headerLines ++ endLines
					//End of block to header preparation
					dqRecordsDF.cache()
					rejectRecDF.cache()
					/*
					try
					{
					println("Usage : Start : Saving the reqWithRejDetails file")
					reqWithRejDetails.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(params.OUTPUT_FILE_ERR_PATH +"reqWithRejDetails")
					moveFiles(params.OUTPUT_FILE_ERR_PATH +"reqWithRejDetails",params.OUTPUT_FILE_ERR_PATH, "reqWithRejDetails.csv")
					println("Usage : End : Saved the file : " +params.OUTPUT_FILE_DQ_PATH  + "reqWithRejDetails.csv")
					}
					catch{
					case e: Exception =>
							println("Error : Exception caught while saving dqRecordsDF ")
							e.printStackTrace()
					}
					try
					{
					println("Usage : Start : Saving the New account file")
					NewAcctsDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(params.OUTPUT_FILE_ERR_PATH +"NewAcctsDF")
					moveFiles(params.OUTPUT_FILE_ERR_PATH +"NewAcctsDF",params.OUTPUT_FILE_ERR_PATH, "NewAcctsDF.csv")
					println("Usage : End : Saved the file : " +params.OUTPUT_FILE_DQ_PATH  + "NewAcctsDF.csv")
					}
					catch{
					case e: Exception =>
							println("Error : Exception caught while saving dqRecordsDF ")
							e.printStackTrace()
					}
					try
					{
						println("Usage : Start : Saving the Data Quality violations file")
						dqRecordsDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(params.OUTPUT_FILE_DQ_PATH +"_"+params.OUTPUT_FILE_DQ_NAME)
						moveFiles(params.OUTPUT_FILE_DQ_PATH +"_"+params.OUTPUT_FILE_DQ_NAME,params.OUTPUT_FILE_DQ_PATH, params.OUTPUT_FILE_DQ_NAME)
						println("Usage : End : Saved the file : " +params.OUTPUT_FILE_DQ_PATH  + params.OUTPUT_FILE_DQ_NAME)
					}
					catch{
						case e: Exception =>
							println("Error : Exception caught while saving dqRecordsDF ")
							e.printStackTrace()
					}
					try
					{
						println("Usage : Start : Saving the Rejection Records file")
						rejectRecDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(params.OUTPUT_FILE_ERR_PATH +"_"+params.OUTPUT_FILE_ERR_NAME)
						moveFiles(params.OUTPUT_FILE_ERR_PATH +"_"+params.OUTPUT_FILE_ERR_NAME,params.OUTPUT_FILE_ERR_PATH, params.OUTPUT_FILE_ERR_NAME)
						println("Usage : End : Saved the rejectRecDF file :" +params.OUTPUT_FILE_ERR_PATH + params.OUTPUT_FILE_ERR_NAME )
					}
					catch{
						case e: Exception =>
						println("Error : Exception caught while saving rejectRecDF ")
						e.printStackTrace()
					}
					*/
					val outputPath=params.OUTPUT_FILE_ERR_PATH
					try
					{
						println("Usage : Start : Saving the reqWithRejDetails file")
						val tmpFolderName=fileNamePrepend+"_"+"ProcessedAcctsAll"
						val newfileName=tmpFolderName+".csv"
						reqWithRejDetails
						.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
						moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
						println("Usage : End : Saved the file with name : " + outputPath + newfileName)
					}
					catch{
						case e: Exception =>
						println("Error : Exception caught while saving reqWithRejDetails ")
						e.printStackTrace()
					}
					try
					{
						val tmpFolderName=fileNamePrepend+"_"+"NewAcctsReport"
						val newfileName=tmpFolderName+".csv"
						println("Usage : Start : Saving the New account file")
						NewAcctsDF
						.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
						moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
						println("Usage : End : Saved the file with name : " + outputPath + newfileName)
					}
					catch
					{
					case e: Exception =>
						println("Error : Exception caught while saving NewAcctsDF ")
						e.printStackTrace()
					}
					try
					{
					   val tmpFolderName=fileNamePrepend+"_"+"DataQualityReport"
					   val newfileName=tmpFolderName+".csv"
					   println("Usage : Start : Saving the Data Quality violations file")
					   dqRecordsDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
					   moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
					   println("Usage : End : Saved the file with name : " + outputPath + newfileName)
					}
					catch{
						case e: Exception =>
						println("Error : Exception caught while saving dqRecordsDF ")
						e.printStackTrace()
					}
					try
					{
					val tmpFolderName=fileNamePrepend+"_"+"RejectionReport"
					val newfileName=tmpFolderName+".csv"
					println("Usage : Start : Saving the Rejection Records file")
					rejectRecDF.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputPath  +tmpFolderName)
					moveFiles(outputPath+tmpFolderName,outputPath, newfileName)
					println("Usage : End : Saved the file with name : " + outputPath + newfileName)
					}
					catch{
					case e: Exception =>
							println("Error : Exception caught while saving rejectRecDF ")
							e.printStackTrace()
					}
					//  val requestFilePropsDf =getRequestFileDetails(params.INPUT_FILE_XMLREQUEST_PATH + params.INPUT_FILE_XMLREQUEST_NAME,runDate)
					//     requestFilePropsDf.write.format("delta").mode("append").save(controlTablePath)
					//  val df=spark.sql(s"select *  FROM delta.`$controlTablePath` as A")
					println(" Count of Records in input XML File       :"+ params.INPUT_FILE_XMLREQUEST_NAME +" : "+ COUNT_INFILE_REC )
					//println(" Count of Records in HistoryData File     :"+ params.INPUT_FILE_HISTDATA_NAME   +" : "+ histCaseclassDF.count())
					//println(" Count of Records in Jioned DF     :curHistDS : "+ curHistDS.count())
					println(" Count of Valid Records in input XML File       :"+ params.INPUT_FILE_XMLREQUEST_NAME +" : "+ COUNT_OUTFILE_REC)
					println(" Count of New Accounts in input XML File  :"+ params.INPUT_FILE_XMLREQUEST_NAME +" : "+ COUNT_ACCTS_NEW)
					println(" Count of Records in DataQuality Violations File     :"+ params.OUTPUT_FILE_DQ_NAME   +" : "+COUNT_DQ_REC )
					println(" Count of Records in Rejection Records  File     :"+ params.OUTPUT_FILE_ERR_NAME   +" : "+COUNT_REJ_SDVL )
					//## Start of code block for output XML file writing##
					println("Usage : Start : Saving the updated request XML file (applying the exclude rejection records from the file filter)")
					//Start of code blcok to write the temp request xml file by filtering the error records
					try
					{
						println("Usage : Start : Saving the curated XML file Records file")
						validRequestRecordsDF
						// .coalesce(1)
						.repartition(1)
						.write.mode("overwrite")
						.format("com.databricks.spark.xml")
						.option("rootTag", params.OUTPUT_FILE_XMLREQUET_ROOTTAG) //.option("rootTag", "MESSAGE")
						.option("rowTag", params.OUTPUT_FILE_XMLREQUET_ROWTAG) //.option("rowTag", "ACCOUNT")
						//.save(params.OUTPUT_FILE_XMLREQUET_PATH + params.OUTPUT_FILE_XMLREQUET_NAME)
						//.save(params.OUTPUT_FILE_XMLREQUET_PATH +"tmp")
						.save(tempFolder)
						//Function call to merge all part files
						try 
						{ mergeFiles3(getListOfFiles(tempFolder),finalHeaderString, params.OUTPUT_FILE_XMLREQUET_PATH + params.OUTPUT_FILE_XMLREQUET_NAME,tempFolder)}
						catch
						{
							case e: Exception =>
							println("Error : Exception caught in delete temp directory / merge files method")
							e.printStackTrace()
						}
						println("Usage : End : Saved the curated XML file :" +params.OUTPUT_FILE_XMLREQUET_PATH + params.OUTPUT_FILE_XMLREQUET_NAME)
					}
					catch
					{						
						case e: Exception =>
						println("Error : Exception caught in writing curated XML file")
						e.printStackTrace()
					}//End of block for curated request xml file generation
					
					validRequestRecordsDF.unpersist()
					// invalidRecDF.unpersist()
					rejectRecDF.unpersist()
					try
					{
						println("Start appending control table with current run stats")
						val currentTime=new java.sql.Timestamp(System.currentTimeMillis())
						val runStatsDF=Seq(RequestFileStats2 (currentKey1,currentKey2,fileName,runDate,currentTime,currentRunNumber,fileType,fileProduct,COUNT_INFILE_REC,COUNT_OUTFILE_REC,COUNT_REJ_SDVL,COUNT_REJ_SIMAH,COUNT_REJ_TOTAL,COUNT_REJ_EXTRA,COUNT_REJ_MISSING,COUNT_ACCTS_NEW,COUNT_DQ_REC,RESP_STS_SDVL,"")).toDF()
						runStatsDF.write.format("delta").mode("append").save(controlTablePath)
						println("End appending control table with current run stats")
						println(s"inserted control table with current run stats for key1:$currentKey1")
						spark.sql(s"select *  FROM delta.`$controlTablePath` where KEY1 = '$currentKey1'").show()
					}
					catch
					{
						case e:Exception =>
							println("Exception caught while appending control table with current run stats")
							e.printStackTrace()
					}
				}//end else block for previous key status update
			}//end of maxRunDF empty check if  block
			else
			{
				println(s"Usage : unable to fetch the previous run details for file type: $fileType and product_type:$fileProduct ")
                   println("Error : Aborting the Program ")
				println(".....SimahDataValidator Execution Aborted @"+ programStartTime.value)
                   System.exit(1)
			}
		} // end of main try block
		catch
		{
			case e:Exception =>
			println("Exception caught in main block")
			e.printStackTrace()
		}
		println(".....SimahDataValidator Execution Completed @"+ new java.sql.Timestamp(System.currentTimeMillis()))
		println("Start Time :" + programStartTime.value)
		println("End Time :" + new java.sql.Timestamp(System.currentTimeMillis()))
		println("Execution Time: " + getTimeDifference(programStartTime.value,new java.sql.Timestamp(System.currentTimeMillis())))
		//spark.close()
		spark.stop()
	} // close args else block
} //Close def main 
} // close object