package com.fds.qcl

import org.apache.spark.sql.SparkSession
import io.delta.tables._
import io.delta._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.commons.io.FileUtils
import java.io.File
import org.apache.log4j._

import utils.SimahCaseClasses._
import utils.QCLHelperFunctions_V2._
import utils.SimahRuleChecker._
import utils.ConfigParams._

object QCLHistroyLoader_V4 {

 
      def historyLoader(spark : SparkSession,params:utils.QCLConfigParams,log:Logger, RUN_DATE:java.sql.Date,FILE_NAME:String  ): Unit = {
            
        //Logger.getLogger("org").setLevel(Level.ERROR)
          val BaseTablePath= params.DELTA_TABLE_PATH_BASE //"C:/Bigdata/QCL_EXECUTION/LAKEHOUSE/BASE/"
                  val BaseHistTableName=params.DELTA_TABLE_NAME_BASE // "base_hist"
                  val BaseHistRawTableName=params.DELTA_TABLE_NAME_BASERAW //"base_hist_raw"
                  //Start of run control table creation block
      
                  val configFile=
                    if(FILE_NAME.isEmpty() || FILE_NAME=="")
                      params.INPUT_FILE_HISTDATA_CONFIG_PATH+params.INPUT_FILE_HISTDATA_CONFIG_FILENAME
                    else
                      FILE_NAME
                      
                  val params2=setQCLHistConfigParams(configFile)
                  printQCLHistConfigParams(params2)
                  
                  log.info("\n ################# historyLoader started #####################")
                  
                         val rawDataDF = spark.sqlContext.read.format("csv")
                       .option("header", "true")
                       .option("mode", "DROPMALFORMED")
                       .option("encoding", params2.INPUT_DATAFILECHARCTERSET)
                       .option("delimiter", params2.INPUT_DATAFILEDELIMETER)
                       //.load(filePath)
                       .load(params2.INPUT_DATAFILEPATH+params2.INPUT_DATAFILENAME)
     rawDataDF.printSchema()
     rawDataDF.show(false)
   log.info("Loading input file:"+ params2.INPUT_DATAFILEPATH+params2.INPUT_DATAFILENAME )
   log.info("File schema")
   log.info( rawDataDF.schema.printTreeString().toString())
   log.info( "Started converting to new schema")
   //val customSchemaDF=getCustomSchemaDF4(rawDataDF,params2)
     val customSchemaDF=getCustomSchemaDF5(rawDataDF,params2,log)
     log.info("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! SchemaDF !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
       //  customSchemaDF.printSchema()
       //  customSchemaDF.show(false)
     log.info( "completed converting to below schema")
     log.info( customSchemaDF.schema.printTreeString())
   
     
     
    // System.exit(0)
     val base_raw_table=BaseTablePath + params2.INPUT_DATAFILENAME
     log.info(s"base_raw_table:$base_raw_table")
      
     customSchemaDF.write.format("delta").mode("overwrite").save(base_raw_table)
     
     val raw_DF=spark.sql(s"SELECT * FROM delta.`$base_raw_table`").na.fill("")
     
     //customSchemaDF.printSchema()
    // raw_DF.printSchema()
     //customSchemaDF.show(false)
    // raw_DF.show(false)
   
    val mappingList=params2.LOAD_MAPPING_LIST
    
    val selectSql=new StringBuffer()
      selectSql.append("SELECT ")
      
     
    /*for (arr <- mappingList)
    {
      log.info("Len:"+ arr.length)
      log.info(arr(0))
       log.info(arr(1))
     }*/
     mappingList.map(arr =>  selectSql.append(" "+arr(1) +" AS "+arr(0) +",") )
     
     selectSql.append(s" FROM delta.`$base_raw_table`")
     
     val selectSqlString=selectSql.toString().patch(selectSql.toString().lastIndexOf(','), "", 1)
     
    // log.info("SQLStringBuffer::"+selectSql)
     log.info("SQLString::"+selectSqlString)
     
     val raw2HistMapDF=spark.sql(selectSqlString)
     
     raw2HistMapDF.printSchema()
     raw2HistMapDF.show(false)
     
     
     val baseTableCreateSql=s"""CREATE TABLE  delta.`$BaseTablePath$BaseHistTableName` (
                              |AccountNumber STRING,
                              |ProductType STRING,
                              |SalaryAssignment STRING,
                              |SecurityType STRING,
                              |PaymentFrequency STRING,
                              |IssueDate Date,
                              |ExpiryDate Date,
                              |AsOfDate Date,
                              |CloseDate Date,
                              |ProductStatus STRING,
                              |PaymentStatus STRING,
                              |Tenure INT,
                              |InstallmentAmount DOUBLE,
                              |OriginalAmount DOUBLE,
                              |OutStandingBalance DOUBLE,
                              |LastCycleID INT,
                              |LastAmountPaid DOUBLE,
                              |LastPaymentDate Date,
                              |NextPaymentDate Date,
                              |PastDueBalance DOUBLE,
                              |DefaultStatus STRING,
                              |DefaultLoadDate Date,
                              |DefaultOriginalAmount DOUBLE,
                              |DefaultOutStandingAmount DOUBLE,
                              |DefaultStatusDate Date,
                              |DefaultChangeDate Date,
                              |CIUploadDate Date,
                              |CIUpdateDate Date,
                              |CurrentStatus STRING,
                              |ReportedDate Date,
                              |AcceptedDate Date,
                              |DPR INT,
                              |DPA INT,
                              |RJC INT
                              )  USING DELTA""".stripMargin//.replaceAll("\n", "")
                              
      
    try {
      val baseTableCheck=new File(BaseTablePath+BaseHistTableName)
      if(baseTableCheck.exists())
      {
         log.warn("Base Table already exists , skipping creation of Base table , using the existing table: " + s"$BaseTablePath$BaseHistTableName")
      }
      else
      {
        val tablePath = new File(BaseTablePath)
        if (tablePath.exists()) {
          log.info("creating  base table in path: " + s"$BaseTablePath")
          spark.sql(baseTableCreateSql)
          log.info(s"Base table : $BaseHistTableName  is created")
        } else {
          log.info("Path: " + s"$BaseTablePath" + " is Not Exists exiting the program ...")
          log.info("Usage: Re-execute the program by changing  base table path value in parameter file ..")
          System.exit(1)
        }
      }
    } catch {
      case ex: org.apache.spark.sql.catalyst.analysis.TableAlreadyExistsException =>
        log.warn("Usage:Table: " + s"$BaseTablePath$BaseHistTableName" + " is already Exists , Skipping this step......")
         //log.info("Usage: Re-execute the program by changing  base table name value in parameter file ..")
        //System.exit(1)
        log.warn(ex.getLocalizedMessage)
      case e: Exception =>
        log.error("Error : Exception caught in base table creation block")
        log.error(e.getLocalizedMessage)
        e.printStackTrace()
    }
                   
                                                import spark.implicits._
                                    val currentTime=new java.sql.Timestamp(System.currentTimeMillis())
                                    val hist_base_DF=raw2HistMapDF
                                    .withColumn("IssueDate", when('IssueDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('IssueDate))
                                    .withColumn("ExpiryDate", when('ExpiryDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('ExpiryDate))
                                    .withColumn("CloseDate", when('CloseDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('CloseDate))
                                    .withColumn("LastPaymentDate", when('LastPaymentDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('LastPaymentDate))
                                    .withColumn("NextPaymentDate", when('NextPaymentDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('NextPaymentDate))
                                    .withColumn("DefaultLoadDate", when('DefaultLoadDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultLoadDate))
                                    .withColumn("DefaultStatusDate", when('DefaultStatusDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultStatusDate))
                                    .withColumn("DefaultChangeDate", when('DefaultChangeDate==="1753-01-01" , lit(null).cast(DateType)).otherwise('DefaultChangeDate))
                                    .withColumn("CurrentStatus", when('DefaultStatus.isNotNull && ('DefaultStatus==="FS" || 'DefaultStatus==="NS" ||'DefaultStatus==="RS") , lit("SETTLED"))
                                                .when('ProductStatus.isNotNull && 'ProductStatus==="C"  , lit("CLOSED"))
                                                //.when('ProductStatus.isNotNull && 'ProductStatus==="A" && 'DefaultStatus==="NULL" , lit("ACTIVE"))
                                                .when('ProductStatus.isNotNull && 'ProductStatus==="A" && 'DefaultStatus.isNull  , lit("ACTIVE"))
                                                .when('DefaultStatus.isNotNull || 'ProductStatus==="W" , lit("WRITTENOFF"))
                                                //&& 'DefaultStatus.isNull
                                                .when('ProductStatus.isNotNull && 'ProductStatus==="S"  && 'DefaultStatus.isNull , lit("SUSPENDED"))
                                                //.when('ProductStatus.isNotNull  && 'ProductStatus==="W"  && ('DefaultStatus.isNull || 'DefaultStatus==="OS" || 'DefaultStatus==="PP") , lit("WRITTENOFF"))
                                                //.when('DefaultStatus.isNotNull && 'DefaultStatus==="RS"  , lit("CLOSED"))
                                                .otherwise('ProductStatus))
                                    //.withColumn("ReportedDate", lit(RUN_DATE).cast(DateType))
                                    //.withColumn("ReportedDate", coalesce('DefaultChangeDate,'DefaultStatusDate, 'CIUpdateDate))
                                    //.withColumn("AcceptedDate", coalesce('DefaultChangeDate,'DefaultStatusDate, 'CIUpdateDate))
                                    .withColumn("ReportedDate", when('DefaultChangeDate.isNotNull && 'DefaultChangeDate > 'CIUpdateDate , 'DefaultChangeDate )
                                                                            .when( 'DefaultStatusDate.isNotNull && 'DefaultStatusDate > 'CIUpdateDate ,'DefaultStatusDate)
                                                                            .otherwise('CIUpdateDate))
                                    .withColumn("AcceptedDate", when('DefaultChangeDate.isNotNull && 'DefaultChangeDate > 'CIUpdateDate , 'DefaultChangeDate )
                                                                            .when( 'DefaultStatusDate.isNotNull && 'DefaultStatusDate > 'CIUpdateDate ,'DefaultStatusDate)
                                                                            .otherwise('CIUpdateDate))
                                                    //coalesce('DefaultStatusDate, 'CIUpdateDate))
                                    .withColumn("currentDate", current_date())
                                    //.withColumn("DPR",datediff('currentDate, coalesce('DefaultStatusDate, 'CIUpdateDate)))
                                    //.withColumn("DPA",datediff('currentDate, coalesce('DefaultStatusDate, 'CIUpdateDate)))
                                    //.withColumn("DPR",datediff('currentDate, 'ReportedDate))
                                    //.withColumn("DPA",when('CurrentStatus==="SETTLED" || 'CurrentStatus==="CLOSED" , lit(0)).otherwise( datediff('currentDate, 'ReportedDate)))
                                    //.withColumn("DPR", datediff('currentDate, 'ReportedDate))
                                    .withColumn("DPR",  datediff(lit(RUN_DATE), 'ReportedDate))
                                    //.withColumn("DPA",when('CurrentStatus==="SETTLED" || 'CurrentStatus==="CLOSED" , lit(0)).otherwise( datediff('currentDate, 'AcceptedDate)))
                                    .withColumn("DPA",when('CurrentStatus==="SETTLED" || 'CurrentStatus==="CLOSED" , lit(0)).otherwise( datediff(lit(RUN_DATE), 'AcceptedDate)))
                                    
                                    // .withColumn("DPR",  expr(s" (( $currentTime - CIUploadDate.getTime() ) / (60 * 60 * 1000 *24))"))//                    lit(null).cast(IntegerType))
                                    // .withColumn("DPR",  expr(s" (($currentTime - CIUploadDate.getTime() ) / (60 * 60 * 1000 *24))"))
                                    //  .withColumn("x", getTimeDifference('CIUploadDate,new java.sql.Timestamp(System.currentTimeMillis())))
                                    //.withColumn("DPA",  lit(null).cast(IntegerType))
                                    .withColumn("RJC", lit(0).cast(IntegerType))
                                    .select('AccountNumber,'ProductType,'SalaryAssignment,'PaymentFrequency,'SecurityType,'IssueDate,'ExpiryDate,
                                                'AsOfDate,'CloseDate,'ProductStatus,'PaymentStatus,'Tenure,'InstallmentAmount,
                                                'OriginalAmount,'OutStandingBalance,'LastCycleID,'LastAmountPaid,'LastPaymentDate,
                                                'NextPaymentDate,'PastDueBalance,'DefaultStatus,'DefaultLoadDate,'DefaultOriginalAmount,
                                                'DefaultOutStandingAmount,'DefaultStatusDate,'DefaultChangeDate,'CIUploadDate,
                                                'CIUpdateDate,'CurrentStatus,'ReportedDate,'AcceptedDate,'DPR,'DPA,'RJC)
                                                
                                    hist_base_DF.printSchema()
                                    hist_base_DF.show()
                                    //          log.info(hist_base_DF.show() )
                                    //Test
                                    val loadMode=params2.LOAD_MODE
                                    
                                    val baseTable=BaseTablePath+BaseHistTableName
                                    hist_base_DF.write.format("delta").mode(loadMode).save(baseTable)
                                    
                                    hist_base_DF.groupBy('CurrentStatus,'ProductStatus,'DefaultStatus).agg(count('AccountNumber).as("TotalAccts")).show()
                                    
            val baseDeltaDF=spark.sql(s"SELECT * FROM delta.`$baseTable`")
            
              
            baseDeltaDF.groupBy('CurrentStatus,'ProductStatus,'DefaultStatus).agg(count('AccountNumber).as("TotalAccts")).show()
            
   // log.info ("***********Manual Exit ****************") ; System.exit(0)
    
        //E:/Murali/bigdata_folder/DataProfiling/Simah/2023/reconfiles/2419087_119_Recon/119_Recon
    //val filePath="E:/Murali/bigdata_folder/DataProfiling/Simah/2023/reconfiles/2419087_119_Recon/119_Recon/Consumer_Default_ReconciliationFile_For_Member_119.csv"
    //##val filePath="E:/Murali/bigdata_folder/DataProfiling/Simah/2023/reconfiles/2419087_119_Recon/119_Recon/Consumer_Default_ReconciliationFile_For_Member_119.csv"
    log.info("\n ################# historyLoader Completed #####################")
 spark.stop()
      }
      
          def getCustomSchemaDF5(df: DataFrame,params2:utils.QCLHistConfigParams,log:Logger): DataFrame =
    {
      val schemaTupleMap=params2.schemaTupleMapParam
     val listOfCols =schemaTupleMap.keySet.toSeq
      
      val seed = 5
      val withReplacement = false
      val fraction = 0.05
       val tempDF=  df.select(listOfCols.head, listOfCols.tail: _*)
      
      val newDF=listOfCols.foldLeft(df)((df2,columnName) =>
        {
           
        try {
          val row = schemaTupleMap.get(columnName).get
        //val columnName=structField.name
        val datatype = getDataType3(row,log) //structField.dataType
        val dataTypeString = datatype.simpleString
         
          val sampleDF = df2.sample(withReplacement, fraction, seed)
          if (!schemaTupleMap.get(columnName).get._4.isEmpty) 
          {
            val dateFormat = schemaTupleMap.get(columnName).get._4
            //log.info("#####################Caught DateFormat : " + dateFormat)
            if (isComportableDate(datatype, sampleDF, columnName, dateFormat,log)) 
            {
             // log.info("DataType:  " + datatype)
             
             // log.info("dataTypeString:  " + dataTypeString)
              df2.withColumn(columnName, to_date(col(columnName), dateFormat))
            }
            else
              df2
          } else if (!dataTypeString.equalsIgnoreCase("string") && isComportable(datatype, sampleDF, columnName,log)) {
            //&& customSchemaDF.withColumn(columnName,   trim(col(columnName)).cast(datatype))
            df2.withColumn(columnName, (col(columnName)).cast(datatype))
          } else if (!dataTypeString.equalsIgnoreCase("string") && !dataTypeString.equalsIgnoreCase("date")) {
            //log.info("isComportable:"+isComportable(datatype,sampleDF, columnName))
            //log.info("Count:"+sampleDF.count())
            log.info("&&&&&&&&&&&&&& not comportable : ColumnName: " + columnName + " :DataType:  " + datatype)
            df2.withColumn(columnName, col(columnName).cast(StringType))
          } else
            df2
        } catch {
         
          case ex: Exception => df2
          //case _: Throwable =>  df2
        } //End of catch block
        //  customSchemaDF=customSchemaDF
  
        })
      newDF
    }
          def isComportableDate(dataType: DataType, df: DataFrame, columnName: String, dateFormat: String,log:Logger): Boolean = {
    
      try
      {
        log.info(s"ColumnName:$columnName  is Converting to dateFormat $dateFormat")
        val df2 = df.filter(col(columnName).isNotNull).withColumn(columnName, to_date(col(columnName), dateFormat).isNotNull).filter(col(columnName) === false)
         val a = df2.select(columnName).distinct().collect().map(x => x(0).toString().toBoolean)
  
      //    log.info("*********Count:"+df2.count())
      //   log.info("*********length:"+a.length)
     // log.info(columnName)
      if (a.length == 0)
        true
      else if (a.length == 1) {
        log.info("********* Date Foramt is not Comportable")
        //log.info("a(0)" + a(0))
        a(0)
      } else if (a.length == 2) {
        log.info(a(0) + " : " + a(1))
        false
      } else
        false
        }
      catch
      {
        case e : Exception => log.info ("^^^^ Exception Caught")
        e.printStackTrace()
        false
      }
  }

    
    def getDataType3(field: (String, String, String, String, String, String, String, String, String, String, String, String),log:Logger) = 
    {

      val xyz: DataType = field._1.toUpperCase() match {
  
        case "INT"                => IntegerType
        case "DOUBLE"             => DoubleType
        case "STRING"             => StringType
        case "JAVA.SQL.TIMESTAMP" => DateType
        case "DATE"               => DateType
        case "TIMESTAMP"          => TimestampType
        case "FLOAT"              => FloatType
        case "NUMBER" =>
          {
            if (field._2.isEmpty())
              LongType
            else if (field._3.isEmpty()) {
              // log.info("ReturningType:DecimalType")
              // DecimalType.SYSTEM_DEFAULT
              LongType
              // DecimalType.apply(field(2).toInt, 2)
              //LongType//
            } else if (!field._2.isEmpty() && field._3.isEmpty())
              DecimalType.apply(field._2.toInt, 0)
            else if (!field._2.isEmpty() && !field._3.isEmpty())
              DecimalType.apply(field._2.toInt, field._3.toInt)
            else
              DecimalType.SYSTEM_DEFAULT
          }
        case _ => StringType
      }
      xyz
  }
      
 def isComportable(dataType: DataType, df: DataFrame, columnName: String,log:Logger): Boolean = 
 {
    try
    {
     val df2 = df.filter(col(columnName).isNotNull).withColumn(columnName, trim(col(columnName)).cast(dataType).isNotNull).filter(col(columnName) === false)
    
     val a = df2.select(columnName).distinct().collect().map(x => x(0).toString().toBoolean)

     if (a.length == 0)
      true
    else if (a.length == 1) {
      log.info("a(0)" + a(0))
      a(0)
    } else if (a.length == 2)
       false
    else
      false
    }
    catch
    {
      case e : Exception => log.info ("^^^^ Exception Caught")
      e.printStackTrace()
      false
    }
  }
}